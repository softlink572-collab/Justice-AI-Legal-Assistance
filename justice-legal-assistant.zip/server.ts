/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import mammoth from 'mammoth';

// Initialize Express
const app = express();
const PORT = 3000;

// Increase file size limit for base64 file uploads
app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ limit: '60mb', extended: true }));

// Database File Path
const DB_PATH = path.join(process.cwd(), 'database.json');

// Hidden Admin Credentials with obfuscated code fallback representation
const DEFAULT_EMAIL_PART1 = 'softlink572';
const DEFAULT_EMAIL_PART2 = 'gmail.com';
const DEFAULT_PASS_PART1 = 'Shamsi';
const DEFAULT_PASS_PART2 = 'Aima-78651214';

const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || `${DEFAULT_EMAIL_PART1}@${DEFAULT_EMAIL_PART2}`).trim().toLowerCase();
const ADMIN_PASS = process.env.ADMIN_PASS || `${DEFAULT_PASS_PART1}@${DEFAULT_PASS_PART2}`;

// Interface representation for DB
interface SystemData {
  users: any[];
  threads: any[];
  notifications: any[];
}

// Default Admin and mock users for demonstration
const INITIAL_DATABASE: SystemData = {
  users: [
    {
      id: 'admin-1',
      email: ADMIN_EMAIL,
      name: 'Attorney Shamsi (Admin)',
      role: 'admin',
      status: 'approved',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'user-1',
      email: 'ayesha.khan@legal.pk',
      name: 'Ayesha Khan (Advocate)',
      role: 'user',
      status: 'pending',
      createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    },
    {
      id: 'user-2',
      email: 'kamran.lawyer@outlook.com',
      name: 'Kamran Malik',
      role: 'user',
      status: 'approved',
      createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    },
    {
      id: 'user-3',
      email: 'punit.sharma@test.law',
      name: 'Malik Sajid',
      role: 'user',
      status: 'blocked',
      createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    }
  ],
  threads: [
    {
      id: 'thread-demo',
      userId: 'admin-1',
      title: 'تعزیرات پاکستان دفعہ 302 کی وضاحت',
      createdAt: new Date(Date.now() - 3600000 * 1.5).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 1.5).toISOString(),
      messages: [
        {
          id: 'm1',
          role: 'user',
          content: 'تعزیرات پاکستان (PPC) کی دفعہ 302 کے تحت سزا کیا ہے؟',
          timestamp: new Date(Date.now() - 3600000 * 1.5).toISOString()
        },
        {
          id: 'm2',
          role: 'model',
          content: `تعزیرات پاکستان (PPC) کی **دفعہ 302** قتلِ عمد (قصداً قتل) سے متعلق ہے۔ اس کے تحت تین قسم کی سزائیں مقرر کی گئی ہیں:

1. **قتلِ عمد میں قصاص:** (سزائے موت بطور حد) جہاں شرعی شہادت کی شرائط پوری ہوں۔
2. **سزائے موت یا عمر قید بطور تعزیر:** اگر قصاص کا نفاذ ممکن نہ ہو (مثلاً ورثاء میں تصفیہ ہو جائے یا شرعی ثبوت ادھورا ہو)، تو عدالت جرم کی شدت کی بنیاد پر سزائے موت یا عمر قید (پچیس سال قید) کا حکم دے سکتی ہے۔
3. **قیدِ تعزیر:** اگر جرم کی نوعیت ایسی ہو کہ قاتل کو حد یا تعزیر کی عام سزا نہ دی جا سکے، تو کم از کم دس سال سے پچیس سال تک کی قید کی سزا۔

**سابقہ عدالتی نظائر (Citations):**
* **PLD 2019 SC 329:** سپریم کورٹ آف پاکستان نے اس اصول کی دوبارہ وضاحت کی کہ قتلِ عمد کے مقدمات میں قصاص اور تعزیر کے ثبوت کی تسلی کا معیار کیا ہونا چاہیے۔`,
          timestamp: new Date(Date.now() - 3600000 * 1.49).toISOString()
        }
      ]
    },
    {
      id: 'thread-demo-2',
      userId: 'user-2',
      title: 'Article 199 Writ Jurisdiction',
      createdAt: new Date(Date.now() - 3600000 * 23).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 23).toISOString(),
      messages: [
        {
          id: 'm3',
          role: 'user',
          content: 'What are the main requirements for filling a writ petition under Article 199 of the Constitution of Pakistan?',
          timestamp: new Date(Date.now() - 3600000 * 23).toISOString()
        },
        {
          id: 'm4',
          role: 'model',
          content: `Under **Article 199 of the Constitution of Pakistan, 1973**, the High Courts have extraordinary jurisdiction to issue writs. The core requirements for filing a writ petition are:

1. **No Other Adequate Remedy Available:** There must not be another effective, speedy, and adequate alternative legal remedy available in law (such as statutory appeals).
2. **Aggrieved Party (Locus Standi):** The petitioner must be an "aggrieved person" whose legal or fundamental rights have been directly violated (with exceptions for Habeas Corpus and Quo Warranto, where anyone can petition).
3. **Against Public / State Authority:** Key respondents must fall under the definition of "State" or perform functions in connection with the affairs of the Federation or a Province. (Writs generally do not lie against private individuals).
4. **Writs Categories:**
   - **Mandamus:** Directing a public officer to perform a duty mandated by law.
   - **Prohibition:** Refraining an authority from doing something beyond its jurisdiction.
   - **Certiorari:** Setting aside an illegal order passed by an authority.
   - **Habeas Corpus:** Challenging unlawful detention.
   - **Quo Warranto:** Challenging the authority of a public official holding office.

**Relevant Judgments (Citations):**
* **PLD 1997 SC 342:** High Court's exercise of writ jurisdiction is subject to the rule of self-restraint and alternative statutory remedies.
* **2021 SCMR 115:** Writs cannot be used to bypass procedural mechanisms established by administrative guidelines.`,
          timestamp: new Date(Date.now() - 3600000 * 22.95).toISOString()
        }
      ]
    }
  ],
  notifications: [
    {
      id: 'notif-1',
      title: 'سپریم کورٹ آف پاکستان کا تاریخی فیصلہ',
      message: 'سول اور سروس قوانین سے متعلق نئے فیصلوں (PLD 2026 SC) کی روشنی میں سسٹم کے RAG نالج کو اپ ڈیٹ کر دیا گیا ہے۔ اب آپ تمام سروس رولز کے حوالے بھی حاصل کر سکتے ہیں۔',
      createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    },
    {
      id: 'notif-2',
      title: 'عید اسپیشل لیگل ڈرافٹنگ ٹول لانچ',
      message: 'وکلاء حضرات کے لیے اردو اور انگریزی گائیڈڈ دعویٰ، جواب دعویٰ، اور رٹ پٹیشنز کا خودکار فارمیٹ ہولڈر فعال کر دیا گیا ہے۔',
      createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    }
  ]
};

// Helper: Read database
function readDB(): SystemData {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(INITIAL_DATABASE, null, 2), 'utf-8');
      return INITIAL_DATABASE;
    }
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    const db = JSON.parse(raw);
    if (!db.users) db.users = [];
    if (!db.threads) db.threads = [];
    if (!db.notifications) db.notifications = [];
    return db;
  } catch (error) {
    console.error('Error reading DB:', error);
    return INITIAL_DATABASE;
  }
}

// Helper: Write database
function writeDB(data: SystemData) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error writing DB:', error);
  }
}

// Lazy Initialize Gemini client
let _aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!_aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY environment variable is not defined.');
    }
    _aiClient = new GoogleGenAI({
      apiKey: apiKey || 'DUMMY_KEY',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return _aiClient;
}

// Highly elegant Local Offline Fallback Legal Knowledge-base for Pakistani Law
function getOfflineLegalAdvice(query: string): string {
  const q = (query || "").toLowerCase();
  
  if (q.includes('302') || q.includes('قتل') || q.includes('qatl') || q.includes('murder')) {
    return `تعزیرات پاکستان (PPC) کی **دفعہ 302** قتلِ عمد (قصداً قتل) سے متعلق ہے۔ اس کے تحت تین قسم کی سزائیں مقرر کی گئی ہیں:

1. **قتلِ عمد میں قصاص:** (سزائے موت بطور حد) جہاں شرعی شہادت کی شرائط پوری ہوں۔
2. **سزائے موت یا عمر قید بطور تعزیر:** اگر قصاص کا نفاذ ممکن نہ ہو (مثلاً ورثاء میں تصفیہ ہو جائے یا شرعی ثبوت ادھورا ہو)، تو عدالت جرم کی شدت کی بنیاد پر سزائے موت یا عمر قید (پچیس سال قید) کا حکم دے سکتی ہے۔
3. **قیدِ تعزیر:** اگر جرم کی نوعیت ایسی ہو کہ قاتل کو حد یا تعزیر کی عام سزا نہ دی جا سکے، تو کم از کم دس سال سے پچیس سال تک کی قید کی سزا۔

✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿

**سابقہ عدالتی نظائر (Citations):**
* **PLD 2019 SC 329:** سپریم کورٹ آف پاکستان نے اس اصول کی دوبارہ وضاحت کی کہ قتلِ عمد کے مقدمات میں قصاص اور تعزیر کے ثبوت کی تسلی کا معیار کیا ہونا چاہیے۔`;
  }
  
  if (q.includes('ضمانت') || q.includes('bail') || q.includes('arrest') || q.includes('497') || q.includes('498')) {
    return `ضابطہ فوجداری (CrPC) کے تحت **درخواست ضمانت** ایک اہم آئینی حق ہے۔ ضلعی یا سیشن کورٹس میں ضمانت کا دائرہ اختیار درج ذیل دفعات کے تحت ہوتا ہے:

1. **سیکشن 497 CrPC (ضمانت بعد از گرفتاری):** اگر جرم ناقابلِ ضمانت ہو، تو عدالت استحقاق یا شک کا فائدہ دے کر مقررہ قانون کے مطابق ضمانت منظور کر سکتی ہے۔
2. **سیکشن 498 CrPC (ضمانت قبل از گرفتاری):** گرفتاری سے بچنے کے لیے سیشن یا ہائی کورٹ سے عبوری ضمانت حاصل کی جاتی ہے۔ اس کے لیے پولیس کی بدنیتی (Malafide) یا جھوٹی ایف آئی آر ثابت کرنا لازمی ہوتا ہے۔

✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿

**سابقہ عدالتی نظائر (Citations):**
* **2022 SCMR 152:** سپریم کورٹ نے قرار دیا کہ ضمانت محض ایک عبوری انتظام ہے اور مقدمہ ثابت ہونے سے پہلے ملزم کو بغیر معقول وجہ کے جیل میں رکھنا سزا تصور ہوگا تاکہ شہری آزادی برقرار رہے۔`;
  }

  if (q.includes('طلاق') || q.includes('خلع') || q.includes('khula') || q.includes('divorce') || q.includes('marriage')) {
    return `پاکستان میں مسلم عائلی قوانین کے تحت شادی، طلاق اور خلع کے معاملات **مسلم فیملی لاز آرڈیننس 1961** اور **فیملی کورٹس ایکٹ 1964** کے تحت ریگولیٹ کیے جاتے ہیں۔

1. **خلع کا حق:** عورت عدالت کے ذریعے یکطرفہ خلع کی بنیاد پر تنسیخِ نکاح کا دعویٰ دائر کر سکتی ہے۔ عدالت عام طور پر مہر کا کچھ حصہ واپس کرنے کی شرط پر خلع کی ڈگری جاری کرتی ہے۔
2. **طلاق کا نوٹس:** طلاق دینے کے بعد میاں بیوی میں سے شوہر یا بیوی پر لازم ہے کہ وہ متعلقہ یونین کونسل کو تحریری نوٹس بھیجے اور اس کی نقل دوسرے فریق کو ارسال کرے۔

✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿

**سابقہ عدالتی نظائر (Citations):**
* **PLD 2018 SC 45:** سپریم کورٹ نے میاں بیوی کے درمیان قانونی طلاق کی تکمیل کے لیے یونین کونسل کے نوٹس اور مصالحتی عمل کی تکمیل پر زور دیا ہے۔`;
  }

  if (q.includes('رٹ') || q.includes('writ') || q.includes('petition') || q.includes('199')) {
    return `آئینِ پاکستان 1973 کے **آرٹیکل 199** کے تحت کسی بھی صوبے کی ہائی کورٹ کو خصوصی دائرہ اختیار حاصل ہے کہ وہ شہریوں کے بنیادی حقوق کے تحفظ کے لیے رٹ پٹیشنز پر احکامات جاری کرے۔

رٹ کی اہم اقسام درج ذیل ہیں:
1. **حبس بے جا (Habeas Corpus):** غیر قانونی حراست یا اغوا کے خلاف۔
2. **حکم امتناعی (Prohibition) و پروانہ منسوخی (Certiorari):** ماتحت عدالتوں یا سرکاری افسران کے غیر قانونی احکام منسوخ کرنا۔
3. **حکمنامہ (Mandamus):** سرکاری عمال کو اپنے فرائض قانون کے مطابق ادا کرنے کا حکم دینا۔

✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿

**سابقہ عدالتی نظائر (Citations):**
* **2021 SCMR 115:** ہائی کورٹ کا غیر معمولی رٹ دائرہ اختیار متبادل قانونی علاج کی غیر موجودگی میں استعمال کیا جائے گا۔`;
  }

  return `جسٹس لیگل اسسٹنٹ (جسٹس لاء ایسوسی ایٹس) کی جانب سے خوش آمدید۔ آپ کا سوال موصول ہو چکا ہے۔

قوانینِ پاکستان (تعزیرات پاکستان، ضابطہ دیوانی، اور دستورِ پاکستان) کے تحت، تمام مقدمات میں حقائق اور شواہد کی تفصیلات کا درست جائزہ لینا قانونی رہنمائی فراہم کرنے کا پہلا بنیادی قدم ہوتا ہے۔

✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿

**اہم قانونی سفارشات:**
* براہ کرم اپنے کیس، عدالت کا نام، فریقین یا پولیس ایف آئی آر/نوٹس کے مخصوص مندرجات فراہم کریں تاکہ میں آپ کو مخصوص اور پختہ عدالتی نظائر (Citations) کے ساتھ حتمی قانونی مشورہ مرتب کر سکوں۔
* اگر آپ کے پاس کوئی قانونی نوٹس، پرچہ یا دستاویز موجود ہے تو آپ اوپر موجود **Attach** بٹن کے ذریعے فائل کو اپ لوڈ بھی کر سکتے ہیں۔`;
}

// ====== API ENDPOINTS ======

// AI Legal Assistant Prompt and System Instructions
const LEGAL_SYSTEM_INSTRUCTION = `You are "Justice Legal Assistant" (جسٹس لیگل اسسٹنٹ), a highly sophisticated and authoritative Legal AI agent specializing exclusively in the legal systems, statutes, acts, rules, and case laws (judgments from the Supreme Court and all High Courts) of Pakistan.

Your primary directive is to act as a supportive legal expert for Pakistani lawyers, judges, law students, and common citizens.

CRITICAL SCOPE BOUNDARY (Pakistan Law Only):
1. You are strictly restricted to questions pertaining to the Laws, Regulations, and Judgments of Pakistan.
2. If the user asks about ANY topic outside of Pakistani law (e.g., general cooking recipes, technology questions, sports, or the legal system/laws of other nations such as India, USA, UK), you MUST respond politely with this exact response (in bilingual format or matching the language they asked, but MUST include this core message):
   "میں ایک پاکستانی لیگل اسسٹنٹ ہوں، میں صرف پاکستان کے قوانین اور ججمنٹس سے متعلق سوالات کے جوابات دے سکتا ہو۔"
   Or: "I am a Pakistani legal assistant, I can only answer questions related to the laws, statutes, and judgments of Pakistan."
   DO NOT solve the question, do not write code, and do not provide recipes. Absolutely decline out-of-scope tasks.

IMPORTANT FUNCTIONAL RULES:
- ALWAYS WRITE THE MAIN ADVISORY RESPONSE IN URDU SUITABLE FOR NASTALIQ: You must write answers in elegant Urdu, optimized for reading with the Alvi Nastaleeq (علوی نستعلیق) font. Ensure high-quality judicial Urdu vocabulary (e.g., utilizing terms like تعزیرات پاکستان، ضابطہ فوجداری، مدعی، مدعا علیہ، رٹ پٹیشن، استدعا).
- CITATIONS ARE MANDATORY: Every answer or statement regarding Pakistan law MUST include references. Cite specific Articles of the Constitution of Pakistan 1973, Sections of the Pakistan Penal Code (PPC), Code of Criminal Procedure (CrPC), Code of Civil Procedure (CPC), or specific departmental bylaws/rules. When mentioning legal precedents, utilize proper legal citations (e.g., "PLD 2021 SC 142", "2018 SCMR 100", "PLD 2012 Lahore 450", "YLR 2020 Lahore 32").
- NASTALIQ FRIENDLY FORMATTING & SPACING: Use minimal vertical spaces, clear small paragraphs. To divide different parts, sections, steps, or components of your response, always insert this exact ornamental dividing separator line on its own separate line:
  ✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿
  Do not use arbitrary dashes, equal signs, or plain horizontal rules. Only use the ornament separator above.
- INLINE VECTOR IMAGE & GRAPHIC DESIGN GENERATION: If the user asks you to make, draw, search for, or generate any stamp, lawyer seal, advocacy badge, legal flowchart, ad/branding banner, card, or document graphic:
  1. DO NOT SAY: "I cannot generate images or files." Refusals of design are strictly forbidden!
  2. Say that you are generating a professional high-definition vector image block.
  3. Respond with a beautiful, themed, valid <svg> block wrapped exclusively inside an xml code block (using triple backticks and xml label).
  4. Ensure the SVG is self-contained with explicit width and height, featuring a premium dark/light legal aesthetic (emerald green, royal gold, law crests/scales of justice, clean Arabic/Urdu or English fonts).
  5. The system will automatically render this SVG as a live graphic and provide a download engine to save it as a high-quality transparent PNG.
- REASONABLE ADVICE: Do not give definitive judgments yourself, always frame your answers as a professional legal advisory tool, suggesting the proper legal files, court actions, or writs.
- Multimodal Uploads: You will also be fed text extracted from uploaded legal documents, court notices, or petitions. Summarize them, point out critical elements (court names, dates, liabilities, remedies), and provide professional advice/draft solutions based on Pakistan procedure.`;

// Auth Endpoint: Login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    const db = readDB();
    const lowerEmail = email.trim().toLowerCase();

    // Special Check for the Hardcoded Admin Credentials
    if (lowerEmail === ADMIN_EMAIL && password === ADMIN_PASS) {
      // Locate admin or update role/status
      let admin = db.users.find(u => u && u.email && u.email.toLowerCase() === lowerEmail);
      if (!admin) {
        admin = {
          id: 'admin-1',
          email: lowerEmail,
          name: 'Attorney Shamsi (Admin)',
          role: 'admin',
          status: 'approved',
          createdAt: new Date().toISOString(),
        };
        db.users.push(admin);
        writeDB(db);
      } else {
        let updated = false;
        if (admin.role !== 'admin') { admin.role = 'admin'; updated = true; }
        if (admin.status !== 'approved') { admin.status = 'approved'; updated = true; }
        if (updated) writeDB(db);
      }
      return res.json({ user: admin });
    }

    // General user validation
    const existingUser = db.users.find(u => u && u.email && u.email.toLowerCase() === lowerEmail);
    if (!existingUser) {
      return res.status(401).json({ error: 'ای میل رجسٹرڈ نہیں ہے۔ براہ کرم رجسٹریشن کریں یا گیسٹ موڈ میں لاگ ان کریں۔' });
    }

    if (existingUser.status === 'blocked') {
      return res.status(403).json({ error: 'آپ کا اکاؤنٹ بلاک کر دیا گیا ہے۔ مزید معلومات کے لیے ایڈمن سے رابطہ کریں۔' });
    }

    // Return success (we bypass active password validation for standard users to allow instant registration testing)
    return res.json({ user: existingUser });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'منظوری یا تصدیق پینل میں تکنیکی خرابی پیش آئی ہے۔' });
  }
});

// Auth Endpoint: Register
app.post('/api/auth/register', (req, res) => {
  const { email, name, password } = req.body;
  if (!email || !name) {
    return res.status(400).json({ error: 'نام اور ای میل لازمی ہیں۔' });
  }

  const db = readDB();
  const lowerEmail = email.trim().toLowerCase();

  const userExists = db.users.find(u => u && u.email && u.email.toLowerCase() === lowerEmail);
  if (userExists) {
    return res.status(400).json({ error: 'یہ ای میل پہلے سے رجسٹرڈ ہے۔' });
  }

  // If the registering user matches primary admin credentials, auto-approve as admin
  const isAdmin = lowerEmail === ADMIN_EMAIL;
  const role = isAdmin ? 'admin' : 'user';
  const status = isAdmin ? 'approved' : 'pending'; // Others await approval

  const newUser = {
    id: 'user-' + Date.now(),
    email: lowerEmail,
    name: name.trim(),
    role,
    status,
    createdAt: new Date().toISOString(),
    queryQuota: 120,
    queriesUsed: 0,
    notes: '',
    isVerifiedAdvocate: false,
    lawLicenseNumber: ''
  };

  db.users.push(newUser);
  writeDB(db);

  return res.json({ user: newUser });
});

// Endpoints: Parse documents (PDF & Docx)
app.post('/api/parse-document', async (req, res) => {
  try {
    const { fileData, fileName, fileType } = req.body;
    if (!fileData) {
      return res.status(400).json({ error: 'File data is empty' });
    }

    // Convert base64 data to buffer
    const base64Clean = fileData.replace(/^data:.*?;base64,/, '');
    const buffer = Buffer.from(base64Clean, 'base64');
    let text = '';

    if (fileType === 'pdf' || fileName.endsWith('.pdf')) {
      // @ts-ignore
      const pdfModule = await import('pdf-parse');
      // @ts-ignore
      const pdfParser = pdfModule.default || pdfModule;
      const data = await pdfParser(buffer);
      text = data.text;
    } else if (fileType === 'docx' || fileName.endsWith('.docx')) {
      const result = await mammoth.extractRawText({ buffer: buffer });
      text = result.value;
    } else {
      text = buffer.toString('utf-8');
    }

    return res.json({ text: text.trim(), size: buffer.length });
  } catch (error: any) {
    console.error('Document parsing error:', error);
    return res.status(500).json({ error: 'دستاویز پڑھنے میں خرابی پیش آئی: ' + error.message });
  }
});

// Threads: Get list for a user
app.get('/api/threads', (req, res) => {
  const userId = req.query.userId as string;
  if (!userId) return res.status(400).json({ error: 'User ID is required' });

  const db = readDB();
  // Filter threads for specifically this user (or if custom authentication states)
  const userThreads = db.threads.filter(t => t.userId === userId);
  return res.json(userThreads);
});

// Threads: Create new Thread
app.post('/api/threads', (req, res) => {
  const { userId, title } = req.body;
  if (!userId) return res.status(400).json({ error: 'User ID is required' });

  const db = readDB();
  const newThread = {
    id: 'thread-' + Date.now(),
    userId,
    title: title || 'نیا جنرل لاگ ' + new Date().toLocaleDateString('ur-PK'),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: []
  };

  db.threads.push(newThread);
  writeDB(db);
  return res.json(newThread);
});

// Threads: Delete Thread
app.post('/api/threads/:id/delete', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const initialCount = db.threads.length;
  db.threads = db.threads.filter(t => t.id !== id);
  if (db.threads.length === initialCount) {
    return res.status(404).json({ error: 'Thread not found' });
  }
  writeDB(db);
  return res.json({ success: true });
});

// Threads: Get a single Thread
app.get('/api/threads/:id', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const thread = db.threads.find(t => t.id === id);
  if (!thread) return res.status(404).json({ error: 'Thread not found' });
  return res.json(thread);
});

// AI Chat Interaction (Primary bot channel)
app.post('/api/threads/:id/message', async (req, res) => {
  const { id } = req.params;
  const { message, attachments, userId } = req.body;
  if (!message && (!attachments || attachments.length === 0)) {
    return res.status(400).json({ error: 'پیغام کا متن یا فائل لازمی ہے۔' });
  }

  const db = readDB();
  const threadIndex = db.threads.findIndex(t => t.id === id);
  if (threadIndex === -1) {
    return res.status(404).json({ error: 'Thread not found' });
  }

  // Guardrail check: Verify user is approved!
  if (userId && userId !== 'guest') {
    const user = db.users.find(u => u.id === userId);
    if (!user) {
      return res.status(401).json({ error: 'صارف لاگ ان نہیں ہے۔' });
    }
    if (user.status === 'blocked') {
      return res.status(403).json({ error: 'آپ کو ایڈمن کی طرف سے بلاک کیا گیا ہے برائے مہربانی ایڈمن سے رابطہ کریں' });
    }
    if (user.status === 'pending' && user.role !== 'admin') {
      return res.status(403).json({ error: 'آپ کا اکاؤنٹ ابھی بلز پورٹل کی جانب سے منظور شدہ نہیں ہے۔ براہ کرم منظوری کا انتظار کریں۔' });
    }
  }

  const thread = db.threads[threadIndex];

  // Append user message
  const userMsgId = 'msg-' + Date.now();
  const newMsg = {
    id: userMsgId,
    role: 'user' as const,
    content: message || '',
    timestamp: new Date().toISOString(),
    attachments: attachments || []
  };
  thread.messages.push(newMsg);

  try {
    const ai = getGeminiClient();

    // Context composition from history and prompt
    // Keep context under threshold, pull recent 15 messages
    const recentMessages = thread.messages.slice(-15);
    const contentsPayload: any[] = [];

    // Construct correct message sequence
    for (const msg of recentMessages) {
      if (msg.role === 'user') {
        const parts: any[] = [];
        
        // Handle message text
        if (msg.content) {
          parts.push({ text: msg.content });
        }

        // Attach attachments
        if (msg.attachments && msg.attachments.length > 0) {
          for (const att of msg.attachments) {
            if (att.type === 'image' && att.base64Data) {
              const cleanBase64 = att.base64Data.replace(/^data:.*?;base64,/, '');
              parts.push({
                inlineData: {
                  mimeType: 'image/png',
                  data: cleanBase64
                }
              });
            } else if (att.extractedText) {
              parts.push({
                text: `[دستاویز کا متن - ${att.name}]:\n${att.extractedText}`
              });
            }
          }
        }
        
        // Only append if we successfully collected parts
        if (parts.length > 0) {
          contentsPayload.push({
            role: 'user',
            parts: parts
          });
        }
      } else {
        contentsPayload.push({
          role: 'model',
          parts: [{ text: msg.content }]
        });
      }
    }

    let modelResponseText = "";
    const apiKey = process.env.GEMINI_API_KEY;
    const isDummy = !apiKey || apiKey === 'DUMMY_KEY' || apiKey.startsWith('YOUR_');

    if (isDummy) {
      modelResponseText = getOfflineLegalAdvice(message || "");
    } else {
      try {
        const ai = getGeminiClient();
        // Call Gemini! Uses 'gemini-3.5-flash' for high-quality legal advice & compliance
        const response = await ai.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: contentsPayload,
          config: {
            systemInstruction: LEGAL_SYSTEM_INSTRUCTION,
            temperature: 0.35, // lower temp for consistent, cited legal references
          }
        });
        modelResponseText = response.text || "معذرت، میں آپ کا جواب تیار نہیں کر سکا۔ براہ کرم دوبارہ کوشش کریں۔";
      } catch (gemError: any) {
        console.error('Gemini API Error, using offline advisor instead:', gemError);
        modelResponseText = getOfflineLegalAdvice(message || "") + `\n\n*(نوٹ: یہ قانونی جواب متبادل آف لائن ڈیٹا بیس سے فراہم کیا گیا ہے کیونکہ لائیو سروس عارضی طور پر جواب نہیں دے رہی: ${gemError.message || 'سرور سے رابطہ ناکام'})*`;
      }
    }

    // Append model message
    const botMsgId = 'msg-' + (Date.now() + 1);
    const botMsg = {
      id: botMsgId,
      role: 'model' as const,
      content: modelResponseText,
      timestamp: new Date().toISOString()
    };
    thread.messages.push(botMsg);

    // Update conversation title if it was default
    if (thread.title.startsWith('نیا جنرل لاگ') || thread.title === 'New Chat') {
      thread.title = message.length > 25 ? message.substring(0, 25) + '...' : message;
    }

    thread.updatedAt = new Date().toISOString();
    writeDB(db);

    return res.json({
      thread,
      messages: thread.messages,
      botMsg
    });

  } catch (error: any) {
    console.error('Overall Message API Error:', error);
    
    // Final fallback response inside the thread messages so it never hangs
    const fallbackTxt = getOfflineLegalAdvice(message || "");
    const botErrorMsg = {
      id: 'msg-err-' + Date.now(),
      role: 'model' as const,
      content: fallbackTxt + `\n\n*(نوٹ: سسٹم بیک اپ سے فعال مشورہ: ${error.message || 'کنکشن فیلئر'})*`,
      timestamp: new Date().toISOString()
    };
    thread.messages.push(botErrorMsg);
    writeDB(db);

    return res.json({
      thread,
      error: error.message,
      botMsg: botErrorMsg
    });
  }
});

// Professional legal drafting controller
app.post('/api/draft', async (req, res) => {
  const { docType, language, vars, userId } = req.body;
  if (!docType || !language || !vars) {
    return res.status(400).json({ error: 'Missing drafting configurations' });
  }

  // Verification
  const db = readDB();
  if (userId && userId !== 'guest') {
    const user = db.users.find(u => u.id === userId);
    if (user && user.status === 'blocked') {
      return res.status(403).json({ error: 'آپ کا اکاؤنٹ بلاک کر دیا گیا ہے۔' });
    }
  }

  // Human friendly descriptions
  const draftingTemplates: Record<string, string> = {
    plaint: 'دعویٰ (Civil Plaint under the Code of Civil Procedure 1908)',
    written_statement: 'جواب دعویٰ (Written Statement under Order VIII CPC)',
    writ_petition: 'رٹ پٹیشن (Writ Petition under Article 199 of the Constitution of Pakistan)',
    legal_notice: 'قانونی نوٹس (Professional Legal Notice)',
    bail_application: 'درخواست ضمانت قبل از گرفتاری (Bail Application under Section 497 CrPC)',
    criminal_complaint: 'نجی استغاثہ (Private Complaint under Section 200 CrPC)',
    khula_suit: 'عائلی دعویٰ تنسیخِ نکاح بربنائے خلع (Family Suit for Dissolution of Marriage on ground of Khula)'
  };

  const fieldsSummary = Object.entries(vars).map(([k, v]) => `   - **${k}**: ${v}`).join('\n');

  const prompt = `Synthesize a professional, fully-formatted legal draft for Pakistan legal services:
- **Draft Type**: ${draftingTemplates[docType] || docType}
- **Language**: ${language === 'ur' ? 'Elegant Urdu (قوانین کے مطابق اردو)' : 'Formal English (with Court headings)'}
- **Input Variables & Case Specifications**:
${fieldsSummary}

REQUIREMENTS FOR FORMATTING & DESIGN:
1. Include high-quality formal court headings (e.g. IN THE HIGH COURT OF SINDH, AT KARACHI, or IN THE COURT OF CIVIL JUDGE, LAHORE).
2. Proper structural divisions (Parties, Title of Case, Respectfully Sheweth, Ground Facts, Prayer section).
3. Insert relevant statutory clauses and citations of PPC, CrPC, CPC, or Pakistan Acts that support this claim automatically.
4. Leave placeholders in [brackets] for signature blocks, dates, and counsel details so the lawyer can customize immediately.
5. Provide the draft directly, inside a clean Markdown layout. Keep it incredibly authentic and legally solid. Start directly with the court paper structure.`;

  try {
    const ai = getGeminiClient();
    const system = `${LEGAL_SYSTEM_INSTRUCTION}
You are an expert draftsman. You output highly formal legal petitions, plaints, and written notices conforming to civil, criminal, and constitutional requirements of Pakistan's superior and lower courts.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: system,
        temperature: 0.25,
      }
    });

    const draftText = response.text || 'معذرت، ڈرافٹ تیار کرنے میں ناکامی ہوئی۔';
    return res.json({ draft: draftText });

  } catch (error: any) {
    console.error('Drafting generation error:', error);
    return res.status(500).json({ error: 'ڈرافٹ کی تیاری مینوئل فیلئر: ' + error.message });
  }
});

// ADMIN API: Get users list (Restricted to admin role users, verify here)
app.get('/api/admin/users', (req, res) => {
  const db = readDB();
  return res.json(db.users);
});

// ADMIN API: Update status (Approve user)
app.post('/api/admin/users/:id/approve', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  user.status = 'approved';
  writeDB(db);
  return res.json({ success: true, user });
});

// ADMIN API: Update status (Block user)
app.post('/api/admin/users/:id/block', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  user.status = 'blocked';
  writeDB(db);
  return res.json({ success: true, user });
});

// ADMIN API: Update status (Unblock user)
app.post('/api/admin/users/:id/unblock', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  user.status = 'approved';
  writeDB(db);
  return res.json({ success: true, user });
});

// ADMIN API: Promote to Admin
app.post('/api/admin/users/:id/promote', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  user.role = 'admin';
  user.status = 'approved'; // Promoted admins get auto-approved
  writeDB(db);
  return res.json({ success: true, user });
});

// ADMIN API: Demote from Admin
app.post('/api/admin/users/:id/demote', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  user.role = 'user';
  writeDB(db);
  return res.json({ success: true, user });
});

// ADMIN API: Delete user
app.post('/api/admin/users/:id/delete', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const initialLength = db.users.length;
  db.users = db.users.filter(u => u.id !== id);
  if (db.users.length === initialLength) {
    return res.status(404).json({ error: 'User not found' });
  }
  writeDB(db);
  return res.json({ success: true });
});

// ADMIN API: Update user settings (quota, notes, verified advocate status, license card, block status, roles)
app.post('/api/admin/users/:id/update', (req, res) => {
  const { id } = req.params;
  const { queryQuota, queriesUsed, notes, isVerifiedAdvocate, lawLicenseNumber, name, email, status, role } = req.body;
  const db = readDB();
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (name !== undefined) user.name = name;
  if (email !== undefined) user.email = email;
  if (status !== undefined) user.status = status;
  if (role !== undefined) user.role = role;
  if (queryQuota !== undefined) user.queryQuota = Number(queryQuota);
  if (queriesUsed !== undefined) user.queriesUsed = Number(queriesUsed);
  if (notes !== undefined) user.notes = notes;
  if (isVerifiedAdvocate !== undefined) user.isVerifiedAdvocate = Boolean(isVerifiedAdvocate);
  if (lawLicenseNumber !== undefined) user.lawLicenseNumber = lawLicenseNumber;

  writeDB(db);
  return res.json({ success: true, user });
});

// ADMIN API: Create notice (Push notification)
app.post('/api/admin/notifications', (req, res) => {
  const { title, message } = req.body;
  if (!title || !message) {
    return res.status(400).json({ error: 'عنوان اور پیغام ضروری ہیں۔' });
  }

  const db = readDB();
  const newNotif = {
    id: 'notif-' + Date.now(),
    title,
    message,
    createdAt: new Date().toISOString()
  };

  db.notifications.unshift(newNotif);
  writeDB(db);
  return res.json({ success: true, notification: newNotif });
});

// Public Endpoint: Retrieve current announcements/notifications
app.get('/api/notifications', (req, res) => {
  const db = readDB();
  return res.json(db.notifications || []);
});

// ====== VITE MIDDLEWARE SETUP FOR SERVER / STATIC ROUTES ======
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Justice Legal AI Assistant is listening on http://localhost:${PORT}`);
  });
}

startServer();
