/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Mail, Lock, User, Scale, Eye, EyeOff } from 'lucide-react';
import { User as UserType } from '../types';

interface AuthModalProps {
  onAuthSuccess: (user: UserType | null) => void;
  onClose?: () => void;
  isOpen: boolean;
}

export default function AuthModal({ onAuthSuccess, onClose, isOpen }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const url = isLogin ? '/api/auth/login' : '/api/auth/register';
    const body = isLogin 
      ? { email, password }
      : { email, name, password };

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'کچھ غلط ہو گیا تھا۔ دوبارہ کوشش کریں۔');
      }

      onAuthSuccess(data.user);
      if (onClose) onClose();
    } catch (err: any) {
      setError(err.message || 'کنکشن کا مسئلہ پیش آیا۔');
    } finally {
      setLoading(false);
    }
  };

  const handleGuestMode = () => {
    onAuthSuccess(null); // null designates guest mode
    if (onClose) onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-md overflow-hidden bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl shadow-2xl animate-fade-in text-right">
        {/* Decorative Top Accent */}
        <div className="h-2 bg-gradient-to-r from-emerald-600 via-stone-800 to-emerald-700"></div>

        <div className="p-6">
          {/* Logo Heading */}
          <div className="flex flex-col items-center mb-6 text-center">
            <div 
              className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-750 dark:text-emerald-400 rounded-full mb-3 shadow-inner"
            >
              <Scale size={32} />
            </div>
            <h2 className="text-xl font-bold tracking-tight text-stone-800 dark:text-stone-100 font-sans">
              جسٹس لیگل AI اسسٹنٹ
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 font-urdu">
              پاکستان کا قابلِ بھروسہ قانونی مشیر و ڈرافٹنگ پارٹنر
            </p>
          </div>

          {error && (
            <div className="p-3 mb-4 text-sm text-red-600 bg-red-50 dark:bg-red-950/20 dark:text-red-400 border border-red-200 dark:border-red-900/30 rounded-lg text-center font-sans">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1 font-urdu text-right">
                  صارف کا نام (Full Name)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-stone-400">
                    <User size={16} />
                  </span>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="اپنا پورا نام درج کریں"
                    className="w-full py-2 pl-10 pr-4 text-sm bg-stone-55 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans text-left"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1 font-urdu text-right text-right">
                ای میل ایڈریس (Email Address)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-stone-400">
                  <Mail size={16} />
                </span>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full py-2 pl-10 pr-4 text-sm bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans text-left"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1 font-urdu text-right">
                پاس ورڈ (Password)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-stone-400">
                  <Lock size={16} />
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full py-2 pl-10 pr-10 text-sm bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans text-left"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 cursor-pointer"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 font-semibold text-white bg-emerald-700 hover:bg-emerald-850 dark:bg-emerald-800 dark:hover:bg-emerald-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 hover:-translate-y-0.5 active:translate-y-0 transition-all font-urdu text-sm cursor-pointer"
            >
              {loading ? 'پروسیسنگ...' : isLogin ? 'لاگ ان کریں' : 'اکاؤنٹ بنائیں'}
            </button>
          </form>

          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => {
                setIsLogin(!isLogin);
                setError('');
              }}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300 font-urdu cursor-pointer"
            >
              {isLogin ? 'نیا اکاؤنٹ بنانا چاہتے ہیں؟ رجسٹریشن کریں' : 'پہلے سے اکاؤنٹ ہے؟ لاگ ان کریں'}
            </button>
          </div>

          {/* Guest Mode Divider */}
          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-stone-200 dark:border-stone-800"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="px-2 bg-white dark:bg-stone-900 text-stone-400 dark:text-stone-500 font-urdu">
                یا پھر
              </span>
            </div>
          </div>

          {/* Guest Button */}
          <button
            type="button"
            onClick={handleGuestMode}
            className="w-full py-2 px-4 text-xs font-semibold text-stone-600 dark:text-stone-300 border border-stone-300 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-850 rounded-xl transition-all font-urdu text-center cursor-pointer"
          >
            مہمان موڈ میں جاری رکھیں (Guest Portal)
          </button>
        </div>
      </div>
    </div>
  );
}
