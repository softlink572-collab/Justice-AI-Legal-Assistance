/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Scale, Award, FolderHeart, FileText, ShieldAlert, CheckSquare, PlusSquare, ChevronLeft, X, LogOut, PenTool, Smartphone, LogIn, User as UserIcon } from 'lucide-react';
import { User } from '../types';

interface LeftSidebarProps {
  currentUser: User | null;
  activeCategory: string | null;
  onSelectCategory: (category: string | null) => void;
  onNavigateToDraft: () => void;
  onNavigateToAdmin: () => void;
  onNavigateToStamps: () => void;
  onNavigateToApk: () => void;
  activeTab: 'chat' | 'draft' | 'stamps' | 'apk' | 'admin';
  isOpen?: boolean;
  onClose?: () => void;
  onLogout?: () => void;
  onLoginClick?: () => void;
}

export default function LeftSidebar({
  currentUser,
  activeCategory,
  onSelectCategory,
  onNavigateToDraft,
  onNavigateToAdmin,
  onNavigateToStamps,
  onNavigateToApk,
  activeTab,
  isOpen,
  onClose,
  onLogout,
  onLoginClick
}: LeftSidebarProps) {
  const isAdmin = currentUser?.role === 'admin';

  const DRAFT_CATEGORIES = [
    { id: 'criminal_petition', name: 'فوجداری درخواستوں کے مسودے', nameEn: 'Criminal Petitions', icon: <Scale size={15} /> },
    { id: 'civil_petition', name: 'دیوانی درخواستوں کے مسودے', nameEn: 'Civil Petitions', icon: <BookOpen size={15} /> },
    { id: 'criminal_draft', name: 'فوجداری ڈرافٹنگ مسودے', nameEn: 'Criminal Drafting', icon: <FileText size={15} /> },
    { id: 'civil_draft', name: 'سول ڈرافٹنگ مسودے', nameEn: 'Civil Drafting', icon: <Award size={15} /> },
    { id: 'family_draft', name: 'فیملی ڈرافٹنگ مسودے', nameEn: 'Family Drafting', icon: <FolderHeart size={15} /> }
  ];

  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/50 backdrop-blur-xs z-50 lg:hidden"
        ></div>
      )}

      {/* Left Sidebar Main container */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-64 border-r border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex flex-col justify-between transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } shrink-0 lg:flex`}
      >
        
        {/* Header Title */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-100/50 dark:bg-slate-900/40 shrink-0">
          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-650 dark:hover:text-slate-200 transition-all cursor-pointer"
            >
              <X size={16} />
            </button>
          )}
          
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <h2 className="text-xs font-bold text-stone-500 dark:text-stone-400 font-sans tracking-widest uppercase">
              Drafts & Workspace
            </h2>
            <span className="text-[10px] text-emerald-700 dark:text-emerald-450 font-urdu mt-1 font-semibold leading-tight">
              قانونی مسودات و ذیلی کٹیگریز
            </span>
          </div>
        </div>

        {/* Content Section - Template categories */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          
          {/* Drafting Templates categories block */}
          <div className="space-y-1.5">
            <span className="px-3 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2 font-sans text-right">
              درخواستوں کی کٹیگریز (Templates)
            </span>

            {DRAFT_CATEGORIES.map((cat) => {
              const isActive = activeTab === 'draft' && activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    onSelectCategory(cat.id);
                    onNavigateToDraft();
                    if (onClose) onClose();
                  }}
                  className={`w-full py-2 px-3.5 rounded-xl flex items-center justify-between transition-all text-right font-urdu text-xs cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-700/10 font-medium'
                      : 'hover:bg-slate-200/50 dark:hover:bg-slate-800 text-slate-705 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800'
                  }`}
                >
                  <span className="text-[10px] font-mono opacity-60">
                    {isActive ? <ChevronLeft size={10} className="text-white" /> : cat.nameEn}
                  </span>
                  
                  <div className="flex items-center gap-2.5 justify-end">
                    <span>{cat.name}</span>
                    <span className={isActive ? 'text-white' : 'text-emerald-700 dark:text-emerald-400'}>
                      {cat.icon}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* New Workspace Tools segment */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-850 space-y-1.5">
            <span className="px-3 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2 font-sans text-right">
              خصوصی عدالتی ٹولز (Workspace Tools)
            </span>

            {/* Stamps & Seal creator trigger */}
            <button
              onClick={() => {
                onSelectCategory(null);
                onNavigateToStamps();
                if (onClose) onClose();
              }}
              className={`w-full py-2.5 px-3.5 rounded-xl flex items-center justify-between transition-all text-right font-urdu text-xs cursor-pointer ${
                activeTab === 'stamps'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-700/10 font-bold'
                  : 'hover:bg-slate-200/50 dark:hover:bg-slate-800 text-slate-705 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800'
              }`}
            >
              <span className="text-[10px] font-mono opacity-60">
                {activeTab === 'stamps' ? <ChevronLeft size={10} className="text-white" /> : 'STAMPS'}
              </span>
              <div className="flex items-center gap-2.5 justify-end">
                <span>عدالتی مہر و اسٹامپ میکر</span>
                <PenTool size={14} className={activeTab === 'stamps' ? 'text-white' : 'text-emerald-700 dark:text-emerald-400'} />
              </div>
            </button>

            {/* Mobile App APK Creator trigger */}
            <button
              onClick={() => {
                onSelectCategory(null);
                onNavigateToApk();
                if (onClose) onClose();
              }}
              className={`w-full py-2.5 px-3.5 rounded-xl flex items-center justify-between transition-all text-right font-urdu text-xs cursor-pointer ${
                activeTab === 'apk'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-700/10 font-bold'
                  : 'hover:bg-slate-200/50 dark:hover:bg-slate-800 text-slate-705 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800'
              }`}
            >
              <span className="text-[10px] font-mono opacity-60">
                {activeTab === 'apk' ? <ChevronLeft size={10} className="text-white" /> : 'ANDROID'}
              </span>
              <div className="flex items-center gap-2.5 justify-end">
                <span>موبائل ایپ اے پی کے (APK)</span>
                <Smartphone size={14} className={activeTab === 'apk' ? 'text-white' : 'text-blue-700 dark:text-blue-400'} />
              </div>
            </button>
          </div>

          {/* Admin Powers Menu section as requested */}
          {isAdmin && (
            <div className="pt-3 border-t border-slate-200 dark:border-slate-850 space-y-2">
              <span className="px-3 text-[10px] font-bold text-red-500 dark:text-red-450 uppercase tracking-widest block mb-1 font-sans flex items-center gap-1 justify-end">
                <ShieldAlert size={10} />
                ایڈمنسٹریٹر موڈ اختیارات
              </span>

              <button
                onClick={() => {
                  onSelectCategory(null);
                  onNavigateToAdmin();
                  if (onClose) onClose();
                }}
                className={`w-full py-2.5 px-3.5 rounded-xl flex items-center justify-between transition-all text-right font-urdu text-xs cursor-pointer ${
                  activeTab === 'admin'
                    ? 'bg-red-700 text-white shadow-md shadow-red-800/10 font-medium'
                    : 'bg-red-500/10 hover:bg-red-500/15 text-red-700 dark:text-red-400 border border-red-500/20'
                }`}
              >
                <span className="text-[9px] font-mono opacity-70">ADMIN</span>
                <span className="font-semibold">صارفین اور قوانین مینیجمنٹ</span>
              </button>
              
              <div className="px-2 py-1.5 bg-stone-55 dark:bg-stone-900/40 rounded-xl space-y-1.5 border border-stone-200/50 dark:border-stone-800/50">
                <div className="flex items-center gap-1.5 text-[10px] text-stone-500 dark:text-stone-400 font-urdu justify-end">
                  <span>صارفین منظوری دائرہ کار</span>
                  <CheckSquare size={11} className="text-emerald-600" />
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-stone-500 dark:text-stone-400 font-urdu justify-end">
                  <span>براڈکاسٹ سسٹم نوٹس</span>
                  <PlusSquare size={11} className="text-emerald-600" />
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer Credit Tag inside LeftSidebar */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-900 text-center space-y-3 shrink-0">
          
          {/* User state section (Login & Logout features in the left menu) */}
          <div className="border-b border-slate-200/60 dark:border-slate-800/60 pb-3 mb-2 text-right">
            {currentUser ? (
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 justify-end">
                  <div className="text-right min-w-0">
                    <p className="text-xs font-bold font-sans text-slate-800 dark:text-slate-150 truncate leading-none">
                      {currentUser.name}
                    </p>
                    <p className="text-[9px] text-emerald-700 dark:text-emerald-400 font-mono mt-1 lowercase tracking-wide font-semibold">
                      {currentUser.role} • {currentUser.status}
                    </p>
                  </div>
                  <div className="w-7 h-7 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-750 dark:text-emerald-400 rounded-lg flex items-center justify-center shrink-0">
                    <UserIcon size={14} />
                  </div>
                </div>

                <button
                  onClick={onLogout}
                  className="w-full py-1.5 px-3 bg-red-650 hover:bg-red-750 dark:bg-red-950/60 dark:hover:bg-red-900 text-white rounded-xl text-xs font-urdu font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                >
                  <LogOut size={11} />
                  <span>لاگ آؤٹ</span>
                </button>
              </div>
            ) : (
              <div className="space-y-1.5">
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-urdu text-center leading-tight">
                  محفوظ تاریخ کے لیے سائن ان کریں
                </p>
                {onLoginClick && (
                  <button
                    onClick={onLoginClick}
                    className="w-full py-1.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-urdu font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                  >
                    <LogIn size={11} />
                    <span>لاگ ان (Sign In)</span>
                  </button>
                )}
              </div>
            )}
          </div>

          <div>
            <div className="text-[11px] font-bold text-slate-800 dark:text-slate-100 font-sans tracking-wide">
              JUSTICE LAW ASSOCIATES
            </div>
            <p className="text-[10px] text-emerald-750 dark:text-emerald-400 font-sans font-bold leading-tight mt-1">
              Syed Azhar Hussain Sabzwari
              <br />
              <span className="text-[8px] text-slate-400 font-mono font-medium">Advocate High Court</span>
            </p>
          </div>
        </div>

      </div>
    </>
  );
}
