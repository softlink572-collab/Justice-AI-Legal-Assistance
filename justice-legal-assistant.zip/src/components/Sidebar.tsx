/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, MessageSquare, Trash2, LogOut, User, Shield, Bell, X, LogIn } from 'lucide-react';
import { Thread, User as UserType, SystemNotification } from '../types';

interface SidebarProps {
  threads: Thread[];
  activeThreadId: string | null;
  onSelectThread: (id: string) => void;
  onNewThread: () => void;
  onDeleteThread: (id: string) => void;
  currentUser: UserType | null;
  onLogout: () => void;
  onLoginClick: () => void;
  onNavigateToChat: () => void;
  activeTab: 'chat' | 'draft' | 'admin';
  notifications: SystemNotification[];
  isOpen?: boolean;
  onClose?: () => void;
}

export default function Sidebar({
  threads,
  activeThreadId,
  onSelectThread,
  onNewThread,
  onDeleteThread,
  currentUser,
  onLogout,
  onLoginClick,
  onNavigateToChat,
  activeTab,
  notifications,
  isOpen,
  onClose
}: SidebarProps) {
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/50 backdrop-blur-xs z-50 lg:hidden"
        ></div>
      )}

      {/* Main Right Sidebar Wrapper */}
      <div
        className={`fixed inset-y-0 right-0 z-50 w-64 border-l border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex flex-col justify-between transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        } shrink-0 lg:flex`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-100/50 dark:bg-slate-900/40 shrink-0">
          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-650 dark:hover:text-slate-200 transition-all cursor-pointer"
            >
              <X size={16} />
            </button>
          )}

          <div className="flex items-center gap-2 text-emerald-750 dark:text-emerald-400 font-bold text-base ml-auto">
            <span className="font-urdu text-xs">قانونی مکالمات و ہسٹری</span>
            <div className="w-7 h-7 bg-emerald-700 rounded-lg flex items-center justify-center text-white font-bold text-base font-sans">⚖️</div>
          </div>
        </div>

        {/* Dynamic Action Buttons */}
        <div className="p-4 pb-2 space-y-2 shrink-0">
          <button
            onClick={() => {
              onNewThread();
              onNavigateToChat();
              if (onClose) onClose();
            }}
            className="w-full py-2.5 px-4 bg-emerald-700 text-white rounded-xl shadow-xs hover:bg-emerald-850 text-xs flex items-center gap-2 justify-center font-urdu active:scale-98 transition-all cursor-pointer hover:border-emerald-500"
          >
            <Plus size={14} className="text-white" />
            نیا چیٹ رائیٹر (New Chat)
          </button>
        </div>

        {/* Chat History List (Threads) - Always remember history */}
        <div className="flex-1 overflow-y-auto px-2 py-3 space-y-1">
          <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-sans text-right">
            محفوظ مکالمات کی یادداشت
          </div>

          {threads.length === 0 ? (
            <div className="text-center py-8 text-slate-400 dark:text-slate-500 space-y-1">
              <p className="text-[11px] font-urdu leading-tight">کوئی سابقہ چیٹ موجود نہیں ہے۔</p>
              <p className="text-[9px] font-sans text-slate-400/70">Start a chat to save history</p>
            </div>
          ) : (
            threads.map((thr) => {
              const isActive = thr.id === activeThreadId && activeTab === 'chat';
              return (
                <div
                  key={thr.id}
                  className={`group relative w-full rounded-xl flex items-center transition-all ${
                    isActive
                      ? 'bg-emerald-500/10 dark:bg-emerald-950/40 text-emerald-850 dark:text-emerald-300 border-r-4 border-emerald-600 font-medium'
                      : 'hover:bg-slate-200/50 dark:hover:bg-slate-900 text-slate-650 dark:text-slate-405'
                  }`}
                >
                  {/* Delete trigger */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteThread(thr.id);
                    }}
                    className="absolute left-2.5 opacity-0 group-hover:opacity-100 p-1 hover:text-red-500 dark:hover:text-red-400 rounded-lg transition-all z-10 cursor-pointer"
                    title="مٹائيں"
                  >
                    <Trash2 size={12} />
                  </button>

                  <button
                    onClick={() => {
                      onSelectThread(thr.id);
                      onNavigateToChat();
                      if (onClose) onClose();
                    }}
                    className="flex-1 text-right py-2 pl-8 pr-3 text-xs overflow-hidden text-ellipsis whitespace-nowrap min-w-0 cursor-pointer"
                  >
                    <div className="font-urdu text-right text-xs truncate" dir="rtl">
                      {thr.title}
                    </div>
                  </button>
                  
                  {/* Chat Icon right */}
                  <span className="absolute right-3 top-2.5 opacity-60">
                    <MessageSquare size={12} />
                  </span>
                </div>
              );
            })
          )}
        </div>

        {/* System Announcements Block */}
        {notifications.length > 0 && (
          <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-emerald-500/5 shrink-0">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="w-full flex justify-between items-center text-[10px] text-emerald-850 dark:text-emerald-400 hover:underline font-urdu cursor-pointer"
            >
              <span className="text-[9px] font-sans">View</span>
              <span className="flex items-center gap-1.5 ml-auto">
                ایڈمن اعلانات ({notifications.length})
                <Bell size={11} className="text-emerald-600" />
              </span>
            </button>
          </div>
        )}

        {/* User Card & Action Area - Login history and info */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-900 flex flex-col gap-2 shrink-0">
          {currentUser ? (
            <div className="flex items-center justify-between gap-1.5">
              <button
                onClick={onLogout}
                className="p-1 px-2.5 bg-slate-250/70 hover:bg-slate-300/80 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-650 dark:text-slate-300 rounded-xl hover:text-red-500 dark:hover:text-red-400 transition-all text-[11px] font-urdu cursor-pointer"
                title="لاگ آؤٹ"
              >
                لاگ آؤٹ
              </button>

              <div className="min-w-0 flex-1 text-right">
                <div className="text-xs font-semibold text-slate-850 dark:text-slate-100 truncate font-sans">
                  {currentUser.name}
                </div>
                <div className="text-[9px] text-slate-450 font-mono truncate mt-0.5">
                  <span className="px-1 py-0.2 bg-emerald-500/10 text-emerald-600 rounded text-[8px] font-bold uppercase">{currentUser.status}</span>
                </div>
              </div>

              <div className="p-2 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 rounded-lg">
                {currentUser.role === 'admin' ? <Shield size={16} /> : <User size={16} />}
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-[10px] text-stone-400 font-urdu text-center leading-tight">
                محفوظ تاریخ اور اضافی اختیارات کے لیے اکاؤنٹ میں داخل ہوں
              </p>
              <button
                onClick={onLoginClick}
                className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-urdu flex items-center justify-center gap-1.5 transition-all font-semibold cursor-pointer shadow-xs active:scale-98"
              >
                <LogIn size={13} />
                لاگ ان / رجسٹریشن کریں
              </button>
            </div>
          )}
        </div>

      </div>

      {/* Announcements Slider Overlay */}
      {showNotifications && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-5 mt-16 animate-fade-in relative text-right">
            <button
              onClick={() => setShowNotifications(false)}
              className="absolute top-4 left-4 p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 cursor-pointer"
            >
              <X size={16} />
            </button>
            <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-bold font-urdu text-sm mb-4 justify-end">
              ایڈمن کی جانب سے نوٹیفکیشنز
              <Bell size={18} />
            </div>

            <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1">
              {notifications.map((notif) => (
                <div key={notif.id} className="p-3 bg-slate-50 dark:bg-slate-850 border border-slate-200/50 dark:border-slate-800 rounded-xl space-y-1">
                  <div className="font-semibold text-xs text-slate-850 dark:text-slate-205 font-urdu">{notif.title}</div>
                  <p className="text-xs text-slate-550 dark:text-slate-400 leading-relaxed font-urdu">{notif.message}</p>
                  <div className="text-[8px] text-slate-400 font-mono text-left mt-1">
                    {new Date(notif.createdAt).toLocaleString('ur-PK')}
                  </div>
                </div>
              ))}
            </div>
            
            <button
              onClick={() => setShowNotifications(false)}
              className="mt-4 w-full py-1 px-3 text-xs text-slate-500 dark:text-slate-400 text-center hover:underline font-urdu cursor-pointer"
            >
              بند کریں
            </button>
          </div>
        </div>
      )}
    </>
  );
}
