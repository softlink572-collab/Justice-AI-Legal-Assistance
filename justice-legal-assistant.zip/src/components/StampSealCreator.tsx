/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { Award, Download, RefreshCw, PenTool, Clipboard, Check, Paintbrush, Scale, Layers, HelpCircle, Palette } from 'lucide-react';

export default function StampSealCreator() {
  const [activeSubTab, setActiveSubTab] = useState<'round_seal' | 'rect_stamp' | 'estamp' | 'esign'>('round_seal');
  
  // Custom states for Round Rubber Seal
  const [advocateName, setAdvocateName] = useState('سید اظہر حسین سبزواری');
  const [advocateTitle, setAdvocateTitle] = useState('ایڈوکیٹ ہائی کورٹ');
  const [licenseNo, setLicenseNo] = useState('HC-7865-LHR');
  const [city, setCity] = useState('لاہور');
  const [sealColor, setSealColor] = useState('#0254a3'); // Blue ink, customizable
  const [bleedAmt, setBleedAmt] = useState(3); // Ink-bleed authenticity adjustment
  const [borderType, setBorderType] = useState<'solid' | 'dashed' | 'double'>('double');

  // Custom states for Court Rectangular Stamp
  const [courtName, setCourtName] = useState('عدالت عالیہ سول سروسز، لاہور');
  const [stampStatus, setStampStatus] = useState('نقلِ مطابقِ اصل / CERTIFIED TRUE COPY');
  const [officerSignName, setOfficerSignName] = useState('رائے زاہد حسین ایڈمنسٹریٹر');
  const [stampDate, setStampDate] = useState(new Date().toISOString().substring(0, 10));
  const [stampColor, setStampColor] = useState('#b91c1c'); // Red ink default

  // Custom states for E-Stamp Paper Header
  const [stampValue, setStampValue] = useState('500');
  const [eTicketCode, setETicketCode] = useState('PB-LHR-2026-987413');
  const [firstParty, setFirstParty] = useState('عمران خان بن محمد بخش');
  const [secondParty, setSecondParty] = useState('جسٹس لاء ایسوسی ایٹس');
  const [estampDate, setEstampDate] = useState(new Date().toISOString().substring(0, 10));

  // Refs for drawing canvases
  const roundSealCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const rectStampCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const estampCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const esignCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // E-Signature Pad drawing states
  const [isDrawing, setIsDrawing] = useState(false);
  const [esignColor, setEsignColor] = useState('#000000');
  const [esignWidth, setEsignWidth] = useState(3);
  const [hasDrawn, setHasDrawn] = useState(false);

  const [copiedText, setCopiedText] = useState(false);

  // Drawing the Round Rubber Seal
  const drawRoundSeal = () => {
    const canvas = roundSealCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear and reset canvas for ultra crisp retina rendering
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Transparent background for PNG export
    ctx.fillStyle = 'rgba(0,0,0,0)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const radius = 135;

    // Direct shadow/blur representing rubber ink bleed authenticity
    ctx.shadowColor = sealColor;
    ctx.shadowBlur = bleedAmt;

    ctx.strokeStyle = sealColor;
    ctx.fillStyle = sealColor;

    // Draw OUTER borders
    if (borderType === 'double') {
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();

      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, radius - 6, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      ctx.lineWidth = 4;
      if (borderType === 'dashed') {
        ctx.setLineDash([8, 6]);
      } else {
        ctx.setLineDash([]);
      }
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Inner circle
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, radius - 35, 0, Math.PI * 2);
    ctx.stroke();

    // Render scales of justice or star emblem in the center
    ctx.font = '28px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('⚖', cx, cy - 12);

    ctx.font = 'bold 13px sans-serif';
    ctx.fillText(licenseNo, cx, cy + 22);

    // Draw Circular Text - Top Arc (Advocate Name)
    ctx.save();
    ctx.translate(cx, cy);
    const topText = advocateName.toUpperCase();
    const topArcLength = topText.length;
    // Set text radius
    const textRadiusTop = radius - 20;
    ctx.font = 'bold 15px sans-serif';
    
    // Arc calculation
    const angleRangeTop = 1.25 * Math.PI; // Total angle coverage
    const startAngleTop = -angleRangeTop / 2 - Math.PI / 2;
    const angleStepTop = angleRangeTop / (topArcLength > 1 ? topArcLength - 1 : 1);

    for (let i = 0; i < topArcLength; i++) {
      const char = topText[i];
      const angle = startAngleTop + i * angleStepTop;
      ctx.save();
      ctx.rotate(angle);
      ctx.translate(0, -textRadiusTop);
      ctx.fillText(char, 0, 0);
      ctx.restore();
    }
    ctx.restore();

    // Draw Circular Text - Bottom Arc (Advocate Title / City)
    ctx.save();
    ctx.translate(cx, cy);
    const bottomText = `${advocateTitle} - ${city}`.toUpperCase();
    const bottomArcLength = bottomText.length;
    const textRadiusBottom = radius - 20;
    ctx.font = '900 12px sans-serif';

    const angleRangeBottom = 1.25 * Math.PI;
    const startAngleBottom = -angleRangeBottom / 2 + Math.PI / 2;
    const angleStepBottom = angleRangeBottom / (bottomArcLength > 1 ? bottomArcLength - 1 : 1);

    for (let i = 0; i < bottomArcLength; i++) {
      const char = bottomText[i];
      const angle = startAngleBottom - i * angleStepBottom;
      ctx.save();
      ctx.rotate(angle);
      ctx.translate(0, textRadiusBottom);
      ctx.fillText(char, 0, 0);
      ctx.restore();
    }
    ctx.restore();

    // Apply some tiny noise pixels for realistic vintage ink stamp feel
    if (bleedAmt > 0) {
      applyStampNoise(ctx, canvas, sealColor, bleedAmt);
    }
  };

  // Rectangular stamp draw routine
  const drawRectStamp = () => {
    const canvas = rectStampCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = 'rgba(0,0,0,0)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const w = canvas.width;
    const h = canvas.height;

    ctx.shadowColor = stampColor;
    ctx.shadowBlur = bleedAmt;
    ctx.strokeStyle = stampColor;
    ctx.fillStyle = stampColor;

    // Frame border
    ctx.lineWidth = 5;
    ctx.strokeRect(20, 20, w - 40, h - 40);

    ctx.lineWidth = 1.5;
    ctx.strokeRect(27, 27, w - 54, h - 54);

    // Inner line separators
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(27, h * 0.35);
    ctx.lineTo(w - 27, h * 0.35);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(27, h * 0.68);
    ctx.lineTo(w - 27, h * 0.68);
    ctx.stroke();

    // Fill Titles
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // Top Court Line
    ctx.font = 'bold 15px sans-serif';
    ctx.fillText(courtName, w / 2, h * 0.22);

    // Center Big Status Badge
    ctx.font = '900 13px sans-serif';
    ctx.fillText(stampStatus, w / 2, h * 0.51);

    // Bottom Officer details & Date
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText(`${officerSignName} | Date: ${stampDate}`, w / 2, h * 0.81);

    // Apply authentic ink splash noise
    if (bleedAmt > 0) {
      applyStampNoise(ctx, canvas, stampColor, bleedAmt);
    }
  };

  // E-Stamp Paper Drawing Template routine
  const drawEstamp = () => {
    const canvas = estampCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Antique off-white base paper color for the E-Stamp paper
    ctx.fillStyle = '#f6fdf3';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Base background grids
    ctx.strokeStyle = '#e2ebd5';
    ctx.lineWidth = 0.5;
    for (let x = 0; x < canvas.width; x += 25) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 25) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Outer beautiful dark green royal border
    ctx.strokeStyle = '#04583d';
    ctx.lineWidth = 6;
    ctx.strokeRect(15, 15, canvas.width - 30, canvas.height - 30);

    ctx.strokeStyle = '#04583d';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(22, 22, canvas.width - 44, canvas.height - 44);

    // Header E-Stamp Banner Design
    ctx.fillStyle = '#055138';
    ctx.fillRect(30, 30, canvas.width - 60, 110);

    // White Inner Text for Banner
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    
    ctx.font = '900 12px sans-serif';
    ctx.fillText('GOVERNMENT OF PUNJAB / SINDH / PAKISTAN', canvas.width / 2, 55);

    ctx.font = 'bold 24px sans-serif';
    ctx.fillText(`SECURE E-STAMP PAPER`, canvas.width / 2, 85);

    ctx.font = '900 11px sans-serif';
    ctx.fillText('VALID FOR SUPREME COURT, HIGH COURT & LOCAL SUB-REGISTRAR SUBMISSIONS', canvas.width / 2, 115);

    // Government Star & Crescent seal (Gold styled circle)
    ctx.strokeStyle = '#f59e0b';
    ctx.fillStyle = '#f59e50';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(70, 85, 25, 0, Math.PI * 2);
    ctx.stroke();
    ctx.font = '16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('🇵🇰', 70, 85);

    // Value Block (PKR Seal)
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(canvas.width - 130, 45, 90, 80);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px sans-serif';
    ctx.fillText('VALUE RS.', canvas.width - 85, 68);
    ctx.font = '900 28px sans-serif';
    ctx.fillText(`${stampValue}/-`, canvas.width - 85, 105);

    // Body content fields
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillStyle = '#05513d';
    ctx.font = 'bold 14px sans-serif';

    // Detailed values table lines
    const startY = 170;
    const gap = 38;

    ctx.fillText('E-TICKET REF:', 45, startY);
    ctx.fillText('FIRST PARTY / COMPLAINANT:', 45, startY + gap);
    ctx.fillText('SECOND PARTY / RESPONDENT:', 45, startY + gap * 2);
    ctx.fillText('EMISSION DATE / VALIDITY:', 45, startY + gap * 3);
    ctx.fillText('STAMP DUTY FEES PAID (PKR):', 45, startY + gap * 4);

    // Input values mapping
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 14px sans-serif';
    ctx.fillText(eTicketCode, 280, startY);
    ctx.fillText(firstParty, 280, startY + gap);
    ctx.fillText(secondParty, 280, startY + gap * 2);
    ctx.fillText(estampDate, 280, startY + gap * 3);
    ctx.fillText(`Rs. ${stampValue} Rupees Only`, 280, startY + gap * 4);

    // Barcode rendering representation
    ctx.fillStyle = '#055138';
    ctx.strokeRect(40, canvas.height - 85, canvas.width - 80, 50);

    // Draw dummy lines for barcode barcode
    ctx.fillStyle = '#000000';
    let lineX = 65;
    while (lineX < canvas.width - 65) {
      const lineWidth = Math.random() > 0.4 ? (Math.random() > 0.5 ? 4 : 2) : 1;
      ctx.fillRect(lineX, canvas.height - 80, lineWidth, 40);
      lineX += lineWidth + (Math.random() > 0.5 ? 2 : 4);
    }
  };

  // Draw simulation noisy dots for vintage ink rubber stamp effect
  const applyStampNoise = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, inkColor: string, bleed: number) => {
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;

    // Inject randomness on colored pixel borders representing porous rubber bleeding
    for (let i = 0; i < data.length; i += 4) {
      const alpha = data[i + 3];
      if (alpha > 50) {
        // Pixel is part of the stamp artwork
        const rand = (Math.random() - 0.5) * 45 * bleed;
        data[i + 3] = Math.max(0, Math.min(255, alpha - Math.random() * 50)); // Random fade
        
        // Random dot spill outward
        if (Math.random() > 0.94) {
          const shift = Math.floor((Math.random() - 0.5) * 40 * bleed);
          const shadowIndex = i + shift * 4;
          if (shadowIndex >= 0 && shadowIndex < data.length) {
            data[shadowIndex] = data[i]; // red
            data[shadowIndex + 1] = data[i + 1]; // green
            data[shadowIndex + 2] = data[i + 2]; // blue
            data[shadowIndex + 3] = 120; // translucent splash
          }
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);
  };

  // Re-draw triggers on dependency updates
  useEffect(() => {
    if (activeSubTab === 'round_seal') {
      drawRoundSeal();
    } else if (activeSubTab === 'rect_stamp') {
      drawRectStamp();
    } else if (activeSubTab === 'estamp') {
      drawEstamp();
    }
  }, [
    activeSubTab,
    advocateName,
    advocateTitle,
    licenseNo,
    city,
    sealColor,
    bleedAmt,
    borderType,
    courtName,
    stampStatus,
    officerSignName,
    stampDate,
    stampColor,
    stampValue,
    eTicketCode,
    firstParty,
    secondParty,
    estampDate
  ]);

  // E-Signature Pad Draw Handlers
  const handleSignatureStart = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = esignCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = esignColor;
    ctx.lineWidth = esignWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const pos = getCoordinate(e, canvas);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    setIsDrawing(true);
    setHasDrawn(true);
  };

  const handleSignatureDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = esignCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pos = getCoordinate(e, canvas);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
  };

  const handleSignatureEnd = () => {
    setIsDrawing(false);
  };

  const getCoordinate = (e: any, canvas: HTMLCanvasElement) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if (e.touches && e.touches[0]) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY
      };
    } else {
      return {
        x: (e.clientX - rect.left) * scaleX,
        y: (e.clientY - rect.top) * scaleY
      };
    }
  };

  const clearEsignPad = () => {
    const canvas = esignCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
  };

  // Universal Downloader for finished graphic assets
  const downloadAsset = (tab: typeof activeSubTab) => {
    let canvas: HTMLCanvasElement | null = null;
    let fileName = '';

    if (tab === 'round_seal') {
      canvas = roundSealCanvasRef.current;
      fileName = `Advocate_Round_Seal_${licenseNo}.png`;
    } else if (tab === 'rect_stamp') {
      canvas = rectStampCanvasRef.current;
      fileName = `Court_Duty_Stamp.png`;
    } else if (tab === 'estamp') {
      canvas = estampCanvasRef.current;
      fileName = `Estamp_Duty_Paper_${eTicketCode}.png`;
    } else if (tab === 'esign') {
      canvas = esignCanvasRef.current;
      fileName = `Advocate_Digital_E_Signature.png`;
    }

    if (!canvas) return;
    
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = fileName;
    link.href = url;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full h-full p-2 lg:p-6 overflow-y-auto max-h-[calc(100vh-100px)]">
      {/* Intro banner */}
      <div className="mb-6 bg-emerald-600/10 border border-emerald-500/10 p-4 lg:p-5 rounded-2xl flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex items-center gap-3 text-right shrink-0">
          <div className="p-3 bg-emerald-600/15 text-emerald-700 dark:text-emerald-400 rounded-xl">
            <PenTool size={22} />
          </div>
          <div className="text-right">
            <h2 className="text-base font-extrabold text-stone-800 dark:text-stone-100 font-urdu">مہر، اسٹامپ اور ای-دستخط میکر پورٹل</h2>
            <p className="text-xs text-stone-500 dark:text-stone-400 font-urdu mt-0.5">عدالتی اسٹامپ پیپرز، وکیلوں کی آفیشل گول مہریں، عدالتی موصولہ اسٹامپ اور ہائی ڈیفینیشن دستخط تیار کیجئے</p>
          </div>
        </div>
        <span className="text-[10px] bg-emerald-700 text-white font-mono px-3 py-1 rounded-full uppercase font-bold tracking-widest">
          Legal Graphics Hub
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Side menu togglers */}
        <div className="lg:col-span-4 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-4 rounded-2xl shadow-sm space-y-3.5">
          <div className="flex items-center gap-2 border-b border-stone-100 dark:border-stone-800 pb-2 mb-2 justify-end">
            <span className="text-xs font-bold text-stone-600 dark:text-stone-300 font-urdu">مطلوبہ گرافک اثاثہ منتخب کریں:</span>
            <Palette size={14} className="text-emerald-700 dark:text-emerald-400" />
          </div>

          <div className="space-y-2">
            <button
              onClick={() => setActiveSubTab('round_seal')}
              className={`w-full py-3 px-4 text-xs font-urdu font-bold rounded-xl border transition-all text-right flex items-center justify-between cursor-pointer ${
                activeSubTab === 'round_seal'
                  ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                  : 'hover:bg-stone-50 dark:hover:bg-stone-800 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
              }`}
            >
              <div className="w-4 h-4 rounded-full border border-current flex items-center justify-center shrink-0">
                <span className="text-[9px] font-bold">1</span>
              </div>
              <span>وکیل مہر میکر (Advocate Round Seal)</span>
            </button>

            <button
              onClick={() => setActiveSubTab('rect_stamp')}
              className={`w-full py-3 px-4 text-xs font-urdu font-bold rounded-xl border transition-all text-right flex items-center justify-between cursor-pointer ${
                activeSubTab === 'rect_stamp'
                  ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                  : 'hover:bg-stone-50 dark:hover:bg-stone-800 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
              }`}
            >
              <div className="w-4 h-4 rounded-full border border-current flex items-center justify-center shrink-0">
                <span className="text-[9px] font-bold">2</span>
              </div>
              <span>عدالتی موصولہ مہر (Court Receipt Stamp)</span>
            </button>

            <button
              onClick={() => setActiveSubTab('estamp')}
              className={`w-full py-3 px-4 text-xs font-urdu font-bold rounded-xl border transition-all text-right flex items-center justify-between cursor-pointer ${
                activeSubTab === 'estamp'
                  ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                  : 'hover:bg-stone-50 dark:hover:bg-stone-800 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
              }`}
            >
              <div className="w-4 h-4 rounded-full border border-current flex items-center justify-center shrink-0">
                <span className="text-[9px] font-bold">3</span>
              </div>
              <span>ای-اسٹامپ برائے عدالت (Secure E-Stamp Paper)</span>
            </button>

            <button
              onClick={() => setActiveSubTab('esign')}
              className={`w-full py-3 px-4 text-xs font-urdu font-bold rounded-xl border transition-all text-right flex items-center justify-between cursor-pointer ${
                activeSubTab === 'esign'
                  ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                  : 'hover:bg-stone-50 dark:hover:bg-stone-800 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300'
              }`}
            >
              <div className="w-4 h-4 rounded-full border border-current flex items-center justify-center shrink-0">
                <span className="text-[9px] font-bold">4</span>
              </div>
              <span>آرٹسٹک ای-دستخط پیڈ (Artistic E-Signature Drawing)</span>
            </button>
          </div>

          {/* Form Parameters Settings fields */}
          <div className="pt-3 border-t border-stone-100 dark:border-stone-800 space-y-4">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 dark:text-slate-500 font-sans block mb-1">
              Parameters Editor
            </span>

            {/* Customizer Panel conditional renders */}
            {activeSubTab === 'round_seal' && (
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Advocate Name:</span>
                    <span>وکیل کا پورا نام</span>
                  </label>
                  <input
                    type="text"
                    value={advocateName}
                    onChange={(e) => setAdvocateName(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Lawyer Designation/Title:</span>
                    <span>اہلیت / ڈیزگنیشن</span>
                  </label>
                  <input
                    type="text"
                    value={advocateTitle}
                    onChange={(e) => setAdvocateTitle(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>License ID:</span>
                      <span>لائسنس نمبر</span>
                    </label>
                    <input
                      type="text"
                      value={licenseNo}
                      onChange={(e) => setLicenseNo(e.target.value)}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>City Limit:</span>
                      <span>متعلقہ شہر</span>
                    </label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>Border Type:</span>
                      <span>سائیڈ بارڈر</span>
                    </label>
                    <select
                      value={borderType}
                      onChange={(e) => setBorderType(e.target.value as any)}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                    >
                      <option value="solid">Solid Circle</option>
                      <option value="dashed">Dashed Circle</option>
                      <option value="double">Double Circular Line</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>Ink Bleed Spill:</span>
                      <span>مہر کا دھندلا پن</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="6"
                      step="1"
                      value={bleedAmt}
                      onChange={(e) => setBleedAmt(Number(e.target.value))}
                      className="w-full h-1 mt-3"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Rubber Ink Color:</span>
                    <span>سیاہی کا رنگ منتخب کریں</span>
                  </label>
                  <div className="flex gap-2.5 mt-1.5 justify-end">
                    {['#0254a3', '#b91c1c', '#04583d', '#4d1cb9', '#0f172a'].map((c) => (
                      <button
                        key={c}
                        onClick={() => setSealColor(c)}
                        className={`w-5 h-5 rounded-full border border-stone-300 transition-all cursor-pointer ${
                          sealColor === c ? 'scale-125 ring-2 ring-emerald-600' : ''
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSubTab === 'rect_stamp' && (
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Court / Administrative Name:</span>
                    <span>متعلقہ عدالتی محکمہ</span>
                  </label>
                  <input
                    type="text"
                    value={courtName}
                    onChange={(e) => setCourtName(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Stamp File Status:</span>
                    <span>مہر اسٹیٹس</span>
                  </label>
                  <input
                    type="text"
                    value={stampStatus}
                    onChange={(e) => setStampStatus(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Authorized Officer Name:</span>
                    <span>مہر دستخط کنندہ افسر</span>
                  </label>
                  <input
                    type="text"
                    value={officerSignName}
                    onChange={(e) => setOfficerSignName(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pb-1">
                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>Emission Date:</span>
                      <span>تاریخ مہر</span>
                    </label>
                    <input
                      type="date"
                      value={stampDate}
                      onChange={(e) => setStampDate(e.target.value)}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>Ink Bleed Amt:</span>
                      <span>پھیلاؤ حد</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="6"
                      step="1"
                      value={bleedAmt}
                      onChange={(e) => setBleedAmt(Number(e.target.value))}
                      className="w-full h-1 mt-3"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Rubber Ink Color:</span>
                    <span>سیاہی کا رنگ منتخب کریں</span>
                  </label>
                  <div className="flex gap-2.5 mt-1.5 justify-end">
                    {['#b91c1c', '#0254a3', '#04583d', '#a3028b', '#000000'].map((c) => (
                      <button
                        key={c}
                        onClick={() => setStampColor(c)}
                        className={`w-5 h-5 rounded-full border border-stone-300 transition-all cursor-pointer ${
                          stampColor === c ? 'scale-125 ring-2 ring-emerald-600' : ''
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSubTab === 'estamp' && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>Stamp Price Duty:</span>
                      <span>مالیت روپے</span>
                    </label>
                    <select
                      value={stampValue}
                      onChange={(e) => setStampValue(e.target.value)}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                    >
                      <option value="100">Rs. 100/-</option>
                      <option value="500">Rs. 500/-</option>
                      <option value="1000">Rs. 1000/-</option>
                      <option value="5000">Rs. 5000/-</option>
                      <option value="15000">Rs. 15000/-</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>E-Ticket Reference:</span>
                      <span>ای-ٹکٹ نمبر</span>
                    </label>
                    <input
                      type="text"
                      value={eTicketCode}
                      onChange={(e) => setETicketCode(e.target.value)}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600 font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>First Party Details:</span>
                    <span>فریق اول (سائل / مدعی)</span>
                  </label>
                  <input
                    type="text"
                    value={firstParty}
                    onChange={(e) => setFirstParty(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Second Party Details:</span>
                    <span>فریق دوم (ذیلی فریق)</span>
                  </label>
                  <input
                    type="text"
                    value={secondParty}
                    onChange={(e) => setSecondParty(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                    <span>Issuance Date:</span>
                    <span>جاری کردہ تاریخ</span>
                  </label>
                  <input
                    type="date"
                    value={estampDate}
                    onChange={(e) => setEstampDate(e.target.value)}
                    className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                  />
                </div>
              </div>
            )}

            {activeSubTab === 'esign' && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>Pen Stroke Thickness:</span>
                      <span>قلم کی موٹائی</span>
                    </label>
                    <select
                      value={esignWidth}
                      onChange={(e) => setEsignWidth(Number(e.target.value))}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                    >
                      <option value="2">2px (Thin Ink)</option>
                      <option value="3">3px (Normal Rollerball)</option>
                      <option value="5">5px (Calligraphy Marker)</option>
                      <option value="7">7px (Thick Seal Pen)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-stone-500 font-urdu flex justify-between">
                      <span>Ink Substance Color:</span>
                      <span>سیاہی مائع رنگ</span>
                    </label>
                    <select
                      value={esignColor}
                      onChange={(e) => setEsignColor(e.target.value)}
                      className="w-full text-xs p-2 bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-lg focus:outline-emerald-600"
                    >
                      <option value="#000000">Jet Black Ink</option>
                      <option value="#0d4ca1">Fountain Blue Ink</option>
                      <option value="#8b0000">Deed Office Dark Red</option>
                      <option value="#006400">Green Board Special</option>
                    </select>
                  </div>
                </div>

                <p className="text-[11px] text-stone-400 dark:text-stone-500 font-urdu leading-normal text-right pt-2">
                  دائیں جانب کینوس پیڈ پر اپنے کمپیوٹر ماؤس يا موبائل ٹچ اسکرین کی مدد سے باقاعدہ وکیل دستخط کھینچیں اور ٹرانسپیرنٹ PNG تصویر ڈاؤنلوڈ کریں۔
                </p>
                
                <button
                  onClick={clearEsignPad}
                  className="w-full mt-3 py-2 px-4 rounded-xl border border-stone-200 hover:bg-stone-50 dark:border-stone-800 dark:hover:bg-stone-800 text-stone-600 dark:text-stone-300 transition-all font-urdu text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer"
                >
                  <RefreshCw size={12} />
                  دستخط بورڈ صاف کریں
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Side live viewport render */}
        <div className="lg:col-span-8 flex flex-col items-center">
          <div className="w-full bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 md:p-10 rounded-2xl shadow-sm flex flex-col items-center justify-center min-h-[420px] relative">
            
            {/* Live Render Canvas instances depending on category */}
            {activeSubTab === 'round_seal' && (
              <div className="relative p-2 border-4 border-dashed border-stone-150 rounded-full bg-stone-50/50">
                <canvas
                  ref={roundSealCanvasRef}
                  width={340}
                  height={340}
                  className="max-w-full h-auto max-h-[300px]"
                />
              </div>
            )}

            {activeSubTab === 'rect_stamp' && (
              <div className="relative p-2 border-4 border-dashed border-stone-150 rounded-xl bg-stone-50/50 w-full max-w-md">
                <canvas
                  ref={rectStampCanvasRef}
                  width={460}
                  height={220}
                  className="w-full h-auto max-h-[220px]"
                />
              </div>
            )}

            {activeSubTab === 'estamp' && (
              <div className="relative p-1 border-2 border-stone-250 shadow-md bg-stone-50/50 w-full max-w-lg rounded-lg overflow-hidden">
                <canvas
                  ref={estampCanvasRef}
                  width={560}
                  height={380}
                  className="w-full h-auto max-h-[380px]"
                />
              </div>
            )}

            {activeSubTab === 'esign' && (
              <div className="w-full max-w-md h-[250px] border-2 border-emerald-600/30 dark:border-emerald-700/20 bg-stone-50 dark:bg-stone-950 rounded-2xl relative overflow-hidden group touch-none cursor-crosshair">
                {!hasDrawn && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none p-4 text-center">
                    <span className="p-2 bg-emerald-600/10 text-emerald-600 rounded-full mb-1">
                      <PenTool size={16} />
                    </span>
                    <span className="text-xs font-bold text-stone-400 dark:text-stone-500 font-urdu">
                      اپنے دستخط یہاں کیجئے
                    </span>
                    <p className="text-[10px] text-stone-300 dark:text-stone-600 mt-1">Draw using mouse cursor or touchscreen gesture</p>
                  </div>
                )}
                <canvas
                  ref={esignCanvasRef}
                  width={450}
                  height={250}
                  onMouseDown={handleSignatureStart}
                  onMouseMove={handleSignatureDraw}
                  onMouseUp={handleSignatureEnd}
                  onMouseLeave={handleSignatureEnd}
                  onTouchStart={handleSignatureStart}
                  onTouchMove={handleSignatureDraw}
                  onTouchEnd={handleSignatureEnd}
                  className="w-full h-full"
                />
              </div>
            )}

            {/* Asset Actions */}
            <div className="mt-8 flex flex-col sm:flex-row gap-3 w-full max-w-md">
              <button
                onClick={() => downloadAsset(activeSubTab)}
                disabled={activeSubTab === 'esign' && !hasDrawn}
                className="flex-1 py-3 px-4 rounded-xl text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 transition-all font-urdu text-sm font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-700/10 active:scale-95"
              >
                <Download size={15} />
                مہر تصویر محفوظ کریں (.PNG)
              </button>
            </div>

            {/* Verification Helper label */}
            <div className="mt-4 flex gap-1.5 items-center justify-center text-stone-400 text-[10px] font-sans">
              <Layers size={11} />
              <span>HIGH RESOLUTION 4K TRANSPARENT LOSSLESS EXPORT SUPPORTED</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
