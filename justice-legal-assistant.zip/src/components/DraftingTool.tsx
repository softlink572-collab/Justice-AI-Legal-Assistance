/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FileText, FileDown, Copy, Check, Scale, BookOpen, Clock, Loader2, Sparkles, Printer } from 'lucide-react';
import { DraftTemplate, User } from '../types';

interface DraftingToolProps {
  currentUser: User | null;
  activeCategory: string | null;
}

const TEMPLATES: DraftTemplate[] = [
  {
    id: 'plaint',
    name: 'Civil Plaint (Suit for Specific Performance / Recovery)',
    nameUrdu: 'دیوانی دعویٰ (تعمیلِ مختص / وصولی زر)',
    type: 'plaint',
    category: 'civil_draft',
    description: 'Deed/petition under CPC 1908 for initiating civil disputes like properties, recovery, or contractual obligations.',
    fields: [
      { key: 'courtName', label: 'Court Name', labelUrdu: 'عدالت عالیہ / عدالتِ دیوانی کا مقام', type: 'text', placeholder: 'e.g., In the Court of Civil Judge, Lahore' },
      { key: 'parties', label: 'Parties Listing (Petitioner vs Respondent)', labelUrdu: 'فریقین (مدعی بنام مدعا علیہ)', type: 'text', placeholder: 'e.g., Muhammad Bilal vs. Punjab Development Authority' },
      { key: 'subject', label: 'Subject Heading', labelUrdu: 'عنوانِ مقدمہ', type: 'text', placeholder: 'e.g., Suit for Specific Performance of Agreement to Sell' },
      { key: 'facts', label: 'Brief Statement of Facts', labelUrdu: 'حالاتِ واقعہ (چیدہ نکات)', type: 'textarea', placeholder: 'Describe dates of Agreement, breach, payments, and warnings...' },
      { key: 'prayer', label: 'Prayer (Specific Relief Sought)', labelUrdu: 'استدعا / دادرسی', type: 'textarea', placeholder: 'Prayer for decree of specific performance and permanent injunction...' }
    ]
  },
  {
    id: 'written_statement',
    name: 'Written Statement (Defendant\'s Reply)',
    nameUrdu: 'جواب دعویٰ (مدعا علیہ کا موقف)',
    type: 'written_statement',
    category: 'civil_draft',
    description: 'Formal rebuttal and defense statements submitted on behalf of the defendant under Order VIII of Civil Procedure Code.',
    fields: [
      { key: 'courtName', label: 'Court Name', labelUrdu: 'عدالتِ دیوانی کا مقام', type: 'text', placeholder: 'e.g., In the Court of Senior Civil Judge, Islamabad' },
      { key: 'parties', label: 'Parties Listing (Petitioner vs Respondent)', labelUrdu: 'فریقین (مدعی بنام مدعا علیہ)', type: 'text', placeholder: 'e.g., Muhammad Bilal vs. Punjab Development Authority' },
      { key: 'suitTitle', label: 'Original Suit Title', labelUrdu: 'اصل دعویٰ کا عنوان', type: 'text', placeholder: 'e.g., Suit for Recovery of Lakhs Rupees' },
      { key: 'objections', label: 'Preliminary Objections', labelUrdu: 'عذرِ لنگ / ابتدائی اعتراضات', type: 'textarea', placeholder: 'No cause of action, barred by limitation, or valuation objections...' },
      { key: 'reply', label: 'Para-wise Reply to Facts', labelUrdu: 'پیرا وار جوابِ واقعہ', type: 'textarea', placeholder: 'Reply to paragraphs 1-5, denying allegations of non-payment...' }
    ]
  },
  {
    id: 'writ_petition',
    name: 'Constitutional Writ Petition (Article 199)',
    nameUrdu: 'آئینی رٹ پٹیشن (آرٹیکل 199)',
    type: 'writ_petition',
    category: 'civil_petition',
    description: 'Extraordinary petition in the High Court challenging illegal acts of government officers or fundamental rights violations.',
    fields: [
      { key: 'highCourt', label: 'High Court Name', labelUrdu: 'متعلقہ ہائی کورٹ کا نام', type: 'text', placeholder: 'e.g., In the Lahore High Court, Lahore' },
      { key: 'parties', label: 'Parties (Petitioner vs State/Authorities)', labelUrdu: 'فریقین (سائل بنام متعلقہ محکمہ)', type: 'text', placeholder: 'e.g., Zaheer Ahmed Advocate vs. Federation of Pakistan & Others' },
      { key: 'aggrievedAct', label: 'Illegal Act Challenged', labelUrdu: 'غیر قانونی عمل / نوٹس جس پر اعتراض ہے', type: 'text', placeholder: 'e.g., Unlawful suspension order or illegal demolition notice' },
      { key: 'grounds', label: 'Constitutional Grounds', labelUrdu: 'بنیادی آئینی وجوہات', type: 'textarea', placeholder: 'Violation of Article 10A, coram non judice, or without lawful authority...' },
      { key: 'prayer', label: 'Prayer (Specific Writs Issued)', labelUrdu: 'استدعا برائے رٹ نوٹس', type: 'textarea', placeholder: 'Direct respondents to withdraw notice, suspend proceedings, etc...' }
    ]
  },
  {
    id: 'legal_notice',
    name: 'Formal Legal Notice (Pre-litigation Warning)',
    nameUrdu: 'قانونی نوٹس (مقدمہ بازی سے پہلے وارننگ)',
    type: 'legal_notice',
    category: 'civil_draft',
    description: 'Pre-action notification sent to opposite party to satisfy terms or face civil/criminal actions.',
    fields: [
      { key: 'parties', label: 'To (Recipient Address details)', labelUrdu: 'مکتوب الیہ (جسے نوٹس بھیجنا ہے)', type: 'text', placeholder: 'e.g., M/S Alpha Traders, G-T Road, Rawalpindi' },
      { key: 'sender', label: 'From (Counsel / Client details)', labelUrdu: 'ارسال کنندہ (سائل / وکیل کی تفصیل)', type: 'text', placeholder: 'e.g., Kamran Malik Adv. on behalf of M. Saleem' },
      { key: 'grievance', label: 'Grievance / Offense Detail', labelUrdu: 'اصل شکایت / مکرر انتباہ', type: 'textarea', placeholder: 'Failure to perform agreement, outstanding payment of Rs 500,000, or defamation...' },
      { key: 'demands', label: 'Clear Demands & Duration', labelUrdu: 'سزا / مطالبات اور وقت', type: 'textarea', placeholder: 'Pay Rs 500,000 within 14 days, otherwise face legal suits at Lahore Courts...' }
    ]
  },
  {
    id: 'bail_application',
    name: 'Bail Application before Arrest (Sec 497 CrPC)',
    nameUrdu: 'درخواست ضمانت قبل از گرفتاری (دفعہ 497 ضابطہ فوجداری)',
    type: 'bail_application',
    category: 'criminal_petition',
    description: 'Formal application submitted to the Session Court or High Court seeking pre-arrest protection under criminal law.',
    fields: [
      { key: 'courtName', label: 'Court Name', labelUrdu: 'حاضر عدالت برائے ضمانت', type: 'text', placeholder: 'e.g., In the Court of Sessions Judge, Faisalabad' },
      { key: 'parties', label: 'Parties Listing (Accused vs State)', labelUrdu: 'فریقین (ملزم بنام سرکار)', type: 'text', placeholder: 'e.g., Muhammad Waqas vs. The State' },
      { key: 'firNo', label: 'FIR No & Police Station', labelUrdu: 'ایف آئی آر نمبر اور متعلقہ تھانہ', type: 'text', placeholder: 'e.g., FIR No. 412/2026, PS Peoples Colony' },
      { key: 'offenses', label: 'Offenses Under PPC Section', labelUrdu: 'دفعات (تعزیرات پاکستان)', type: 'text', placeholder: 'e.g., PPC Sections 379, 411, and 34' },
      { key: 'grounds', label: 'Arguments & Grounds of False Implication', labelUrdu: 'ضمانت کی وجوہات اور دشمنی', type: 'textarea', placeholder: 'Describe enmity with complainant, delay in FIR, lack of recoveries, pure visual setup...' }
    ]
  },
  {
    id: 'criminal_complaint',
    name: 'Private Complaint (Sec 200 CrPC Esthghasa)',
    nameUrdu: 'نجی استغاثہ (فوجداری کارروائی برائے طلبی ملزمان)',
    type: 'criminal_complaint',
    category: 'criminal_draft',
    description: 'Direct prosecution complaint filed in Magistrate court under Section 200 of criminal procedure code.',
    fields: [
      { key: 'courtName', label: 'Magistrate Court Address', labelUrdu: 'عدالتِ علاقہ مجسٹریٹ', type: 'text', placeholder: 'e.g., In the Court of Judicial Magistrate 1st Class, Multan' },
      { key: 'parties', label: 'Parties Listing (Complainant vs Accused)', labelUrdu: 'فریقین (مستغیث بنام ملزمان)', type: 'text', placeholder: 'e.g., Ali Raza vs. Naeem Iqbal & Others' },
      { key: 'incident', label: 'Description of Theft/Assault Incident', labelUrdu: 'مبینہ جرم اور واقعہ کا پس منظر', type: 'textarea', placeholder: 'Provide full detail of trespass, illegal threat of life, and theft details...' },
      { key: 'prayer', label: 'Prosecution Summons Prayer', labelUrdu: 'مقدس استدعا', type: 'textarea', placeholder: 'Prayer to summon, try and penalize the accused for public justice...' }
    ]
  },
  {
    id: 'khula_suit',
    name: 'Family Suit for dissolution of marriage (Khula)',
    nameUrdu: 'عائلی دعویٰ تنسیخِ نکاح بربنائے خلع',
    type: 'khula_suit',
    category: 'family_draft',
    description: 'Legal suit for wives seeking dissolution under West Pakistan Family Courts Act 1964.',
    fields: [
      { key: 'courtName', label: 'Family Court Location', labelUrdu: 'عدالتِ فیملی جج کا نام', type: 'text', placeholder: 'e.g., In the Court of Judge Family Court, Gujranwala' },
      { key: 'parties', label: 'Parties Listing (Wife vs Husband)', labelUrdu: 'فریقین (زوجہ بنام شوہر)', type: 'text', placeholder: 'e.g., Sadia Bibi vs. Muhammad Rashid' },
      { key: 'marriageDetails', label: 'Dower and Nikah Details', labelUrdu: 'تفصیلِ نکاح نامہ و حق مہر', type: 'text', placeholder: 'e.g., Nikah solemnized on 12/03/2024, registered, dower Rs 50,000 unpaid...' },
      { key: 'grounds', label: 'Cruelty & Incompatibility Grounds', labelUrdu: 'نفرت و ناچاقی کی مستند وجوہات', type: 'textarea', placeholder: 'Failure of husband to maintain, physical/verbal cruelty, extreme incompatibility...' },
      { key: 'prayer', label: 'Specific Legal Relief Prayer', labelUrdu: 'حتمی داد رسی استدعا', type: 'textarea', placeholder: 'Dissolution of marriage by Khula and decree for recovery of dowry articles...' }
    ]
  }
];

export default function DraftingTool({ currentUser, activeCategory }: DraftingToolProps) {
  const filteredTemplates = activeCategory 
    ? TEMPLATES.filter(tmpl => tmpl.category === activeCategory)
    : TEMPLATES;

  const [activeTemplate, setActiveTemplate] = useState<DraftTemplate>(filteredTemplates[0] || TEMPLATES[0]);
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [language, setLanguage] = useState<'ur' | 'en'>('en');
  const [draftResult, setDraftResult] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [printFormat, setPrintFormat] = useState<'blank_stamp' | 'normal_letterhead'>('blank_stamp');

  React.useEffect(() => {
    // When LeftSidebar selection updates, automatically transition active drafting tool template
    const match = TEMPLATES.find(t => t.category === activeCategory);
    if (match) {
      setActiveTemplate(match);
      setFormValues({});
      setDraftResult('');
      setError('');
    }
  }, [activeCategory]);

  const handleInputChange = (key: string, val: string) => {
    setFormValues(prev => ({ ...prev, [key]: val }));
  };

  const handleTemplateChange = (tmpl: DraftTemplate) => {
    setActiveTemplate(tmpl);
    setFormValues({});
    setDraftResult('');
    setError('');
  };

  const generateDraft = async () => {
    setError('');
    // Verify required inputs
    const missing = activeTemplate.fields.filter(f => !formValues[f.key]);
    if (missing.length > 0) {
      setError(`براہ کرم تمام خانے پُر کریں۔ درج ذیل رہ گئے ہیں: ` + missing.map(m => m.label).join(', '));
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          docType: activeTemplate.type,
          language,
          vars: formValues,
          userId: currentUser ? currentUser.id : 'guest'
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'ڈرافٹ بنانے میں ناکام رہا۔');
      }

      setDraftResult(data.draft);
    } catch (err: any) {
      setError(err.message || 'ڈرافٹ کی مینوئل تیاری فیل ہو گئی۔');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(draftResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([draftResult], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Justice_Draft_${activeTemplate.type}_${language}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadHTML = () => {
    const isBlankStamp = printFormat === 'blank_stamp';
    const htmlContent = `
<!DOCTYPE html>
<html lang="${language}">
  <head>
    <meta charset="utf-8">
    <title>قانونی دستاویز - جسٹس لاء ایسوسی ایٹس</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
      @font-face {
        font-family: 'Alvi Nastaleeq';
        src: url('https://cdn.jsdelivr.net/gh/tariq-abdullah/urdu-web-font-CDN/AlviLahoriNastaleeq.woff2') format('woff2');
      }
      @page {
        size: legal; /* Standard Pakistani Court Legal Paper Size: 8.5in x 14in */
        margin: 0;   /* Margin explicitly handled in page-container */
      }
      body {
        font-family: 'Alvi Nastaleeq', 'Inter', serif;
        padding: 40px 0;
        margin: 0;
        color: #000;
        direction: ${language === 'ur' ? 'rtl' : 'ltr'};
        background-color: #f3f4f6;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      .page-container {
        box-sizing: border-box;
        width: 8.5in;
        min-height: 14in;
        padding-left: 1in;
        padding-right: 1.1in;
        padding-bottom: 1.2in;
        padding-top: ${isBlankStamp ? '3.5in' : '1.5in'};
        font-size: 19px;
        line-height: 2.4;
        position: relative;
        background-color: #fff;
        margin: 0 auto;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        border: 1px solid #e5e7eb;
      }
      @media print {
        body {
          padding: 0;
          background-color: #fff;
        }
        .page-container {
          box-shadow: none;
          border: none;
          margin: 0;
          width: 8.5in;
          min-height: 14in;
        }
      }
      .letterhead {
        position: absolute;
        top: 0.8in;
        left: 1in;
        right: 1.1in;
        text-align: center;
        border-bottom: 4px double #047857;
        padding-bottom: 15px;
        display: ${isBlankStamp ? 'none' : 'block'};
        direction: rtl;
      }
      .letterhead-title {
        margin: 0;
        font-size: 30px;
        color: #047857;
        font-family: 'Alvi Nastaleeq', serif;
        font-weight: bold;
      }
      .letterhead-subtitle {
        margin: 6px 0 0 0;
        font-size: 19px;
        color: #111;
        font-family: 'Alvi Nastaleeq', serif;
        font-weight: bold;
      }
      .letterhead-en {
        margin: 3px 0 0 0;
        font-size: 11px;
        color: #4b5563;
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        letter-spacing: 1.5px;
        text-transform: uppercase;
      }
      .content {
        font-size: 19px;
        white-space: pre-wrap;
        color: #000;
        text-align: justify;
        font-weight: 500;
      }
      .footer {
        position: absolute;
        bottom: 1.1in;
        left: 1in;
        right: 1.1in;
        border-top: 1px solid #e5e7eb;
        padding-top: 15px;
        text-align: center;
        font-size: 12px;
        color: #4b5563;
        font-family: 'Inter', sans-serif;
      }
      strong {
        color: #000;
        font-weight: bold;
      }
      /* Top Helper Bar */
      .action-bar {
        max-width: 8.5in;
        margin: 0 auto 20px auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #111827;
        color: #fff;
        padding: 12px 24px;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        font-family: system-ui, -apple-system, sans-serif;
      }
      .action-title {
        font-size: 14px;
        font-weight: 600;
      }
      .print-btn {
        background-color: #059669;
        color: white;
        border: none;
        padding: 8px 18px;
        font-size: 13px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        transition: background 0.2s;
      }
      .print-btn:hover {
        background-color: #047857;
      }
      @media print {
        .action-bar {
          display: none;
        }
      }
    </style>
  </head>
  <body>
    <div class="action-bar">
      <div class="action-title">جسٹس لاء ایسوسی ایٹس - عدالتی دستاویز ریڈی برائے پی ڈی ایف</div>
      <button class="print-btn" onclick="window.print()">پرنٹ / پی ڈی ایف سیو کریں (PDF)</button>
    </div>
    <div class="page-container">
      <div class="letterhead">
        <div class="letterhead-title font-urdu">جسٹس لاء ایسوسی ایٹس</div>
        <div class="letterhead-subtitle font-urdu">سید اظہر حسین سبزواری ایڈوکیٹ ہائی کورٹ</div>
        <div class="letterhead-en">Justice Law Associates - Advocate High Court</div>
      </div>
      <div class="content">${draftResult.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>')}</div>
      <div class="footer">
        ڈرافٹ خودکار نظام جسٹس لاء ایسوسی ایٹس سسٹم سے حاصل شدہ ہے
        <br/>ڈرافٹنگ تاریخ: ${new Date().toLocaleString('ur-PK')}
      </div>
    </div>
  </body>
</html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Court_Legal_Draft_${activeTemplate.type}_${language}.html`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintDraft = () => {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (doc) {
      const isBlankStamp = printFormat === 'blank_stamp';
      
      doc.write(`
        <html>
          <head>
            <title>قانونی دستاویز - جسٹس لاء ایسوسی ایٹس</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
              @font-face {
                font-family: 'Alvi Nastaleeq';
                src: url('https://cdn.jsdelivr.net/gh/tariq-abdullah/urdu-web-font-CDN/AlviLahoriNastaleeq.woff2') format('woff2');
              }
              @page {
                size: legal; /* Standard Pakistani Court Legal Paper Size: 8.5in x 14in */
                margin: 0;   /* Margin explicitly handled in print container */
              }
              body {
                font-family: 'Alvi Nastaleeq', 'Inter', serif;
                padding: 0;
                margin: 0;
                color: #000;
                direction: ${language === 'ur' ? 'rtl' : 'ltr'};
                background-color: #fff;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
              }
              .page-container {
                box-sizing: border-box;
                width: 8.5in;
                min-height: 14in;
                padding-left: 1in;
                padding-right: 1.1in;
                padding-bottom: 1.2in;
                /* Leave 3.5 inches of top space for physical stamp paper seals if blank_stamp is chosen, else normal 1.5 inches padding */
                padding-top: ${isBlankStamp ? '3.5in' : '1.5in'};
                font-size: 19px; /* Highly requested large, readable font size */
                line-height: 2.4;
                position: relative;
              }
              .letterhead {
                position: absolute;
                top: 0.8in;
                left: 1in;
                right: 1.1in;
                text-align: center;
                border-bottom: 3px double #047857;
                padding-bottom: 15px;
                display: ${isBlankStamp ? 'none' : 'block'};
                direction: rtl;
              }
              .letterhead-title {
                margin: 0;
                font-size: 30px;
                color: #047857;
                font-family: 'Alvi Nastaleeq', serif;
                font-weight: bold;
              }
              .letterhead-subtitle {
                margin: 6px 0 0 0;
                font-size: 19px;
                color: #111;
                font-family: 'Alvi Nastaleeq', serif;
                font-weight: bold;
              }
              .letterhead-en {
                margin: 3px 0 0 0;
                font-size: 11px;
                color: #4b5563;
                font-family: 'Inter', sans-serif;
                font-weight: 600;
                letter-spacing: 1.5px;
                text-transform: uppercase;
              }
              .content {
                font-size: 19px;
                white-space: pre-wrap;
                color: #000;
                text-align: justify;
                font-weight: 500;
              }
              .footer {
                position: absolute;
                bottom: 1in;
                left: 1in;
                right: 1.1in;
                border-top: 1px solid #e5e7eb;
                padding-top: 15px;
                text-align: center;
                font-size: 12px;
                color: #4b5563;
                font-family: 'Inter', sans-serif;
              }
              strong {
                color: #000;
                font-weight: bold;
              }
            </style>
          </head>
          <body>
            <div class="page-container">
              <div class="letterhead">
                <div class="letterhead-title">جسٹس لاء ایسوسی ایٹس</div>
                <div class="letterhead-subtitle">سید اظہر حسین سبزواری ایڈوکیٹ ہائی کورٹ</div>
                <div class="letterhead-en">Justice Law Associates - Advocate High Court</div>
              </div>
              <div class="content">${draftResult.replace(/\*\*(.*?)\*\//g, '<strong>$1</strong>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>')}</div>
              <div class="footer">
                ڈرافٹ خودکار نظام جسٹس لاء ایسوسی ایٹس سسٹم سے حاصل شدہ ہے
                <br/>ڈرافٹنگ تاریخ: ${new Date().toLocaleString('ur-PK')}
              </div>
            </div>
          </body>
        </html>
      `);
      doc.close();

      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 1000);
      }, 500);
    }
  };

  return (
    <div className="w-full h-full grid grid-cols-1 lg:grid-cols-12 gap-6 p-1 lg:p-4 overflow-y-auto max-h-[calc(100vh-120px)]">
      {/* Sidebar - Templates */}
      <div className="lg:col-span-4 space-y-4">
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-4 rounded-2xl shadow-sm">
          <div className="flex items-center gap-2 mb-3 text-emerald-700 dark:text-emerald-400">
            <Scale size={18} />
            <h3 className="font-semibold text-stone-800 dark:text-stone-200 font-urdu text-sm">لیگل ڈرافٹ منتخب کریں</h3>
          </div>
          
          <div className="space-y-2">
            {filteredTemplates.map((tmpl) => {
              const isSelected = activeTemplate.id === tmpl.id;
              return (
                <button
                  key={tmpl.id}
                  onClick={() => handleTemplateChange(tmpl)}
                  className={`w-full text-right p-3 rounded-xl border text-xs transition-all ${
                    isSelected
                      ? 'bg-emerald-500/10 border-emerald-500 text-emerald-800 dark:text-emerald-300 font-medium'
                      : 'border-stone-150 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-850 bg-white/40 dark:bg-stone-900/10'
                  }`}
                >
                  <div className="font-semibold font-sans mb-1 text-sm text-left">{tmpl.name}</div>
                  <div className="text-stone-600 dark:text-stone-300 font-urdu text-xs mb-1 mb-2 text-right">{tmpl.nameUrdu}</div>
                  <p className="text-[10px] text-stone-400 dark:text-stone-500 font-sans leading-tight text-left">
                    {tmpl.description}
                  </p>
                </button>
              );
            })}
            
            {filteredTemplates.length === 0 && (
              <div className="p-6 text-center text-stone-400 dark:text-stone-500 font-urdu text-xs bg-slate-50 dark:bg-stone-900/40 rounded-xl">
                اس کٹیگری کے تحت کوئی مسودہ موجود نہیں ہے۔ براہ کرم بائیں مینو سے کٹیگری منتخب کریں۔
              </div>
            )}
          </div>
        </div>

        {/* Input variables form */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-5 rounded-2xl shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-stone-100 dark:border-stone-800">
            <span className="font-semibold text-stone-700 dark:text-stone-200 font-urdu text-xs">ڈرافٹنگ سیٹنگز:</span>
            
            {/* Language toggle selector */}
            <div className="flex bg-stone-100 dark:bg-stone-800 p-1 rounded-lg">
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 text-[11px] rounded transition-all ${
                  language === 'en'
                    ? 'bg-white dark:bg-stone-700 text-stone-800 dark:text-white shadow-sm font-semibold'
                    : 'text-stone-500'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLanguage('ur')}
                className={`px-3 py-1 text-xs font-urdu rounded transition-all ${
                  language === 'ur'
                    ? 'bg-emerald-700 text-white shadow-sm font-semibold'
                    : 'text-stone-500'
                }`}
              >
                اردو
              </button>
            </div>
          </div>

          {error && (
            <div className="p-2.5 text-xs text-red-600 bg-red-50 dark:bg-red-950/20 dark:text-red-400 border border-red-200 dark:border-red-900/30 rounded-xl font-urdu">
              {error}
            </div>
          )}

          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {activeTemplate.fields.map((field) => (
              <div key={field.key} className="space-y-1">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-stone-500 dark:text-stone-400 font-sans font-medium">{field.label}</span>
                  <span className="text-stone-600 dark:text-stone-300 font-urdu text-[11px]">{field.labelUrdu}</span>
                </div>

                {field.type === 'text' ? (
                  <input
                    type="text"
                    value={formValues[field.key] || ''}
                    onChange={(e) => handleInputChange(field.key, e.target.value)}
                    placeholder={field.placeholder}
                    className="w-full p-2.5 text-xs bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
                  />
                ) : (
                  <textarea
                    rows={field.key === 'facts' ? 4 : 3}
                    value={formValues[field.key] || ''}
                    onChange={(e) => handleInputChange(field.key, e.target.value)}
                    placeholder={field.placeholder}
                    className="w-full p-2.5 text-xs bg-stone-50 dark:bg-stone-800 text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
                  />
                )}
              </div>
            ))}
          </div>

          <button
            onClick={generateDraft}
            disabled={loading}
            className="w-full py-2.5 px-4 font-semibold text-white bg-emerald-700 hover:bg-emerald-800 dark:bg-emerald-850 dark:hover:bg-emerald-700 active:scale-95 disabled:opacity-50 disabled:pointer-events-none rounded-xl transition-all flex items-center justify-center gap-2 font-urdu text-sm cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                تحریر تیار کی جا رہی ہے...
              </>
            ) : (
              <>
                <Sparkles size={16} />
                خودکار ڈرافٹ تیار کریں
              </>
            )}
          </button>
        </div>
      </div>

      {/* Draft previewer space styled like formal green stamp court paper */}
      <div className="lg:col-span-8 flex flex-col h-full min-h-[500px]">
        {draftResult ? (
          <div className="flex-1 flex flex-col bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl shadow-sm overflow-hidden min-h-0">
            {/* Stamp Paper header bar with responsive Urdu formatting selector */}
            <div className="bg-stone-100 dark:bg-stone-800 p-3 px-4 border-b border-stone-200 dark:border-stone-700 flex flex-col md:flex-row gap-3 justify-between items-center z-10 shrink-0">
              <div className="flex flex-wrap items-center gap-2">
                <FileText size={16} className="text-emerald-700 dark:text-emerald-400" />
                <span className="text-xs font-bold font-sans uppercase text-stone-700 dark:text-stone-200">Court Draft Preview</span>
                {language === 'ur' && <span className="px-1.5 py-0.5 bg-emerald-750 text-white text-[10px] rounded font-urdu">اردو ورژن</span>}
                
                {/* Format selection toggler */}
                <div className="flex ml-0 md:ml-4 bg-stone-250/50 dark:bg-stone-900/40 p-0.5 rounded-lg border border-stone-300/30 dark:border-stone-800">
                  <button
                    onClick={() => setPrintFormat('blank_stamp')}
                    className={`px-3 py-1 text-[11px] font-urdu rounded-md transition-all cursor-pointer ${
                      printFormat === 'blank_stamp'
                        ? 'bg-emerald-700 text-white shadow-sm font-bold'
                        : 'text-stone-600 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
                    }`}
                  >
                    اسٹامپ پیپر کیلئے (خالی جگہ)
                  </button>
                  <button
                    onClick={() => setPrintFormat('normal_letterhead')}
                    className={`px-3 py-1 text-[11px] font-urdu rounded-md transition-all cursor-pointer ${
                      printFormat === 'normal_letterhead'
                        ? 'bg-emerald-750 text-white shadow-sm font-bold'
                        : 'text-stone-600 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
                    }`}
                  >
                    لیٹر ہیڈ (جسٹس لاء ایسوسی ایٹس)
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="p-1 px-3 text-xs bg-white dark:bg-stone-700 border border-stone-250 dark:border-stone-600 text-stone-700 dark:text-stone-200 rounded-lg hover:bg-stone-50 dark:hover:bg-stone-600 transition-all flex items-center gap-1.5 cursor-pointer font-urdu"
                >
                  {copied ? (
                    <>
                      <Check size={12} className="text-green-650" />
                      کاپی ہو گیا!
                    </>
                  ) : (
                    <>
                      <Copy size={12} />
                      مسودہ کاپی کریں
                    </>
                  )}
                </button>
                 <button
                  onClick={handleDownload}
                  className="p-1 px-3 text-xs bg-white dark:bg-stone-700 border border-stone-250 dark:border-stone-600 text-stone-700 dark:text-stone-200 rounded-lg hover:bg-stone-50 dark:hover:bg-stone-600 transition-all flex items-center gap-1.5 cursor-pointer font-urdu"
                  title="مارک ڈاؤن (.md) فائل ڈاؤنلوڈ کریں"
                >
                  <FileDown size={12} />
                  ڈاؤنلوڈ مارک ڈاؤن (.md)
                </button>
                <button
                  onClick={handleDownloadHTML}
                  className="p-1 px-3 text-xs bg-amber-600 hover:bg-amber-700 text-white rounded-lg transition-all flex items-center gap-1.5 cursor-pointer font-urdu font-bold"
                  title="پی ڈی ایف برائے پرنٹ (HTML) ڈاؤنلوڈ کریں"
                >
                  <FileDown size={12} />
                  ڈاؤنلوڈ پی ڈی ایف برائے کورٹ (.html)
                </button>
                <button
                  onClick={handlePrintDraft}
                  className="p-1 px-3 text-xs bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg transition-all flex items-center gap-1.5 cursor-pointer font-urdu font-bold"
                >
                  <Printer size={12} />
                  براہِ راست پرنٹ PDF (Iframe)
                </button>
              </div>
            </div>

            {/* Simulated E-Stamp Green Board with large, high contrast custom typography styles */}
            <div className="flex-1 overflow-y-auto p-2 md:p-6 bg-stone-50 dark:bg-stone-950 flex justify-center">
              <div className="w-full max-w-2xl bg-[#fdfdfc] dark:bg-[#121413] shadow-lg p-6 md:p-10 min-h-[297mm] flex flex-col text-stone-900 dark:text-stone-100 relative border border-stone-200/50 dark:border-stone-800/50">
                {/* Official Stamp Header block vs Advocate Letterhead based on print format selection */}
                {printFormat === 'blank_stamp' ? (
                  <div className="flex flex-col items-center justify-center border-b-2 border-stone-300 dark:border-stone-800 pb-4 mb-6 text-center opacity-65 dotted-border">
                    <div className="w-10 h-10 bg-green-800/10 flex items-center justify-center rounded-full text-green-705 dark:text-green-400 mb-1">
                      <Scale size={20} />
                    </div>
                    <span className="text-[9px] font-bold text-green-850 dark:text-green-450 font-sans tracking-wide uppercase">
                      PHYSICAL STAMP LEAF ALIGNMENT PRESET
                    </span>
                    <p className="text-[10px] text-stone-400 font-mono">پرنٹ کرتے ہوئے اوپر 3.5 انچ جگہ خالی چھوڑی جائے گی تاکہ یہ اصل اسٹامپ پیپر پر پرنٹ ہو سکے</p>
                    <div className="w-full h-12 flex items-center justify-center border-y border-dashed border-emerald-600/30 text-[10px] text-emerald-800 mt-1 font-urdu bg-emerald-50/20">
                      ← 3.5 انچ عارضی ٹاپ مارجن (صرف اسٹامپ پیپر کے لیے متحرک ہے) →
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center border-b-4 border-double border-emerald-700 pb-4 mb-8 text-center">
                    <h2 className="text-2xl md:text-3xl font-bold text-emerald-800 dark:text-emerald-450 font-urdu leading-tight">جسٹس لاء ایسوسی ایٹس</h2>
                    <p className="text-sm md:text-base font-bold text-stone-850 dark:text-stone-105 font-urdu mt-1 text-emerald-900 dark:text-emerald-400">سید اظہر حسین سبزواری ایڈوکیٹ ہائی کورٹ</p>
                    <span className="text-[10px] text-stone-500 dark:text-stone-400 font-sans tracking-widest uppercase font-bold mt-1">
                      JUSTICE LAW ASSOCIATES - ADVOCATE HIGH COURT
                    </span>
                  </div>
                )}

                {/* Main draft container text - ENLARGED globally as requested to be highly readable */}
                <div 
                  className={`flex-1 prose max-w-none dark:prose-invert font-sans text-stone-850 dark:text-stone-50 whitespace-pre-wrap leading-relaxed ${
                    language === 'ur' ? 'urdu-text text-right px-1 font-medium' : 'font-medium'
                  }`}
                  style={{ fontSize: '1.25rem', lineHeight: '2.5' }}
                  dir={language === 'ur' ? 'rtl' : 'ltr'}
                >
                  {draftResult}
                </div>

                {/* Footer seal */}
                <div className="mt-12 pt-6 border-t border-stone-200 dark:border-stone-800 text-center text-[10px] text-stone-400 font-mono">
                  *** JUSTICE LAW ASSOCIATES — COURT DOCUMENT DOCUMENT COPY ***
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl flex flex-col items-center justify-center p-8 text-center">
            <div className="p-4 bg-stone-50 dark:bg-emerald-950/20 text-stone-400 dark:text-emerald-500/80 rounded-full mb-3">
              <FileText size={36} />
            </div>
            <h4 className="font-semibold text-stone-700 dark:text-stone-300 font-urdu text-sm">ڈرافٹ خالی ہے</h4>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 max-w-md font-urdu leading-relaxed">
              بائیں جانب متعلقہ قانونی فارم کے خانے بریف ہسٹری کے ساتھ پُر کریں اور 'خودکار ڈرافٹ تیار کریں' بٹن پر کلک کریں۔ AI سورسز اور کوڈز آف پروسیجر کی روشنی میں باقاعدہ عدالتی تحریر تیار کرے گا۔
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
