/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Users, Shield, CheckCircle, Ban, Send, Bell, Loader2, Sparkles, Scale, RefreshCw, 
  Trash2, UserCheck, ShieldAlert, Award, FileText, Search, Filter, Key, Check, X,
  TrendingUp, BarChart2, Zap, HelpCircle, HardDrive, Edit2, CheckCircle2, UserX, ToggleLeft, ToggleRight
} from 'lucide-react';
import { User, SystemNotification } from '../types';

interface AdminDashboardProps {
  currentUser: User | null;
}

export default function AdminDashboard({ currentUser }: AdminDashboardProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  
  // Searching & Filtering state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  
  // Interactive Editing panel state
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editQuota, setEditQuota] = useState(120);
  const [editQueriesUsed, setEditQueriesUsed] = useState(0);
  const [editNotes, setEditNotes] = useState('');
  const [editIsVerified, setEditIsVerified] = useState(false);
  const [editLicense, setEditLicense] = useState('');

  const [loading, setLoading] = useState(false);
  const [submittingNotif, setSubmittingNotif] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Bulk actions status helper
  const [bulkProcessing, setBulkProcessing] = useState(false);

  const fetchAdminData = async () => {
    setRefreshing(true);
    try {
      const uRes = await fetch('/api/admin/users');
      const uData = await uRes.json();
      if (uRes.ok) {
        setUsers(uData);
      }

      const nRes = await fetch('/api/notifications');
      const nData = await nRes.json();
      if (nRes.ok) {
        setNotifications(nData);
      }
    } catch (err) {
      console.error('Error fetching admin details:', err);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleUserAction = async (id: string, action: 'approve' | 'block' | 'unblock' | 'promote' | 'demote' | 'delete') => {
    setErrorMsg('');
    setSuccessMsg('');
    setBulkProcessing(true);
    try {
      const res = await fetch(`/api/admin/users/${id}/${action}`, {
        method: 'POST'
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'عمل درآمد میں ناکامی۔');
      }

      setSuccessMsg(`صارف پر کارروائی (${action}) کامیابی سے مکمل ہو گئی۔`);
      if (selectedUserId === id) {
        setSelectedUserId(null); // Clear selected if modified/deleted
      }
      fetchAdminData();
    } catch (err: any) {
      setErrorMsg(err.message || 'کنکشن فیل ہو گیا۔');
    } finally {
      setBulkProcessing(false);
    }
  };

  // Select user for inline advanced control editor
  const handleSelectUserEdit = (user: User) => {
    setSelectedUserId(user.id);
    setEditName(user.name);
    setEditEmail(user.email);
    setEditQuota(user.queryQuota !== undefined ? user.queryQuota : 120);
    setEditQueriesUsed(user.queriesUsed !== undefined ? user.queriesUsed : 0);
    setEditNotes(user.notes || '');
    setEditIsVerified(!!user.isVerifiedAdvocate);
    setEditLicense(user.lawLicenseNumber || '');
  };

  // Submit comprehensive user settings update to backend
  const handleSaveUserSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) return;

    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);

    try {
      const res = await fetch(`/api/admin/users/${selectedUserId}/update`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: editName,
          email: editEmail,
          queryQuota: editQuota,
          queriesUsed: editQueriesUsed,
          notes: editNotes,
          isVerifiedAdvocate: editIsVerified,
          lawLicenseNumber: editLicense
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'ترتیبات محفوظ کرنے میں ناکامی۔');
      }

      setSuccessMsg(`صارف "${editName}" کی تمام جدید تبدیلیاں اور اختیارات کامیابی سے لاگو کر دیے گئے۔`);
      setSelectedUserId(null);
      fetchAdminData();
    } catch (err: any) {
      setErrorMsg(err.message || 'تبدیلیاں محفوظ نہ ہوسکیں۔');
    } finally {
      setLoading(false);
    }
  };

  // Trigger quick bulk quota grant
  const handleBulkBonusQuota = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);
    try {
      let updatedCount = 0;
      for (const u of users) {
        const currentQuota = u.queryQuota || 120;
        await fetch(`/api/admin/users/${u.id}/update`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ queryQuota: currentQuota + 50 })
        });
        updatedCount++;
      }
      setSuccessMsg(`تمام ${updatedCount} صارفین کو +50 اضافی سوالات کا بونس کوٹہ فراہم کر دیا گیا!`);
      fetchAdminData();
    } catch (err: any) {
      setErrorMsg('کچھ صارفین کو بونس دیتے ہوئے خرابی پیش آئی۔');
    } finally {
      setLoading(false);
    }
  };

  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    if (!notifTitle || !notifMessage) {
      setErrorMsg('عنوان اور پیغام دونوں درج کریں۔');
      return;
    }

    setSubmittingNotif(true);
    try {
      const res = await fetch('/api/admin/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: notifTitle, message: notifMessage })
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'نوٹیفکیشن ارسال کرنے میں خرابی۔');
      }

      setSuccessMsg('پش نوٹیفکیشن تمام صارفین کے پورٹل پر بھیج دیا گیا ہے!');
      setNotifTitle('');
      setNotifMessage('');
      fetchAdminData();
    } catch (err: any) {
      setErrorMsg(err.message || 'کنکشن فیلر۔');
    } finally {
      setSubmittingNotif(false);
    }
  };

  // Metrics calculations
  const totalUsers = users.length;
  const pendingApprovals = users.filter(u => u.status === 'pending').length;
  const blockedCount = users.filter(u => u.status === 'blocked').length;
  const verifiedAdvocates = users.filter(u => u.isVerifiedAdvocate).length;

  // Filter list of users based on search state & dropdown filters
  const filteredUsers = users.filter(u => {
    const matchesSearch = 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.lawLicenseNumber && u.lawLicenseNumber.includes(searchQuery));
    
    const matchesStatus = statusFilter === 'all' || u.status === statusFilter;
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;

    return matchesSearch && matchesStatus && matchesRole;
  });

  return (
    <div className="w-full h-full p-1 lg:p-4 space-y-6 overflow-y-auto max-h-[calc(100vh-120px)] font-sans text-stone-800 dark:text-stone-200">
      
      {/* Supreme Admin Header Block */}
      <div className="relative overflow-hidden bg-radial from-emerald-800/20 to-emerald-900/5 dark:from-emerald-950/40 dark:to-stone-950 p-6 rounded-3xl border border-emerald-700/20 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 text-[10px] font-bold rounded-lg uppercase tracking-widest font-mono animate-pulse">
              Super Admin Mode
            </span>
            <span className="p-1 px-2.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-[10px] font-bold rounded-lg font-urdu">
              ثقہ قانونی پورٹل
            </span>
          </div>
          <h2 className="text-xl font-extrabold flex items-center gap-2.5 tracking-tight mt-1 text-slate-800 dark:text-slate-100">
            <Shield className="text-emerald-700 dark:text-emerald-400" size={24} />
            اعلیٰ انتظامی کنٹرول پینل (Pakistan Legal Admin Core)
          </h2>
          <p className="text-xs text-stone-500 dark:text-stone-400 font-urdu">
            صارف: <strong className="text-emerald-800 dark:text-emerald-400">Softlink572@gmail.com</strong> | یہاں سے آپ تمام صارفین، ان کے کوٹہ سسٹمز، لائسنس تصدیق، رول پروموشن، سورس بلاکنگ اور لائیو اطلاعات مکمل کنٹرول کر سکتے ہیں۔
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 self-stretch md:self-auto justify-end">
          <button
            onClick={handleBulkBonusQuota}
            disabled={loading || users.length === 0}
            className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-xl text-xs font-bold font-urdu flex items-center gap-1.5 shadow-md hover:shadow-lg transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
            title="تمام ممبرز کو بطور تحفہ 50 سوالات کے ایڈیشنل کریڈٹس فراہم کریں"
          >
            <Sparkles size={13} />
            سب کو بونس کوٹہ (+50) دیں
          </button>
          
          <button
            onClick={fetchAdminData}
            disabled={refreshing}
            className="p-2.5 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200 hover:text-emerald-700 rounded-xl border border-stone-200 dark:border-stone-700 text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
          >
            <RefreshCw size={14} className={refreshing ? 'animate-spin text-emerald-600' : ''} />
            <span className="font-urdu font-semibold">ڈاٹا ریفریش</span>
          </button>
        </div>
      </div>

      {/* Alert feeds */}
      {successMsg && (
        <div className="p-3.5 text-sm text-green-800 bg-green-50 dark:bg-green-950/20 dark:text-green-400 border border-green-200 dark:border-green-900/30 rounded-2xl text-center font-urdu shadow-sm animate-fadeIn">
          ✓ {successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 text-sm text-red-800 bg-red-50 dark:bg-red-950/20 dark:text-red-400 border border-red-200 dark:border-red-900/20 rounded-2xl text-center font-urdu shadow-sm animate-fadeIn">
          ✗ {errorMsg}
        </div>
      )}

      {/* 4-Column Professional Metrics Dashboard */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'کل رجسٹرڈ صارفین', val: totalUsers, icon: Users, sub: 'کل ڈیٹا بیس ممبرز', color: 'border-emerald-600/10 text-emerald-800 dark:text-emerald-400 bg-emerald-500/5' },
          { label: 'منظوری کے منتظر', val: pendingApprovals, icon: ShieldAlert, sub: 'کارروائی درکار ہے', color: 'border-yellow-600/10 text-yellow-600 dark:text-yellow-400 bg-yellow-500/5' },
          { label: 'بلاک شدہ صارفین', val: blockedCount, icon: Ban, sub: 'بلاک شدہ اکاؤنٹس', color: 'border-rose-600/10 text-rose-600 dark:text-rose-400 bg-rose-500/5' },
          { label: 'تصدیق شدہ وکلاء', val: verifiedAdvocates, icon: Award, sub: 'ممبر لائسنس ہولڈرز', color: 'border-amber-600/10 text-amber-600 dark:text-amber-400 bg-amber-500/5' }
        ].map((met, i) => (
          <div key={i} className={`p-4 border rounded-2xl flex items-center justify-between shadow-xs transition-transform hover:translate-y-[-1px] ${met.color}`}>
            <div className="space-y-1">
              <span className="text-[11px] font-bold font-urdu block text-stone-500 dark:text-stone-400">{met.label}</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl font-extrabold font-mono tracking-tight">{met.val}</span>
                <span className="text-[9px] font-medium font-urdu opacity-75">{met.sub}</span>
              </div>
            </div>
            <div className="p-2 rounded-xl bg-white/40 dark:bg-stone-900/40">
              <met.icon size={22} className="opacity-85" />
            </div>
          </div>
        ))}
      </div>

      {/* Main interactive administration dashboard layout */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* BIG BOARD: User registry, searches, and controls */}
        <div className="xl:col-span-8 space-y-4">
          
          <div className="bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 p-5 rounded-2xl shadow-xs space-y-4">
            
            {/* Header & Filter Controls bar */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-stone-100 dark:border-stone-800">
              <div className="flex items-center gap-2">
                <Users className="text-emerald-700 dark:text-emerald-400" size={18} />
                <h3 className="font-bold text-stone-800 dark:text-white font-urdu text-[14px]">صارفین کی تفصیلی فہرست و جدید اختیارات</h3>
              </div>
              
              {/* Reset to approved filter quickly */}
              <div className="flex items-center gap-1.5 self-end">
                <span className="text-[10px] text-stone-400 font-urdu">فلٹرز:</span>
                <button 
                  onClick={() => { setStatusFilter('all'); setRoleFilter('all'); }}
                  className="px-2 py-0.5 text-[10px] bg-stone-100 dark:bg-stone-800 rounded text-stone-500 hover:text-stone-900 dark:hover:text-stone-200 transition-all font-urdu"
                >
                  تمام ختم کریں
                </button>
              </div>
            </div>

            {/* Quick SEARCH and Double filters */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-2 text-xs">
              
              {/* Input */}
              <div className="md:col-span-6 relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="صارف کا نام، ای میل یا مہر نمبر تلاش کریں..."
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 dark:bg-stone-850 text-stone-800 dark:text-stone-150 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-urdu text-right"
                  dir="rtl"
                />
                <Search size={14} className="absolute left-3 top-3 text-stone-400" />
              </div>

              {/* Status Filter Dropdown */}
              <div className="md:col-span-3 flex items-center gap-1">
                <span className="text-[10px] text-stone-400 font-urdu whitespace-nowrap">حالت:</span>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full p-2 bg-stone-50 dark:bg-stone-850 text-stone-800 dark:text-stone-200 border border-stone-200 dark:border-stone-800 rounded-xl font-urdu text-xs"
                >
                  <option value="all">تمام حالتیں (All Status)</option>
                  <option value="approved">منظور شدہ (Approved)</option>
                  <option value="pending">تصدیق طلب (Pending)</option>
                  <option value="blocked">بلاک شدہ (Blocked)</option>
                </select>
              </div>

              {/* Role filter dropdown */}
              <div className="md:col-span-3 flex items-center gap-1">
                <span className="text-[10px] text-stone-400 font-urdu whitespace-nowrap">رول:</span>
                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="w-full p-2 bg-stone-50 dark:bg-stone-850 text-stone-800 dark:text-stone-200 border border-stone-200 dark:border-stone-800 rounded-xl font-urdu text-xs"
                >
                  <option value="all">تمام رولز (All Roles)</option>
                  <option value="admin">ایڈمن مینیجر (Administrators)</option>
                  <option value="user">عام صارف (General Users)</option>
                </select>
              </div>

            </div>

            {/* List and actions table */}
            <div className="overflow-x-auto">
              {refreshing && users.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-stone-400">
                  <Loader2 size={36} className="animate-spin mb-2" />
                  <span className="text-xs font-urdu font-medium animate-pulse">فہرست لوڈ ہو رہی ہے...</span>
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="text-center py-20 text-stone-400 space-y-2">
                  <X size={44} className="mx-auto text-stone-300 dark:text-stone-700" />
                  <p className="text-sm font-urdu">مطلوبہ فلٹرز کے مطابق کوئی بھی صارف نہیں ملا۔</p>
                </div>
              ) : (
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="border-b border-stone-200/60 dark:border-stone-800 text-[10px] text-stone-400 uppercase font-semibold">
                      <th className="py-2 px-1 text-right">صارف کی تفصیلات</th>
                      <th className="py-2 px-1 text-center">اہلیت رول</th>
                      <th className="py-2 px-1 text-center font-urdu">سوالات کوٹہ</th>
                      <th className="py-2 px-1 text-center font-urdu">سائین اپ تاریخ</th>
                      <th className="py-2 px-1 text-left">فوری اور بہت زیادہ اختیارات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 dark:divide-stone-800/40 text-xs">
                    {filteredUsers.map((u) => {
                      const limit = u.queryQuota || 120;
                      const used = u.queriesUsed || 0;
                      const usagePercent = Math.min(100, Math.round((used / limit) * 100));

                      return (
                        <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-stone-850/40 group transition-all duration-150">
                          
                          {/* User contact details */}
                          <td className="py-3.5 px-1">
                            <div className="flex items-center gap-2 justify-start">
                              <div className="text-right">
                                <div className="font-bold text-stone-800 dark:text-stone-150 flex items-center gap-1 justify-start">
                                  <span>{u.name}</span>
                                  {u.isVerifiedAdvocate && (
                                    <span 
                                      className="inline-flex bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[9px] font-bold p-0.5 px-1.5 rounded-full border border-amber-500/20 font-urdu items-center gap-0.5"
                                      title={`پاکستان لیگل کونسل تصدیق نمبر: ${u.lawLicenseNumber || 'دستیاب نہیں'}`}
                                    >
                                      <Award size={10} />
                                      وکالت رجسٹرڈ
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-stone-400 font-mono italic block mt-0.5 font-medium">{u.email}</span>
                              </div>
                            </div>
                          </td>

                          {/* Role with badges */}
                          <td className="py-3.5 px-1 text-center">
                            {u.role === 'admin' ? (
                              <span className="px-2 py-0.5 bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 text-[9px] rounded-lg font-bold border border-emerald-600/25 uppercase font-mono">
                                ADMIN
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-stone-105 dark:bg-stone-800 text-stone-500 text-[9px] rounded-lg font-mono">
                                GENERAL
                              </span>
                            )}
                          </td>

                          {/* Quotas meter visual slider */}
                          <td className="py-3.5 px-1 text-center">
                            <div className="inline-block max-w-[100px] w-full text-right">
                              <div className="flex justify-between items-center text-[10px] mb-1 font-mono">
                                <span className="text-stone-400">{limit}</span>
                                <span className="font-semibold text-emerald-700 dark:text-emerald-400">{used}</span>
                              </div>
                              <div className="w-full bg-stone-100 dark:bg-stone-800 h-1.5 rounded-full overflow-hidden">
                                <div 
                                  className="bg-emerald-600 h-full rounded-full transition-all" 
                                  style={{ width: `${usagePercent}%` }}
                                />
                              </div>
                            </div>
                          </td>

                          {/* Registration Date */}
                          <td className="py-3.5 px-1 text-center">
                            <span className="text-[10px] text-stone-400 font-mono block">
                              {new Date(u.createdAt).toLocaleDateString('ur-PK')}
                            </span>
                          </td>

                          {/* Instant Actions Column with multiple options */}
                          <td className="py-3.5 px-1 text-left space-x-1 whitespace-nowrap">
                            
                            {/* DEMOTE and PROMOTE buttons */}
                            {u.role === 'admin' ? (
                              <button
                                onClick={() => handleUserAction(u.id, 'demote')}
                                className="p-1 px-2.5 bg-yellow-500/10 hover:bg-yellow-500 text-yellow-600 hover:text-white rounded-lg text-[10px] font-bold font-urdu transition-all cursor-pointer inline-flex items-center gap-0.5"
                                title="ایڈمن عہدے سے ہٹائیں"
                              >
                                ایڈمن ہٹائیں
                              </button>
                            ) : (
                              <button
                                onClick={() => handleUserAction(u.id, 'promote')}
                                className="p-1 px-2.5 bg-emerald-600/10 hover:bg-emerald-600 text-emerald-700 hover:text-white rounded-lg text-[10px] font-bold font-urdu transition-all cursor-pointer inline-flex items-center gap-0.5"
                                title="سپر ایڈمنسٹریٹر بنائیں"
                              >
                                ایڈمن بنائیں
                              </button>
                            )}

                            {/* APPROVE and BLOCK controls */}
                            {u.status === 'blocked' ? (
                              <button
                                onClick={() => handleUserAction(u.id, 'unblock')}
                                className="p-1 px-2 bg-green-600 text-white hover:bg-green-700 rounded-lg text-[10px] font-bold font-urdu transition-all cursor-pointer inline-flex items-center gap-0.5"
                                title="پابندی ختم کریں"
                              >
                                <CheckCircle size={10} />
                                بحال (Unblock)
                              </button>
                            ) : (
                              <button
                                onClick={() => handleUserAction(u.id, 'block')}
                                className="p-1 px-2 bg-red-650/10 hover:bg-red-650 text-red-650 hover:text-white rounded-lg text-[10px] font-bold font-urdu transition-all cursor-pointer inline-flex items-center gap-0.5"
                                title="صارف کو بلاک کریں"
                              >
                                <Ban size={10} />
                                بلاک کریں
                              </button>
                            )}

                            {/* Additional direct manual EDIT options button */}
                            <button
                              onClick={() => handleSelectUserEdit(u)}
                              className="p-1 px-2 bg-blue-600/10 hover:bg-blue-600 text-blue-600 hover:text-white rounded-lg text-[10px] font-bold font-urdu transition-all cursor-pointer"
                              title="مزید اختیارات اور ڈیٹا ایڈٹ کریں"
                            >
                              تبدیلیاں (Edit)
                            </button>

                            {/* Direct permanent deletion */}
                            <button
                              onClick={() => {
                                if (window.confirm('کیا آپ واقعی اس صارف کے تمام سیشنز اور پروفائل کو ہمیشہ کے لیے حذف کرنا چاہتے ہیں؟')) {
                                  handleUserAction(u.id, 'delete');
                                }
                              }}
                              className="p-1 px-1.5 bg-rose-50/20 hover:bg-red-700 text-red-500 hover:text-white rounded-lg transition-all cursor-pointer"
                              title="ہمیشہ کے لیے اکاؤنٹ حذف کریں"
                            >
                              <Trash2 size={11} />
                            </button>

                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>

          </div>

          {/* ADVANCED OPTION: Expandable Advanced Edit Dashboard Segment */}
          {selectedUserId && (
            <div className="bg-gradient-to-r from-emerald-950/20 to-emerald-900/5 dark:from-emerald-950/50 dark:to-stone-900 p-5 rounded-2xl border-2 border-emerald-600/20 shadow-md space-y-4 animate-slideDown">
              <div className="flex justify-between items-center pb-2 border-b border-emerald-600/15">
                <div className="flex items-center gap-2">
                  <Edit2 className="text-emerald-700 dark:text-emerald-400" size={18} />
                  <h4 className="font-bold text-stone-800 dark:text-emerald-400 font-urdu text-sm">
                    صارف ترتیبات و بہت زیادہ اختیارات کنٹرول (Edit User & Scale Permissions)
                  </h4>
                </div>
                <button 
                  onClick={() => setSelectedUserId(null)}
                  className="p-1 bg-stone-100 hover:bg-stone-200 dark:bg-stone-850 dark:hover:bg-stone-800 rounded-full text-stone-400 transition-all cursor-pointer"
                >
                  <X size={15} />
                </button>
              </div>

              <form onSubmit={handleSaveUserSettings} className="space-y-4 text-xs font-urdu text-right" dir="rtl">
                
                {/* 2-Column Inputs */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  <div>
                    <label className="block text-xs font-bold text-stone-650 dark:text-stone-300 mb-1">
                      صارف کا پورا نام (Full Name)
                    </label>
                    <input
                      type="text"
                      required
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full p-2.5 bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-sans text-left text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-650 dark:text-stone-300 mb-1">
                      صارف کا ای میل آئی ڈی (Email Address)
                    </label>
                    <input
                      type="email"
                      required
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                      className="w-full p-2.5 bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-sans text-left text-xs"
                    />
                  </div>

                </div>

                {/* Quota & Usage details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  
                  <div>
                    <label className="block text-xs font-bold text-stone-650 dark:text-stone-300 mb-1">
                      مختص کردہ سوالات کا کوٹہ (Max Query Quota)
                    </label>
                    <input
                      type="number"
                      required
                      min={0}
                      max={10000}
                      value={editQuota}
                      onChange={(e) => setEditQuota(Number(e.target.value))}
                      className="w-full p-2.5 bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono text-left text-xs"
                    />
                    <span className="text-[10px] text-stone-400 block mt-1">ڈیفالٹ: 120 سوالات روزانہ</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-650 dark:text-stone-300 mb-1">
                      اب تک پوچھے گئے سوالات (Queries Used)
                    </label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={editQueriesUsed}
                      onChange={(e) => setEditQueriesUsed(Number(e.target.value))}
                      className="w-full p-2.5 bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono text-left text-xs"
                    />
                    <span className="text-[10px] text-stone-400 block mt-1">اس صارف کا استعمال شدہ کاؤنٹر</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-650 dark:text-stone-300 mb-1">
                      وکالت تصدیق کارڈ نمبر (Punjab/Sindh Bar License)
                    </label>
                    <input
                      type="text"
                      placeholder="مثال: LHC-8923-ADV"
                      value={editLicense}
                      onChange={(e) => setEditLicense(e.target.value)}
                      className="w-full p-2.5 bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-sans text-left text-xs"
                    />
                    <span className="text-[10px] text-stone-400 block mt-1">ہائی کورٹ / ماتحت عدالت کا مہر نمبر</span>
                  </div>

                </div>

                {/* Advocate verified boolean check */}
                <div className="flex items-center gap-3 p-3 bg-stone-50 dark:bg-stone-850 rounded-xl border border-stone-200/50 dark:border-stone-800 justify-between">
                  <div className="space-y-0.5 text-right flex-1">
                    <p className="text-xs font-bold text-stone-700 dark:text-stone-200 flex items-center justify-start gap-1">
                      <Award size={13} className="text-amber-500" />
                      پاکستان بار کونسل ممبرشپ لاگو کریں
                    </p>
                    <p className="text-[10px] text-stone-400">اس وکیل کی تصدیق کریں تاکہ اس کے نام کے ساتھ سونے رنگ کا پیمانہ عدل والا بیج نظر آئے۔</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setEditIsVerified(!editIsVerified)}
                    className="p-1 focus:outline-none text-emerald-700 dark:text-emerald-400 cursor-pointer"
                  >
                    {editIsVerified ? <ToggleRight size={38} className="text-emerald-600" /> : <ToggleLeft size={38} className="text-stone-400 dark:text-stone-600" />}
                  </button>
                </div>

                {/* Remarks/Notes */}
                <div>
                  <label className="block text-xs font-bold text-stone-650 dark:text-stone-300 mb-1">
                    انتظامی ریمارکس / نوٹسز (Internal Administrative Notes)
                  </label>
                  <textarea
                    rows={2}
                    value={editNotes}
                    onChange={(e) => setEditNotes(e.target.value)}
                    placeholder="یہاں کوئی بھی انتظامی ریمارکس لکھیں جیسے 'ممبر نے فیس ڈرافٹنگ جمع کروائی ہے' یا 'خصوصی کسٹمر'..."
                    className="w-full p-2.5 bg-white dark:bg-stone-850 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                {/* Buttons controls */}
                <div className="flex items-center gap-2 justify-end pt-2 border-t border-stone-150 dark:border-stone-800">
                  <button
                    type="button"
                    onClick={() => setSelectedUserId(null)}
                    className="py-2 px-5 bg-stone-105 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-750 rounded-xl text-xs font-bold text-stone-500 dark:text-stone-300 transition-all cursor-pointer"
                  >
                    منسوخ کریں
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="py-2 px-6 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                  >
                    {loading ? (
                      <>
                        <Loader2 size={12} className="animate-spin" />
                        محفوظ کیا جا رہا ہے...
                      </>
                    ) : (
                      <>
                        <Check size={12} />
                        اختیارات و تبدیلیاں محفوظ کریں
                      </>
                    )}
                  </button>
                </div>

              </form>
            </div>
          )}

        </div>

        {/* RIGHT SIDEBAR: Broadcaster & Logs stats */}
        <div className="xl:col-span-4 space-y-6">
          
          {/* Notification Broadcast form */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 p-5 rounded-2xl shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-stone-100 dark:border-stone-800">
              <Bell className="text-emerald-700 dark:text-emerald-400" size={18} />
              <h3 className="font-bold text-stone-800 dark:text-white font-urdu text-[13px]">پش نوٹیفکیشن / لائیو اعلان بھیجیں</h3>
            </div>

            <form onSubmit={handleSendNotification} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-stone-600 dark:text-stone-350 mb-1 font-urdu text-right">
                  اعلان کا عنوان (Title)
                </label>
                <input
                  type="text"
                  required
                  value={notifTitle}
                  onChange={(e) => setNotifTitle(e.target.value)}
                  placeholder="مثال: سپریم کورٹ کرائم رپورٹ رولنگ نمبر 45"
                  className="w-full p-2.5 text-xs bg-stone-50 dark:bg-stone-850 text-stone-850 dark:text-stone-100 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-urdu text-right"
                  dir="rtl"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-stone-600 dark:text-stone-355 mb-1 font-urdu text-right">
                  تفصیلی پیغام (Notification Message)
                </label>
                <textarea
                  rows={4}
                  required
                  value={notifMessage}
                  onChange={(e) => setNotifMessage(e.target.value)}
                  placeholder="صارفین کو آگاہ کرنے کی تفصیلات یا مہماتی پیغام یہاں ٹائپ کریں۔ یہ تمام صارفین کو نظر آئے گا..."
                  className="w-full p-2.5 text-xs bg-stone-50 dark:bg-stone-855 text-stone-850 dark:text-stone-105 border border-stone-200 dark:border-stone-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 font-urdu text-right"
                  dir="rtl"
                />
              </div>

              <button
                type="submit"
                disabled={submittingNotif}
                className="w-full py-2.5 px-4 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl focus:outline-none disabled:opacity-50 flex items-center justify-center gap-1.5 font-urdu transition-all cursor-pointer shadow-md active:scale-95"
              >
                {submittingNotif ? (
                  <>
                    <Loader2 size={12} className="animate-spin" />
                    ارسال کیا جا رہا ہے...
                  </>
                ) : (
                  <>
                    <Send size={12} />
                    پورٹل اعلان نشر کریں
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Real-time system log mockup status with extra controls */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-4 rounded-2xl shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-stone-100 dark:border-stone-800">
              <span className="text-[10px] font-bold text-stone-400 dark:text-stone-500 uppercase font-sans">System Diagnostics</span>
              <span className="text-xs font-bold text-stone-700 dark:text-stone-200 font-urdu">سسٹم ایکشنز لاگز</span>
            </div>
            
            <div className="space-y-2 max-h-[140px] overflow-y-auto">
              <div className="text-[10px] border-b border-stone-100/30 pb-1.5 flex justify-between font-mono gap-1 text-right">
                <span className="text-stone-400">API Standard</span>
                <span className="text-emerald-500">ملازمین فیلڈ چیک: OK</span>
              </div>
              <div className="text-[10px] border-b border-stone-100/30 pb-1.5 flex justify-between font-mono gap-1 text-right">
                <span className="text-stone-400">Gemini-3.5 Engine</span>
                <span className="text-blue-500">پاکستان لا سورس: Active</span>
              </div>
              <div className="text-[10px] border-b border-stone-100/30 pb-1.5 flex justify-between font-mono gap-1 text-right">
                <span className="text-stone-400">Draft Templates</span>
                <span className="text-amber-500">7 سٹرکچرز لوڈڈ</span>
              </div>
            </div>
          </div>

          {/* History list with details */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 p-4 rounded-2xl shadow-xs space-y-3">
            <h4 className="font-bold text-xs text-stone-400 dark:text-stone-400 font-sans uppercase">صارفین کے لیے سابقہ نشر اطلاعات</h4>
            <div className="space-y-3 max-h-[200px] overflow-y-auto pr-1">
              {notifications.length === 0 ? (
                <p className="text-center py-6 text-[11px] text-stone-400 font-urdu italic">کوئی اعلانات موجود نہیں ہیں۔</p>
              ) : (
                notifications.map((notif) => (
                  <div key={notif.id} className="p-3 bg-stone-50 dark:bg-stone-850 rounded-xl border border-stone-150 dark:border-stone-800/40">
                    <div className="font-bold text-xs text-stone-800 dark:text-stone-250 font-urdu">{notif.title}</div>
                    <p className="text-[10px] text-stone-500 dark:text-stone-400 font-urdu leading-relaxed mt-1 text-right" dir="rtl">{notif.message}</p>
                    <div className="text-[8px] text-stone-400 font-mono mt-1.5 text-right">{new Date(notif.createdAt).toLocaleString('ur-PK')}</div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </div>
    
    </div>
  );
}
