/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Smartphone, Download, Settings, RefreshCw, Terminal, CheckCircle, HelpCircle, Code, Copy, Check } from 'lucide-react';

export default function MobileAppPortal() {
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk'>('pwa');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Simulated PWA installable hook
  const [isInstallable, setIsInstallable] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      // Prevent standard browser bar from popping up
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    });

    window.addEventListener('appinstalled', () => {
      setIsInstallable(false);
      setDeferredPrompt(null);
    });
  }, []);

  const triggerPWAInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstallable(false);
      setDeferredPrompt(null);
    }
  };

  const handleCopyCode = (text: string, ref: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(ref);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const commandScript = `npm install @capacitor/core @capacitor/cli
npx cap init "Justice Legal Assistant" "com.justice.legalassistant" --web-dir=dist
npm install @capacitor/android
npx cap add android
npm run build
npx cap sync
npx cap open android`;

  const capacitorConfig = `{
  "appId": "com.justice.legalassistant",
  "appName": "جسٹس لیگل اسسٹنٹ",
  "webDir": "dist",
  "server": {
    "androidScheme": "https"
  },
  "android": {
    "allowMixedContent": true
  }
}`;

  return (
    <div className="w-full h-full p-2 lg:p-6 overflow-y-auto max-h-[calc(100vh-100px)]">
      
      {/* Informative Header card */}
      <div className="mb-6 bg-blue-600/10 border border-blue-500/10 p-4 lg:p-5 rounded-2xl flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex items-center gap-3 text-right">
          <div className="p-3 bg-blue-600/15 text-blue-750 dark:text-blue-400 rounded-xl">
            <Smartphone size={22} />
          </div>
          <div className="text-right">
            <h2 className="text-base font-extrabold text-stone-800 dark:text-stone-100 font-urdu">موبائل ایپ (APK) اور PWA انسٹالر ہب</h2>
            <p className="text-xs text-stone-500 dark:text-stone-400 font-urdu mt-0.5">اپنے موبائل فون پر جسٹس لیگل اسسٹنٹ ایپ ڈاؤن لوڈ، انسٹال اور کنورٹ کیجئے</p>
          </div>
        </div>
        
        {/* Toggle options */}
        <div className="flex bg-stone-150 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-0.5 rounded-xl">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`px-4 py-2 text-xs font-urdu font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'pwa'
                ? 'bg-blue-650 text-white shadow-sm'
                : 'text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
            }`}
          >
            تھری کلک PWA انسٹال (موبائل ایپ)
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`px-4 py-2 text-xs font-urdu font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'apk'
                ? 'bg-blue-650 text-white shadow-sm'
                : 'text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
            }`}
          >
            اینڈرائیڈ APK پیکیجنگ (Capacitor)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {activeTab === 'pwa' ? (
          <>
            {/* Visual Phone Frame / Left view */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div className="w-[280px] h-[540px] border-8 border-stone-800 dark:border-stone-700 bg-stone-100 dark:bg-stone-950 rounded-[40px] shadow-2xl relative overflow-hidden flex flex-col pt-6 px-3">
                {/* Speaker top detail */}
                <div className="w-24 h-4 bg-stone-800 absolute top-0 left-1/2 transform -translate-x-1/2 rounded-b-xl z-20"></div>
                
                {/* Simulated App screen */}
                <div className="flex-1 rounded-[24px] bg-white dark:bg-stone-900 overflow-hidden flex flex-col relative border border-stone-200/40">
                  
                  {/* Top screen header status */}
                  <div className="bg-emerald-800 text-white p-3 pt-4 text-center">
                    <h3 className="text-[11px] font-bold font-urdu">جسٹس لیگل اسسٹنٹ</h3>
                    <p className="text-[8px] opacity-75 font-mono">Mobile App Viewport</p>
                  </div>

                  {/* App body */}
                  <div className="flex-1 p-3 space-y-3.5 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/10 rounded-lg text-center">
                        <span className="text-[12px] font-bold text-emerald-800 dark:text-emerald-300 font-urdu leading-snug block">منظور شدہ اینڈرائیڈ ورژن</span>
                        <span className="text-[8px] text-stone-400 block font-mono">Android v12.1 Native Compliant</span>
                      </div>

                      <div className="p-2.5 bg-stone-50 dark:bg-stone-800 rounded-lg">
                        <div className="w-1/2 h-1.5 bg-stone-200 dark:bg-stone-700 rounded mb-1"></div>
                        <div className="w-full h-1 bg-stone-100 dark:bg-stone-750 rounded mb-1"></div>
                        <div className="w-5/6 h-1 bg-stone-100 dark:bg-stone-750 rounded"></div>
                        <div className="w-full h-12 bg-emerald-700/10 border border-dashed border-emerald-600/20 text-[9px] text-emerald-800 dark:text-emerald-300 font-urdu rounded-lg mt-2 flex items-center justify-center text-center p-1 font-medium">
                          قانونی مکالمہ اور وکیل ڈرافٹنگ روم اب پورٹیبل ہے!
                        </div>
                      </div>
                    </div>

                    {/* Launch button inside app */}
                    <button
                      onClick={triggerPWAInstall}
                      className="w-full py-2 bg-emerald-700 text-white text-[10px] font-bold font-urdu rounded-xl shadow-md cursor-pointer animate-bounce flex items-center justify-center gap-1"
                    >
                      <Download size={10} />
                      انسٹال موبائل ایپ (PWA)
                    </button>
                  </div>
                </div>

                {/* Bottom line button */}
                <div className="w-28 h-1 bg-stone-600 dark:bg-stone-700 rounded-full mx-auto my-2 shrink-0"></div>
              </div>
            </div>

            {/* Urdu instructions Right Column */}
            <div className="lg:col-span-7 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 rounded-2xl shadow-sm space-y-4">
              <div className="flex items-center gap-2 border-b border-stone-100 dark:border-stone-800 pb-2 mb-2 justify-end">
                <span className="text-sm font-extrabold text-stone-700 dark:text-stone-200 font-urdu">موبائل ایپ انسٹالیشن گائیڈ (PWA):</span>
                <Smartphone size={16} className="text-blue-650" />
              </div>

              <div className="space-y-4 font-urdu text-xs leading-relaxed text-right">
                <p className="text-stone-600 dark:text-stone-400 bg-stone-50 dark:bg-stone-950 p-4 rounded-xl border border-stone-100 dark:border-stone-800">
                  ہماری سسٹم ایک <strong>پروگریسو ویب ایپ (PWA)</strong> ہے، جس کا مطلب ہے کہ آپ اسے براہِ راست انٹرنیٹ سے اپنے اینڈرائیڈ یا آئی او ایس (Apple) فون میں کسی بھی سستے پلے اسٹور لنک کے بغیر باقاعدہ ایپ کی شکل میں انسٹال کر سکتے ہیں۔ یہ ایک نجی اور محفوظ نان-پلے اسٹور اینڈرائیڈ فائل پیکنگ ہے۔
                </p>

                <div className="space-y-3 pt-2">
                  <div className="flex gap-3 justify-end">
                    <div className="text-right">
                      <strong className="text-stone-800 dark:text-stone-100">کروم / اینڈرائیڈ کروم (Chrome Browser)</strong>
                      <p className="text-stone-500 dark:text-stone-400 text-[11px] mt-0.5">اپنے موبائل کروم براؤزر کے اوپر بنے تین ڈاٹ (Settings menu) پر کلک کریں اور "Add to Home Screen" یا "Install App" پر ٹیپ کریں، ایپ فوراً آپ کے موبائل اسکرین پر آ جائے گی۔</p>
                    </div>
                    <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center shrink-0 font-bold font-mono">1</div>
                  </div>

                  <div className="flex gap-3 justify-end">
                    <div className="text-right">
                      <strong className="text-stone-800 dark:text-stone-100">آئی فون / سفاری (Safari Browser)</strong>
                      <p className="text-stone-500 dark:text-stone-400 text-[11px] mt-0.5">سفاری براؤزر میں پیج لوڈ کر کے نیچے بنے شیئر بٹن (Share icon) پر کلک کریں، اور لسٹ میں فائنڈ کر کے "Add to Home Screen" منتخب کیجئے، یہ فون ایپ بن جائے گی۔</p>
                    </div>
                    <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center shrink-0 font-bold font-mono">2</div>
                  </div>

                  <div className="flex gap-3 justify-end">
                    <div className="text-right">
                      <strong className="text-stone-800 dark:text-stone-100">آف لائن کام کرنے کی اہلیت</strong>
                      <p className="text-stone-500 dark:text-stone-400 text-[11px] mt-0.5">انسٹال شدہ پروگریسو ایپ انتہائی ہلکی ہے اور خودکار طور پر موبائل میموری میں کیشے ہو جاتی ہے، جس کی بدولت انٹرنیٹ نہ ہونے پر بھی صارفین اپنے بنائے گئے ڈرافٹ اور اسٹامپ کینوس کا مطالعہ کر سکتے ہیں!</p>
                    </div>
                    <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center shrink-0 font-bold font-mono">3</div>
                  </div>
                </div>

                {isInstallable ? (
                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/15 rounded-xl flex items-center justify-between gap-3 mt-4">
                    <button
                      onClick={triggerPWAInstall}
                      className="py-2.5 px-6 font-bold bg-emerald-700 text-white rounded-xl text-xs hover:bg-emerald-800 transition-all cursor-pointer shadow-sm shrink-0"
                    >
                      ابھی ایپ انسٹال کریں
                    </button>
                    <span className="text-[11px] text-emerald-850 dark:text-emerald-450 leading-normal text-right">
                      ہمارا سیکیور لنک موبائل سسٹم پر لائیو ڈیٹیکٹ ہو چکا ہے! فلی ایپ میں کنورٹ کرنے کے لیے بٹن پر کلک کریں۔
                    </span>
                  </div>
                ) : (
                  <div className="p-4 bg-blue-600/10 border border-blue-500/10 rounded-xl text-center text-blue-805 dark:text-blue-400 text-[11px]">
                    نوٹ: اگر آپ کسٹمر کے کمپیوٹر پر ہیں، تو بس اوپر والے براؤزر مینو سے "Install" پر کلک کریں یا موبائل فون کیمرے سے کیو آر کوڈ اسکین کر کے انسٹال کیجئے۔
                  </div>
                )}
              </div>
            </div>
          </>
        ) : (
          /* Capacitor APK view panel */
          <div className="lg:col-span-12 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 rounded-2xl shadow-sm space-y-6">
            <div className="border-b border-stone-100 dark:border-stone-800 pb-3 flex flex-col md:flex-row gap-3 justify-between items-center">
              <span className="text-[10px] bg-blue-700 text-white font-mono font-bold px-3 py-1 rounded-full uppercase tracking-widest">
                Source Android Packaging
              </span>
              <div className="text-right">
                <span className="text-sm font-extrabold text-stone-700 dark:text-stone-200 font-urdu block">
                  اینڈرائیڈ آرکیٹیکچر پیکج بنانا (Building Capacitor APK Bundle):
                </span>
                <p className="text-[11px] text-stone-400 font-urdu mt-1">اپنے ریکٹر/ وائٹ پراجیکٹ کو آفیشل اینڈرائیڈ سٹوڈیو یا گریڈل بلڈر فائل میں تبدیل کیجئے</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Commands list */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <button
                    onClick={() => handleCopyCode(commandScript, 'cli')}
                    className="p-1 px-2.5 bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 rounded hover:bg-stone-200 transition-all text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCode === 'cli' ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
                    کوڈ کاپی کریں
                  </button>
                  <span className="font-bold text-stone-600 dark:text-stone-300 font-urdu">مرحلہ وار ٹرمینل کمانڈز (Terminal CLI):</span>
                </div>

                <div className="p-4 bg-stone-950 text-emerald-400 font-mono text-xs rounded-xl overflow-x-auto whitespace-pre leading-relaxed border border-stone-850">
                  {commandScript}
                </div>

                <p className="text-[10px] text-stone-400 leading-normal text-right font-urdu pt-1.5">
                  پروجیکٹ کی ڈائرکٹری میں ان کمانڈز کو رائز کریں، یہ خودکار طور پر فزیکل اینڈرائیڈ پروجیکٹ تیار کر دے گی، جس کے بعد آپ اینڈرائیڈ اسٹوڈیو میں "Build APK" پر کلک کر کے اصل <strong>.apk</strong> فائل برائے موبائل نکال سکتے ہیں۔
                </p>
              </div>

              {/* Configurations code */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <button
                    onClick={() => handleCopyCode(capacitorConfig, 'config')}
                    className="p-1 px-2.5 bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 rounded hover:bg-stone-200 transition-all text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCode === 'config' ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
                    کوڈ کاپی کریں
                  </button>
                  <span className="font-bold text-stone-600 dark:text-stone-300 font-urdu">کیپیسیٹر کنفیگ پاتھ (`capacitor.config.json`):</span>
                </div>

                <div className="p-4 bg-stone-950 text-blue-400 font-mono text-xs rounded-xl overflow-x-auto whitespace-pre leading-relaxed border border-stone-850">
                  {capacitorConfig}
                </div>

                <div className="p-3.5 bg-blue-600/10 border border-blue-500/15 rounded-xl space-y-1 text-right font-urdu text-[11px] leading-relaxed">
                  <span className="font-extrabold text-blue-805 dark:text-blue-300 block mb-1">طریقہ کار (APK Setup Workflow):</span>
                  <p>1. پروجیکٹ کی جڑ میں ایک نئی فائل <strong>capacitor.config.json</strong> ترتیب دیں اور اوپر والا کوڈ اس میں پیسٹ کریں۔</p>
                  <p>2. ٹرمینل پر <strong>npm run build</strong> رن کریں تاکہ جاوا سکرپٹ ڈسٹ فولڈر تیار ہو جائے۔</p>
                  <p>3. <strong>npx cap sync</strong> کمانڈ چلائیں تاکہ کوڈ اینڈرائیڈ فائل میں رن ہونے لاحق ہو۔</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
