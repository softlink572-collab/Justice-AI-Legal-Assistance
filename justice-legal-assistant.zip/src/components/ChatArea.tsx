/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Send, Square, Mic, MicOff, Volume2, VolumeX, AlertTriangle, Paperclip, FileText, Image, RefreshCw, Scale, ChevronRight, Loader2, Copy, Check, Printer, Phone } from 'lucide-react';
import { Thread, Message, Attachment, User } from '../types';
import { exportThreadToPDF } from '../utils/pdfExport';

interface ChatAreaProps {
  currentThread: Thread | null;
  onSendMessage: (text: string, atts: Attachment[]) => Promise<void>;
  sending: boolean;
  currentUser: User | null;
}

const LEGAL_SUGGESTIONS = [
  { text: 'تعزیرات پاکستان (PPC) کی دفعہ 420 کی تعریف اور سزا کیا ہے؟', en: 'What is PPC Section 420 and its penalty?' },
  { text: 'آئینِ پاکستان کے آرٹیکل 199 کے تحت رٹ کیسے دائر کی جاتی ہے؟', en: 'How to file a Writ Petition under Article 199 of the Constitution?' },
  { text: 'سول پروسیجر کوڈ (CPC) کے تحت حکم امتناعی (Stay Order) کی فائلنگ کیسے ہوتی ہے؟', en: 'How is a stay order filed under CPC?' },
  { text: 'سرکاری ملازمین کے محکمانہ رولز اور انکوائری کے قانون کی وضاحت کریں۔', en: 'Explain civil servant departmental rules and inquiry procedures.' }
];

export default function ChatArea({ currentThread, onSendMessage, sending, currentUser }: ChatAreaProps) {
  const downloadSvgAsPng = (svgMarkup: string, fileName: string = 'legal_design.png') => {
    try {
      const svgBlob = new Blob([svgMarkup], { type: 'image/svg+xml;charset=utf-8' });
      const browserUrl = window.URL || (window as any).webkitURL;
      const blobURL = browserUrl.createObjectURL(svgBlob);
      
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 1200;
        canvas.height = 800;
        const context = canvas.getContext('2d');
        if (context) {
          context.fillStyle = 'white';
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          
          const pngURL = canvas.toDataURL('image/png');
          const downloadLink = document.createElement('a');
          downloadLink.href = pngURL;
          downloadLink.download = fileName;
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
        }
        browserUrl.revokeObjectURL(blobURL);
      };
      image.src = blobURL;
    } catch (err) {
      console.error('Failed to export vector graphic to PNG:', err);
    }
  };

  const [inputText, setInputText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [parsingDoc, setParsingDoc] = useState(false);
  const [voiceRecording, setVoiceRecording] = useState(false);
  const [activeSpeechId, setActiveSpeechId] = useState<string | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [errorLocal, setErrorLocal] = useState('');
  const [isExportingPDF, setIsExportingPDF] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  const handleExportThreadPDF = async () => {
    if (!currentThread || currentThread.messages.length === 0) return;
    setIsExportingPDF(true);
    setErrorLocal('');
    try {
      const clientName = currentUser ? currentUser.name : 'معزز سائل (مہمان)';
      await exportThreadToPDF(currentThread, clientName);
    } catch (err: any) {
      setErrorLocal('پی ڈی ایف ڈاؤنلوڈ کرنے میں خرابی پیش آئی: ' + (err.message || err));
    } finally {
      setIsExportingPDF(false);
    }
  };
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const handleCopyMessage = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(msgId);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const handlePrintMessage = (content: string) => {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (doc) {
      doc.write(`
        <html>
          <head>
            <title>قانونی دستاویز - جسٹس لاء ایسوسی ایٹس</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
              @font-face {
                font-family: 'Alvi Nastaleeq';
                src: url('https://cdn.jsdelivr.net/gh/tariq-abdullah/urdu-web-font-CDN/AlviLahoriNastaleeq.woff2') format('woff2');
              }
              @page {
                size: legal;
                margin: 1.2in 1in 1.2in 1in;
              }
              body {
                font-family: 'Alvi Nastaleeq', 'Inter', serif;
                padding: 20px;
                color: #1a1a1a;
                direction: rtl;
                line-height: 2.3;
                background-color: #fff;
                font-size: 16px;
              }
              .header {
                text-align: center;
                border-bottom: 3px double #047857;
                padding-bottom: 15px;
                margin-bottom: 30px;
              }
              .header h1 {
                margin: 0;
                font-size: 28px;
                color: #047857;
                font-family: 'Alvi Nastaleeq', serif;
                font-weight: bold;
              }
              .header .advocate-name {
                margin: 5px 0;
                font-size: 18px;
                color: #111;
                font-family: 'Alvi Nastaleeq', serif;
                font-weight: bold;
              }
              .header .advocate-title {
                margin: 2px 0 0 0;
                font-size: 11px;
                color: #4b5563;
                font-family: 'Inter', sans-serif;
                letter-spacing: 1.5px;
                text-transform: uppercase;
                font-weight: 600;
              }
              .content {
                font-size: 16px;
                white-space: pre-wrap;
                color: #111827;
                text-align: justify;
              }
              .footer {
                margin-top: 60px;
                border-top: 1px solid #e5e7eb;
                padding-top: 15px;
                text-align: center;
                font-size: 11px;
                color: #6b7280;
                font-family: 'Inter', sans-serif;
              }
              strong {
                color: #047857;
                font-weight: bold;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>جسٹس لاء ایسوسی ایٹس</h1>
              <div class="advocate-name">سید اظہر حسین سبزواری</div>
              <div class="advocate-title">Advocate High Court - Syed Azhar Hussain Sabzwari</div>
            </div>
            <div class="content">${content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>')}</div>
            <div class="footer">
              جسٹس لاء ایسوسی ایٹس - قانونی مشورہ و معاونت سروس
              <br/>پرنٹ تاریخ: ${new Date().toLocaleString('ur-PK')}
            </div>
          </body>
        </html>
      `);
      doc.close();

      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 1000);
      }, 500);
    }
  };

  // Scroll to bottom when messages list advances
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentThread?.messages, sending]);

  // Clean speech synthesis if component gets unmounted
  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  // Web Speech API client voice recognition setups
  const startRecording = () => {
    setErrorLocal('');
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorLocal('آپ کا براؤزر مائیکروفون ٹرانسکرپشن کو سپورٹ نہیں کرتا۔ برائے کرم کروم یا سفاری استعمال کریں۔');
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'ur-PK'; // Setup for primary Urdu capturing

      rec.onstart = () => {
        setVoiceRecording(true);
      };

      rec.onerror = (e: any) => {
        console.error('ASR error:', e);
        // Fallback to English if Urdu setup triggers error in standard chrome
        if (rec.lang === 'ur-PK') {
          rec.lang = 'en-US';
          rec.start();
        } else {
          setVoiceRecording(false);
          setErrorLocal('مائیکروفون تک رسائی ممکن نہیں۔');
        }
      };

      rec.onend = () => {
        setVoiceRecording(false);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputText((prev) => (prev ? prev + ' ' + transcript : transcript));
        }
      };

      recognitionRef.current = rec;
      rec.start();
    } catch (e: any) {
      console.error(e);
      setVoiceRecording(false);
    }
  };

  const stopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setVoiceRecording(false);
    }
  };

  // Text-To-Speech (TTS) Narration helper
  const handleToggleSpeech = (msgId: string, text: string) => {
    if (activeSpeechId === msgId) {
      window.speechSynthesis.cancel();
      setActiveSpeechId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown styling so it doesn't narrate special characters like asterisks
    const cleanedText = text
      .replace(/\*\*/g, '')
      .replace(/##/g, '')
      .replace(/#/g, '')
      .replace(/[*_`#\-\[\]()]/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanedText);
    
    // Choose appropriate voice for language text
    // Check if contains Urdu characters
    const isUrdu = /[\u0600-\u06FF]/.test(text);
    utterance.lang = isUrdu ? 'ur-PK' : 'en-GB';
    
    // Attempt to locate native speaking voice matching
    const voices = window.speechSynthesis.getVoices();
    let matchingVoice = null;
    if (isUrdu) {
      matchingVoice = voices.find(v => v.lang.includes('ur') || v.lang.includes('ar') || v.name.includes('Urdu'));
    } else {
      matchingVoice = voices.find(v => v.lang.includes('en') && (v.name.includes('Google') || v.name.includes('Natural')));
    }
    if (matchingVoice) utterance.voice = matchingVoice;

    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      setActiveSpeechId(null);
    };
    utterance.onerror = () => {
      setActiveSpeechId(null);
    };

    setActiveSpeechId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // File processors (converts to base64, triggers server parsing for docs)
  const processUploadedFile = async (file: File) => {
    setErrorLocal('');
    const sizeLimit = 15 * 1024 * 1024; // 15MB limit
    if (file.size > sizeLimit) {
      setErrorLocal('فائل کا سائز بہت بڑا ہے۔ برائے کرم 15MB سے کم فائل اپ لوڈ کریں۔');
      return;
    }

    const fileType = file.type;
    const isImage = fileType.startsWith('image/');
    const isPdf = fileType === 'application/pdf';
    const isDocx = fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

    if (!isImage && !isPdf && !isDocx) {
      setErrorLocal('معذرت، صرف تصویر، PDF، یا MS Word (.docx) فائلیں اپ لوڈ کی جا سکتی ہیں۔');
      return;
    }

    setParsingDoc(true);
    const reader = new FileReader();

    reader.onload = async () => {
      const base64Data = reader.result as string;
      
      const newAtt: Attachment = {
        name: file.name,
        type: isImage ? 'image' : isPdf ? 'pdf' : 'docx',
        size: file.size,
        base64Data: isImage ? base64Data : undefined
      };

      // If document (PDF/Word), send immediately to express server for parsing text
      if (isPdf || isDocx) {
        try {
          const parseRes = await fetch('/api/parse-document', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileData: base64Data,
              fileName: file.name,
              fileType: isPdf ? 'pdf' : 'docx'
            })
          });

          const parseData = await parseRes.json();
          if (!parseRes.ok) throw new Error(parseData.error || 'دستاویز پڑھنے میں ناکامی۔');

          newAtt.extractedText = parseData.text;
        } catch (err: any) {
          setErrorLocal(err.message || 'دستاویز کے تجزیہ میں ناکامی۔');
          setParsingDoc(false);
          return;
        }
      }

      setAttachments(prev => [...prev, newAtt]);
      setParsingDoc(false);
    };

    reader.onerror = () => {
      setErrorLocal('فائل لوڈ کرنے میں خرابی پیش آئی۔');
      setParsingDoc(false);
    };

    reader.readAsDataURL(file);
  };

  // Handle Input Changes
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processUploadedFile(e.target.files[0]);
    }
  };

  // Drag and drop specifications as requested by guidelines
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const handleSend = async () => {
    if (!inputText.trim() && attachments.length === 0) return;
    const textToSend = inputText;
    const attsToSend = attachments;

    setInputText('');
    setAttachments([]);
    setErrorLocal('');

    await onSendMessage(textToSend, attsToSend);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // Render text helper putting highlights on legal references (citations)
  const formatMessageText = (content: string) => {
    // Check and strip any raw XML/SVG block from being rendered directly as raw text inside formatMessageText
    const textWithoutXML = content.replace(/```(?:xml|html|svg)?\s*([\s\S]*?<svg[\s\S]*?<\/svg>)[\s\S]*?```/gi, '').trim();

    // Escape or split lines
    const lines = textWithoutXML ? textWithoutXML.split('\n') : [];
    return lines.map((line, lIdx) => {
      const trimmedLine = line.trim();

      // Skip rendering entirely empty lines to avoid huge unnecessary empty blocks
      if (!trimmedLine) {
        return null;
      }

      // Check for custom decorative divider
      if (trimmedLine.includes('✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿') || trimmedLine === '✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿' || trimmedLine.startsWith('✿')) {
        return (
          <div key={lIdx} className="text-center my-3 text-emerald-600 dark:text-emerald-400 font-extrabold tracking-widest text-[20px] select-none py-1 w-full flex justify-center">
            ✿⊱•┈┈•⊰✿✿⊱••┈•⊰✿
          </div>
        );
      }

      // Basic markdown styling parsing (bolding)
      let renderedNode: React.ReactNode = line;

      // Look for Section references, Articles, and common Citation formats
      // E.g., PLD, SCMR, PPC, CPC, CrPC
      const citationRegex = /(\bPLD\b|\bSCMR\b|\bYLR\b|\bCLC\b|\bPCrLJ\b|\bSCR\b|\bConstitution\b|\bArticle\b|\bSection\b|\bPPC\b|\bCPC\b|\bCrPC\b|\bدفعہ\b|\bآرٹیکل\b|\bآئین\b)/gi;

      const hasCitation = citationRegex.test(trimmedLine);

      // Clean strong bold representations
      if (line.includes('**')) {
        const parts = line.split('**');
        renderedNode = parts.map((part, pIdx) => {
          if (pIdx % 2 === 1) {
            return <strong key={pIdx} className="text-emerald-900 dark:text-emerald-300 font-bold">{part}</strong>;
          }
          return part;
        });
      }

      const styleClass = trimmedLine.startsWith('*') || trimmedLine.startsWith('-')
        ? 'pl-4 pr-1 list-disc text-slate-800 dark:text-slate-250 my-1 font-urdu text-[19px] md:text-[21px] leading-[2.1]'
        : line.startsWith('###')
        ? 'text-[22px] font-bold text-slate-900 dark:text-emerald-300 mt-3 mb-1 font-urdu'
        : line.startsWith('##') || line.startsWith('#')
        ? 'text-[24px] font-bold text-emerald-800 dark:text-emerald-400 mt-4 mb-2 font-urdu'
        : 'my-1 min-h-[1.5rem] font-urdu text-[19px] md:text-[21px] leading-[2.1] text-stone-850 dark:text-stone-100 font-medium';

      return (
        <div key={lIdx} className={`${styleClass} ${hasCitation ? 'border-r-2 border-emerald-600/35 pr-2' : ''}`} style={{ textAlign: 'justify', textJustify: 'inter-word' }}>
          {renderedNode}
        </div>
      );
    });
  };

  return (
    <div 
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`w-full h-full flex flex-col justify-between overflow-hidden relative ${
        isDragOver ? 'bg-emerald-55 dark:bg-emerald-950/20 ring-2 ring-dashed ring-emerald-500/50 animate-pulse' : 'bg-transparent'
      }`}
    >
      
      {/* Pending status or error messages */}
      {errorLocal && (
        <div className="absolute top-3 left-3 right-3 p-3 bg-red-50 dark:bg-red-950/20 text-red-650 dark:text-red-400 border border-red-100 dark:border-red-900/30 text-xs rounded-xl z-20 flex items-center gap-2 font-urdu">
          <AlertTriangle size={14} className="shrink-0" />
          <span>{errorLocal}</span>
          <button onClick={() => setErrorLocal('')} className="ml-auto text-[10px] uppercase font-sans hover:underline">Close</button>
        </div>
      )}

      {/* Subheader controls for active chat threads */}
      {currentThread && currentThread.messages.length > 0 && (
        <div className="bg-white dark:bg-stone-900 border-b border-stone-200 dark:border-stone-800 px-4 py-2.5 flex items-center justify-between z-10 sticky top-0 shrink-0 select-none shadow-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportThreadPDF}
              disabled={isExportingPDF}
              className="p-1.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white disabled:bg-stone-200 dark:disabled:bg-stone-850 disabled:text-stone-400 rounded-xl text-xs font-urdu font-semibold tracking-tight flex items-center gap-1.5 transition-all shadow-sm cursor-pointer ml-1 hover:-translate-y-0.5"
            >
              {isExportingPDF ? (
                <>
                  <Loader2 size={13} className="animate-spin" />
                  <span>پی ڈی ایف بَن رہی ہے...</span>
                </>
              ) : (
                <>
                  <FileText size={13} />
                  <span>مکمل گفتگو ڈاؤنلوڈ کریں (PDF)</span>
                </>
              )}
            </button>
          </div>
          <div className="text-right">
            <h2 className="text-xs md:text-sm font-bold text-stone-800 dark:text-stone-100 font-urdu truncate max-w-[200px] md:max-w-[400px]">
              {currentThread.title || 'باقاعدہ قانونی مکالمہ'}
            </h2>
            <p className="text-[10px] text-stone-400 font-mono -mt-0.5">
              {currentThread.messages.length} پیغامات
            </p>
          </div>
        </div>
      )}

      {/* Main chat log output */}
      <div className="flex-1 overflow-y-auto p-3 lg:p-6 space-y-6">
        {!currentThread || currentThread.messages.length === 0 ? (
          /* Landing Empty State */
          <div className="w-full max-w-5xl mx-auto py-8 lg:py-16 flex flex-col items-center">
            
            {/* Elegant Emblem Govt Stamp style */}
            <div className="mb-6 flex flex-col items-center">
              <div className="w-20 h-20 bg-emerald-500/10 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 rounded-full flex items-center justify-center p-4 shadow-inner border border-emerald-500/10">
                <Scale size={44} />
              </div>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-extrabold font-sans tracking-tight text-stone-900 dark:text-stone-100 mt-4 text-center">
                Justice Legal AI Assistant
              </h1>
              <div className="text-center mt-3 space-y-1">
                <p className="text-lg md:text-xl lg:text-2xl font-bold tracking-widest text-[#047857] dark:text-emerald-400 font-sans uppercase">
                  JUSTICE LAW ASSOCIATES
                </p>
                <p className="text-3xl md:text-4xl lg:text-5xl font-black text-rose-950 dark:text-[#f3f4f6] font-sans my-2 tracking-tight">
                  Syed Azhar Hussain Sabzwari
                </p>
                <span className="text-sm md:text-base lg:text-lg text-emerald-800 dark:text-emerald-300 font-sans tracking-widest block uppercase font-extrabold mt-1">
                  Advocate High Court
                </span>
              </div>
            </div>

            {/* Urdu Invitation Message */}
            <div className="mb-8 text-center max-w-2xl p-6 bg-stone-50 dark:bg-stone-900/55 rounded-2xl border border-stone-200/50 dark:border-stone-800/50">
              <h2 className="urdu-title text-lg md:text-xl font-bold text-stone-850 dark:text-stone-100">
                السلام علیکم! میں آپ کا ڈیجیٹل جسٹس لیگل اسسٹنٹ ہوں۔
              </h2>
              <p className="urdu-text text-base md:text-[18px] text-stone-650 dark:text-stone-300 mt-3 leading-[2.1] font-medium" dir="rtl">
                میں آئینِ پاکستان 1973، تعزیراتِ پاکستان (پاکستان پینل کوڈ)، ضابطہ فوجداری، ضابطہ دیوانی سمیت تمام اعلیٰ عدالتی فیصلوں اور نوٹسز کی تفہیمِ قوانین کی بنیاد پر رہنمائی کے لیے تیار ہوں۔ آپ کوئی بھی تحریر، تصویر یا نوٹس اپ لوڈ کر کے بھی اس کی مفصل تشریح جان سکتے ہیں اور لیگل ڈرافٹنگ کر سکتے ہیں۔
              </p>
            </div>

            {/* Clickable prompt templates */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full self-stretch">
              {LEGAL_SUGGESTIONS.map((sug, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setInputText(sug.text);
                  }}
                  className="rounded-2xl p-4 border border-stone-150 dark:border-stone-800 text-right bg-white dark:bg-stone-900 hover:bg-stone-50 dark:hover:bg-stone-850 hover:-translate-y-0.5 hover:shadow-xs active:translate-y-0 text-stone-700 dark:text-stone-300 transition-all flex flex-col justify-between gap-2 h-full cursor-pointer"
                >
                  <p className="urdu-text-sm text-emerald-750 dark:text-emerald-400 font-semibold w-full">
                    {sug.text}
                  </p>
                  <p className="text-[10px] text-stone-400 font-sans leading-tight mt-1 text-left flex items-center gap-1">
                    <ChevronRight size={10} />
                    {sug.en}
                  </p>
                </button>
              ))}
            </div>

          </div>
        ) : (
          /* Actual message rendering list */
          <div className="w-[99%] max-w-[99%] mx-auto space-y-3">
            {currentThread.messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 w-full ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {/* User/Bot Avatar on model messaging */}
                  {!isUser && (
                    <div className="w-8 h-8 rounded-full bg-emerald-600/10 text-emerald-750 dark:text-emerald-400 flex items-center justify-center p-1.5 border border-emerald-500/10 shrink-0 self-start">
                      <Scale size={16} />
                    </div>
                  )}

                  {/* Bubble wrapper */}
                  <div className={`w-full max-w-[100%] flex flex-col gap-1.5`}>
                    
                    {/* Attachments rendering on top of messages (User side mostly) */}
                    {msg.attachments && msg.attachments.length > 0 && (
                      <div className="flex flex-wrap gap-2 justify-end mb-1">
                        {msg.attachments.map((att, aIdx) => (
                          <div 
                            key={aIdx} 
                            className="bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700 rounded-xl p-2 px-3 text-xs flex items-center gap-2"
                          >
                            {att.type === 'image' ? <Image size={14} className="text-blue-500" /> : <FileText size={14} className="text-emerald-650" />}
                            <div className="max-w-[120px] truncate">
                              <div className="font-semibold text-slate-705 dark:text-slate-300 title">{att.name}</div>
                              <div className="text-[9px] text-slate-400 font-mono">{(att.size / 1024).toFixed(1)} KB</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* True Body text content */}
                    <div
                      dir={/[\u0600-\u06FF]/.test(msg.content) ? 'rtl' : 'ltr'}
                      className={`p-4 md:p-5 rounded-3xl pb-3.5 leading-relaxed text-[19px] md:text-[21px] shadow-xs relative flex flex-col justify-between w-full ${
                        isUser
                          ? 'bg-emerald-700 text-white rounded-tr-none'
                          : 'bg-white dark:bg-slate-900 text-slate-850 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-tl-none font-urdu'
                      }`}
                    >
                      {/* Formatted body markup */}
                      <div className="flex-1 w-full">
                        {msg.content === 'BLOCKED_USER_RESPONSE' ? (
                          <div className="flex flex-col gap-3 py-1 font-urdu leading-normal text-right w-full" dir="rtl">
                            <p className="whitespace-pre-wrap text-red-650 dark:text-red-450 font-bold text-[20px] md:text-[22px]" style={{ lineHeight: '1.8' }}>
                              آپ کو ایڈمن کی طرف سے بلاک کیا گیا ہے برائے مہربانی ایڈمن سے رابطہ کریں
                            </p>
                            <p className="text-sm text-stone-500 dark:text-stone-400 max-w-sm mt-1">
                              فوری متبادل قانونی مدد حاصل کرنے کے لیے نیچے دیے گئے بٹنز کے ذریعے فورا رابطہ کریں:
                            </p>
                            
                            <div className="flex items-center gap-4 mt-4 justify-start">
                              {/* Call button with icon only */}
                              <a
                                href="tel:03452436118"
                                className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white flex items-center justify-center transition-all shadow-md cursor-pointer hover:-translate-y-0.5"
                                title="کال کریں"
                              >
                                <Phone size={24} />
                              </a>
                              {/* WhatsApp button with icon only */}
                              <a
                                href="https://wa.me/923452436118"
                                className="w-14 h-14 rounded-full bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white flex items-center justify-center transition-all shadow-md cursor-pointer hover:-translate-y-0.5"
                                title="واٹس ایپ پر رابطہ"
                                target="_blank"
                                rel="noreferrer"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008 0c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.457L0 24zm6.59-4.846c1.6.95 3.1 1.455 4.7 1.456 5.48 0 9.94-4.462 9.943-9.94.002-2.654-1.02-5.15-2.875-7.006C16.51 1.8 14.02.78 11.37.782c-5.485.002-9.946 4.464-9.949 9.944a9.87 9.87 0 0 0 1.451 5.163l-1.095 4.0 4.1-.11.13.08zm11.385-6.85c-.3-.15-1.77-.875-2.04-.975-.27-.1-.47-.15-.67.15-.2.3-.77.975-.94 1.175-.17.2-.34.225-.64.075-1.15-.575-1.92-1.012-2.68-2.312-.2-.35-.02-.54.15-.71.15-.15.3-.35.45-.52.15-.175.2-.3.3-.5.1-.2.05-.375-.025-.525-.075-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.525.075-.8.375-.275.3-.1.57.17.87.51.58 2.03 2.03 4.95 3.3 1.62.7 2.85 1.11 3.55 1.34.7.23 1.35.2 1.85.12.55-.08 1.77-.723 2.02-1.39.255-.667.255-1.237.18-1.352-.075-.115-.27-.15-.57-.3z"/>
                                </svg>
                              </a>
                            </div>
                          </div>
                        ) : isUser ? (
                          <p className="whitespace-pre-wrap font-urdu text-[19px] md:text-[21px] text-right" style={{ lineHeight: '2.1' }} dir="rtl">{msg.content}</p>
                        ) : (
                          <>
                            {formatMessageText(msg.content)}
                            {/* SVG Graphic Renderer Canvas */}
                            {(() => {
                              const svgRegex = /```(?:xml|html|svg)?\s*([\s\S]*?<svg[\s\S]*?<\/svg>)[\s\S]*?```/i;
                              const match = msg.content.match(svgRegex);
                              if (match && match[1]) {
                                const svgMarkup = match[1].trim();
                                return (
                                  <div className="mt-4 p-4 bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-2xl flex flex-col items-center w-full">
                                    <div className="w-full border-b border-stone-150 dark:border-stone-850 pb-2 mb-3 flex items-center justify-between">
                                      <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider font-sans">
                                        Justice Vector Graphic Studio
                                      </span>
                                      <span className="text-xs font-bold text-emerald-800 dark:text-emerald-400 font-urdu">
                                        تخلیق شدہ مہر / اشتہار برائے پرنٹ و ڈاؤنلوڈ
                                      </span>
                                    </div>
                                    <div 
                                      className="w-full flex justify-center bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] dark:bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-4 overflow-x-auto min-h-[200px] items-center text-justify"
                                      dangerouslySetInnerHTML={{ __html: svgMarkup }} 
                                    />
                                    <button
                                      onClick={() => downloadSvgAsPng(svgMarkup, `justice_design_${msg.id}.png`)}
                                      className="mt-3 py-2.5 px-6 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold font-urdu flex items-center gap-1.5 transition-all shadow-md self-center cursor-pointer"
                                    >
                                      <Printer size={13} />
                                      تصویر ڈاؤنلوڈ کریں (.PNG)
                                    </button>
                                  </div>
                                );
                              }
                              return null;
                            })()}
                          </>
                        )}
                      </div>

                      {/* Micro actions bottom line (TTS, citations, copy, print) */}
                      {!isUser && (
                        <div className="flex justify-between items-center mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/60 font-sans gap-2">
                          <span className="text-[10px] font-semibold text-emerald-800 dark:text-emerald-400 font-urdu block leading-normal text-right">
                            جسٹس لاء ایسوسی ایٹس
                            <br />
                            سید اظہر حسین سبزواری ایڈوکیٹ ہائی کورٹ
                          </span>

                          <div className="flex items-center gap-1">
                            {/* Copy button */}
                            <button
                              onClick={() => handleCopyMessage(msg.id, msg.content)}
                              className="p-1 px-1.5 text-xs text-slate-500 hover:text-emerald-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all flex items-center gap-1 font-urdu"
                              title="کاپی کریں"
                            >
                              {copiedMsgId === msg.id ? (
                                <>
                                  <Check size={12} className="text-emerald-600" />
                                  <span className="text-[10px]">کاپی ہوا</span>
                                </>
                              ) : (
                                <>
                                  <Copy size={12} />
                                  <span className="text-[10px]">کاپی</span>
                                </>
                              )}
                            </button>

                            {/* Print to PDF button */}
                            <button
                              onClick={() => handlePrintMessage(msg.content)}
                              className="p-1 px-1.5 text-xs text-slate-500 hover:text-emerald-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all flex items-center gap-1 font-urdu"
                              title="پی ڈی ایف پرنٹ کریں"
                            >
                              <Printer size={12} />
                              <span className="text-[10px]">پرنٹ پی ڈی ایف</span>
                            </button>

                            {/* Voice TTS button */}
                            <button
                              onClick={() => handleToggleSpeech(msg.id, msg.content)}
                              className={`p-1 px-2 text-[10px] rounded-lg transition-all flex items-center gap-1 ${
                                activeSpeechId === msg.id
                                  ? 'bg-emerald-700 text-white animate-pulse'
                                  : 'text-slate-500 hover:text-emerald-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                              }`}
                              title={activeSpeechId === msg.id ? "Stop voice reading" : "Read aloud (آواز میں سنیں)"}
                            >
                              {activeSpeechId === msg.id ? (
                                <>
                                  <VolumeX size={12} />
                                  <span className="font-urdu text-[10px]">آواز بند</span>
                                </>
                              ) : (
                                <>
                                  <Volume2 size={12} />
                                  <span className="font-urdu text-[10px]">آواز</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Timestamp line */}
                    <div className={`text-[9px] text-slate-400 font-mono mt-0.5 ${isUser ? 'text-right' : 'text-left'}`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>

                  </div>

                  {/* User avatar right alignment */}
                  {isUser && (
                    <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center font-bold text-xs shrink-0 self-start border border-slate-200 dark:border-slate-700">
                      C
                    </div>
                  )}

                </div>
              );
            })}

            {/* Waiting loader in thread */}
            {sending && (
              <div className="flex gap-3 w-full justify-start items-center">
                <div className="w-8 h-8 rounded-full bg-emerald-600/10 text-emerald-700 dark:text-emerald-455 flex items-center justify-center p-1.5 border border-emerald-500/10 shrink-0 select-none">
                  <Scale size={16} />
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-3xl rounded-tl-none text-slate-550 flex items-center gap-2 shadow-xs py-3 max-w-sm">
                  <Loader2 size={14} className="animate-spin text-emerald-600" />
                  <span className="text-xs font-urdu">آپ کے سوال کا جواب پراسس میں ہے...</span>
                </div>
              </div>
            )}
          </div>
        )}
        <div ref={chatEndRef}></div>
      </div>

      {/* Attachments previewer widget (on input panel) */}
      {(attachments.length > 0 || parsingDoc) && (
        <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950 flex flex-wrap gap-2 shrink-0 z-10">
          {attachments.map((att, i) => (
            <div 
              key={i} 
              className="relative pr-8 p-1.5 px-3 bg-white dark:bg-slate-905 border border-slate-200 dark:border-slate-800 text-xs rounded-xl flex items-center gap-1.5 shadow-xs"
            >
              {att.type === 'image' ? <Image size={12} className="text-blue-500" /> : <FileText size={12} className="text-emerald-600" />}
              <span className="max-w-[150px] truncate font-sans text-[11px]">{att.name}</span>
              <button
                onClick={() => removeAttachment(i)}
                className="absolute right-1 top-2 p-0.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md cursor-pointer"
              >
                <Square size={10} />
              </button>
            </div>
          ))}

          {/* Uploading Circular Progress Item */}
          {parsingDoc && (
            <div className="p-1.5 px-3 bg-white dark:bg-slate-900 border border-emerald-500/35 text-xs rounded-xl flex items-center gap-2 shadow-xs animate-pulse">
              <div className="relative w-4 h-4 flex items-center justify-center">
                <Loader2 size={13} className="animate-spin text-emerald-600" />
              </div>
              <span className="font-urdu text-[11px] text-emerald-700 dark:text-emerald-400">فائل لوڈ ہو رہی ہے...</span>
            </div>
          )}
        </div>
      )}

      {/* Bottom control panel inputs */}
      <div className="p-3 lg:p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 backdrop-blur-xs relative z-10 shrink-0">
        <div className="max-w-none w-full px-4 lg:px-8">
          
          {/* Drag & drop helper visual */}
          {isDragOver && (
            <div className="absolute inset-0 bg-emerald-500/10 backdrop-blur-xs flex items-center justify-center text-sm font-urdu text-emerald-900 dark:text-emerald-300 font-bold z-15 pointer-events-none">
              فائل یہاں چھوڑیں! (Drop files to upload)
            </div>
          )}

          {/* Prompt panel shell */}
          <div className="relative flex items-end gap-2 border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-850 px-3 py-2 rounded-2xl focus-within:ring-2 focus-within:ring-emerald-550 focus-within:border-transparent transition-all">
            
            {/* hidden file attachments trigger */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*,.pdf,.docx"
              className="hidden"
            />

            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={parsingDoc}
              className="p-1 px-2.5 text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all flex items-center gap-1 shrink-0 self-center"
              title="تصویر یا دستاویز اپ لوڈ کریں"
            >
              {parsingDoc ? (
                <RefreshCw size={15} className="animate-spin text-emerald-600" />
              ) : (
                <>
                  <Paperclip size={15} />
                  <span className="text-[10px] uppercase font-sans font-medium hidden md:inline">Attach</span>
                </>
              )}
            </button>

            {/* Main message typing box */}
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              rows={1}
              placeholder={voiceRecording ? 'مائیکروفون سن رہا ہے... بولیں' : 'اپنا سوال یہاں لکھیں...'}
              className="flex-1 max-h-32 min-h-[36px] p-2 pr-4 bg-transparent outline-none border-none text-slate-850 dark:text-slate-150 text-[17px] md:text-[19px] font-urdu resize-none font-medium leading-relaxed placeholder-stone-400 dark:placeholder-stone-550 placeholder-opacity-60 dark:placeholder-opacity-65 transition-opacity duration-200 text-right"
              dir="rtl"
            />

            {/* Voice mircophone triggers */}
            <button
              onClick={voiceRecording ? stopRecording : startRecording}
              className={`p-2 rounded-xl transition-all shrink-0 self-center ${
                voiceRecording
                  ? 'bg-red-650 hover:bg-red-750 text-white animate-pulse'
                  : 'text-slate-500 hover:text-emerald-700 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title={voiceRecording ? "کلک کر کے ریکارڈنگ ختم کریں" : "بول کر سوال پوچھیں (اردو/انگلش)"}
            >
              {voiceRecording ? <MicOff size={16} /> : <Mic size={16} />}
            </button>

            {/* SEND button */}
            <button
              onClick={handleSend}
              disabled={sending || (!inputText.trim() && attachments.length === 0)}
              className="p-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl disabled:bg-stone-200 dark:disabled:bg-stone-850 disabled:text-stone-400 shrink-0 self-center transition-all cursor-pointer"
            >
              <Send size={15} />
            </button>
          </div>

          {/* No disclaimer message here */}

        </div>
      </div>

    </div>
  );
}
