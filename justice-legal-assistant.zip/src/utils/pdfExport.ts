/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { Thread, Message } from '../types';

/**
 * Clean markdown styling to readable HTML for the PDF document
 */
const markdownToHtml = (content: string): string => {
  if (content === 'BLOCKED_USER_RESPONSE') {
    return `
      <div style="color: #dc2626; font-weight: bold; font-size: 16px; direction: rtl; text-align: right; margin-bottom: 10px;">
        آپ کو ایڈمن کی طرف سے بلاک کیا گیا ہے برائے مہربانی ایڈمن سے رابطہ کریں
      </div>
    `;
  }

  // Double newlines to paragraph containers or distinct divs
  // Strip SVG/XML code blocks
  const contentCleaned = content.replace(/```(?:xml|html|svg)?\s*([\s\S]*?<svg[\s\S]*?<\/svg>)[\s\S]*?```/gi, '').trim();

  const lines = contentCleaned.split('\n');
  let htmlResult = '';
  let inList = false;

  for (const line of lines) {
    let trimmed = line.trim();
    if (!trimmed) {
      if (inList) {
        htmlResult += '</ul>';
        inList = false;
      }
      continue;
    }

    // Strip decorative dividers
    if (trimmed.includes('✿⊱•┈┈•⊰✿') || trimmed.startsWith('✿')) {
      if (inList) {
        htmlResult += '</ul>';
        inList = false;
      }
      htmlResult += '<div style="text-align: center; margin: 15px 0; color: #047857; font-weight: bold; font-size: 16px;">✿⊱•┈┈┈┈┈┈•⊰✿</div>';
      continue;
    }

    // Handle Headings
    if (trimmed.startsWith('###')) {
      if (inList) { htmlResult += '</ul>'; inList = false; }
      const txt = trimmed.replace(/^###\s*/, '');
      htmlResult += `<h3 style="font-size: 15px; font-weight: bold; color: #111827; margin-top: 15px; margin-bottom: 5px; direction: rtl; text-align: right;">${txt}</h3>`;
    } else if (trimmed.startsWith('##')) {
      if (inList) { htmlResult += '</ul>'; inList = false; }
      const txt = trimmed.replace(/^##\s*/, '');
      htmlResult += `<h2 style="font-size: 17px; font-weight: bold; color: #047857; border-bottom: 1px italic #ddd; padding-bottom: 3px; margin-top: 18px; margin-bottom: 8px; direction: rtl; text-align: right;">${txt}</h2>`;
    } else if (trimmed.startsWith('#')) {
      if (inList) { htmlResult += '</ul>'; inList = false; }
      const txt = trimmed.replace(/^#\s*/, '');
      htmlResult += `<h1 style="font-size: 19px; font-weight: bold; color: #047857; border-bottom: 2px solid #047857; padding-bottom: 4px; margin-top: 20px; margin-bottom: 10px; direction: rtl; text-align: right;">${txt}</h1>`;
    }
    // Handle Bullet Lists
    else if (trimmed.startsWith('*') || trimmed.startsWith('-')) {
      if (!inList) {
        htmlResult += '<ul style="margin: 5px 0 10px 0; padding-right: 20px; direction: rtl; list-style-type: square; text-align: right;">';
        inList = true;
      }
      const txt = trimmed.replace(/^[*-\s]+/, '');
      const formattedTxt = parseInlineMarkdown(txt);
      htmlResult += `<li style="font-size: 13.5px; line-height: 1.9; color: #2d3748; margin-bottom: 4px;">${formattedTxt}</li>`;
    }
    // Standard Paragraph
    else {
      if (inList) { htmlResult += '</ul>'; inList = false; }
      const formattedTxt = parseInlineMarkdown(trimmed);

      // Check for PPC / CPC legal references
      const hasCitation = /(\bPLD\b|\bSCMR\b|\bYLR\b|\bCLC\b|\bPCrLJ\b|\bConstitution\b|\bArticle\b|\bSection\b|\bPPC\b|\bCPC\b|\bCrPC\b|\bدفعہ\b|\bآرٹیکل\b|\bآئین\b)/gi.test(trimmed);
      const borderStyle = hasCitation ? 'border-right: 3px solid #047857; padding-right: 10px;' : '';

      htmlResult += `<p style="font-size: 13.5px; line-height: 1.95; color: #1f2937; margin: 8px 0; direction: rtl; text-align: justify; ${borderStyle}">${formattedTxt}</p>`;
    }
  }

  if (inList) {
    htmlResult += '</ul>';
  }

  return htmlResult;
};

/**
 * Handles inline bolding **text**
 */
const parseInlineMarkdown = (text: string): string => {
  return text.replace(/\*\*(.*?)\*\*/g, '<strong style="color: #047857; font-weight: bold;">$1</strong>');
};

/**
 * Export current chat thread as PDF using high quality canvas conversion
 */
export const exportThreadToPDF = async (thread: Thread, userName: string = 'معزز سائل') => {
  try {
    // 1. Create temporary offscreen container styled precisely like an official High Court Legal letterhead
    const container = document.createElement('div');
    container.id = 'temp-pdf-export-container';
    
    // Style container to fit standard Letter/A4 aspect-ratio (805px width is perfect for canvas)
    container.style.position = 'fixed';
    container.style.top = '0';
    container.style.left = '0';
    container.style.width = '794px'; // A4 paper width at 96 DPI
    container.style.transform = 'translateY(-200%)'; // Hidden off-screen but rendered by browser
    container.style.zIndex = '-9999';
    container.style.backgroundColor = '#ffffff';
    container.style.color = '#111111';
    container.style.fontFamily = "'Alvi Nastaleeq', 'Inter', serif";
    container.style.padding = '45px 50px';
    container.style.boxSizing = 'border-box';
    container.style.direction = 'rtl';
    container.style.textAlign = 'right';

    // We inject native Lahori/Alvi Nastaleeq webfonts directly to guarantee correct rendering across all platforms in canvas
    const fontStyles = `
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
      @font-face {
        font-family: 'Alvi Nastaleeq';
        src: url('https://cdn.jsdelivr.net/gh/tariq-abdullah/urdu-web-font-CDN/AlviLahoriNastaleeq.woff2') format('woff2');
      }
      #temp-pdf-export-container * {
        font-family: 'Alvi Nastaleeq', 'Inter', serif;
      }
      #temp-pdf-export-container strong {
        font-family: 'Alvi Nastaleeq', 'Inter', serif;
        font-weight: bold;
      }
    `;
    const styleElement = document.createElement('style');
    styleElement.innerHTML = fontStyles;
    container.appendChild(styleElement);

    // 2. Build official high court letterhead block
    const headerHtml = `
      <div style="text-align: center; border-bottom: 4px double #047857; padding-bottom: 12px; margin-bottom: 25px;">
        <div style="font-size: 32px; font-weight: bold; color: #047857; margin-bottom: 2px;">جسٹس لاء ایسوسی ایٹس</div>
        <div style="font-size: 20px; font-weight: bold; color: #111111; margin: 4px 0;">سید اظہر حسین سبزواری</div>
        <div style="font-size: 12.5px; color: #4b5563; font-family: 'Inter', sans-serif; letter-spacing: 1.5px; text-transform: uppercase; font-weight: 600;">
          Advocate High Court - Syed Azhar Hussain Sabzwari
        </div>
        <div style="font-size: 11px; margin-top: 5px; color: #059669; font-weight: bold;">
          رابطہ نمبر: 03452436118 | فیملی، دیوانی و فوجداری مقدمات کے ماہر
        </div>
      </div>
    `;

    // 3. Document Title / Case Metadata Block
    const formattedDate = new Date().toLocaleDateString('ur-PK', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    const formattedTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const metadataHtml = `
      <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px 18px; margin-bottom: 25px; font-size: 12.5px; color: #334155; line-height: 1.6;">
        <table style="width: 100%; border-collapse: collapse; direction: rtl;">
          <tr>
            <td style="text-align: right; width: 50%; font-weight: bold;">دستاویز: <span style="color: #047857;">باقاعدہ قانونی مکالمہ و ایڈوائس لاگ</span></td>
            <td style="text-align: left; width: 50%; font-weight: bold;">کیس / موضوع: <span style="color: #047857;">${thread.title || 'عام قانونی رہنمائی'}</span></td>
          </tr>
          <tr>
            <td style="text-align: right; margin-top: 4px;">رپورٹ سائل: <span style="font-weight: 600;">${userName}</span></td>
            <td style="text-align: left; margin-top: 4px;">تاریخ و وقت جاری: <span>${formattedDate} \u2002 ${formattedTime}</span></td>
          </tr>
        </table>
      </div>
    `;

    // 4. Construct Conversations flow beautifully nested
    let conversationHtml = '<div style="margin-bottom: 40px;">';
    
    thread.messages.forEach((msg, idx) => {
      const isUser = msg.role === 'user';
      const senderTitle = isUser ? `سائل (صارف/کلائنٹ)` : `سید اظہر حسین سبزواری ایڈوکیٹ ہائی کورٹ`;
      const titleBg = isUser ? '#f1f5f9' : '#e6f4ea';
      const titleColor = isUser ? '#1e293b' : '#047857';
      const borderAccent = isUser ? '#cbd5e1' : '#047857';
      
      const msgTimestamp = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      // Create beautiful, official-looking statement log box
      conversationHtml += `
        <div style="margin-bottom: 18px; border: 1px solid ${isUser ? '#e2e8f0' : '#bbf7d0'}; border-radius: 12px; overflow: hidden; page-break-inside: avoid;">
          <!-- Item Header Label -->
          <div style="background-color: ${titleBg}; padding: 8px 15px; border-bottom: 1.5px solid ${borderAccent}; display: flex; justify-content: space-between; align-items: center; direction: rtl;">
            <span style="font-weight: bold; font-size: 12.5px; color: ${titleColor};">${senderTitle}</span>
            <span style="font-size: 10.5px; color: #64748b; font-family: 'Inter', sans-serif;">${msgTimestamp}</span>
          </div>
          <!-- Item Content Details -->
          <div style="padding: 15px; background-color: #ffffff;">
            <div style="text-align: justify; text-justify: inter-word;">
              ${markdownToHtml(msg.content)}
            </div>
            
            <!-- Render attached documents notification if any -->
            ${msg.attachments && msg.attachments.length > 0 ? `
              <div style="margin-top: 10px; padding-top: 8px; border-top: 1px dashed #e2e8f0; font-size: 11px; color: #64748b;">
                <strong>منسلک فائلیں: </strong>
                ${msg.attachments.map(att => `<span style="background-color: #f1f5f9; padding: 2px 8px; border-radius: 6px; margin-left: 5px;">📎 ${att.name}</span>`).join('')}
              </div>
            ` : ''}
          </div>
        </div>
      `;
    });

    conversationHtml += '</div>';

    // 5. Signature and Verification Stamp block
    const verificationHtml = `
      <div style="margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 20px; page-break-inside: avoid;">
        <table style="width: 100%; border-collapse: collapse; direction: rtl;">
          <tr>
            <td style="width: 50%; vertical-align: top; text-align: right; padding-right: 15px;">
              <div style="font-size: 12px; color: #64748b; margin-bottom: 4px;">ڈرافٹ بائی:</div>
              <div style="font-size: 14px; font-weight: bold; color: #111111;">جسٹس لا ایسوسی ایٹس ڈیجیٹل کونسلر</div>
              <div style="font-size: 11px; color: #94a3b8; font-family: 'Inter', sans-serif; margin-top: 2px;">AUTOMATED LEGAL DRAFTING MODULE</div>
            </td>
            <td style="width: 50%; vertical-align: top; text-align: left; padding-left: 15px;">
              <div style="font-size: 12px; color: #64748b; margin-bottom: 4px;">تصدق کنندہ:</div>
              <div style="font-size: 14px; font-weight: bold; color: #047857;">سید اظہر حسین سبزواری</div>
              <div style="font-size: 11px; color: #475569; font-weight: 600;">ایڈوکیٹ ہائی کورٹ (Advocate High Court)</div>
              
              <!-- Signature Line Indicator -->
              <div style="margin-top: 30px; border-top: 1px dashed #4b5563; width: 180px; text-align: center; display: inline-block;">
                <span style="font-size: 10px; color: #64748b;">دستخط جاری کنندگی</span>
              </div>
            </td>
          </tr>
        </table>
      </div>
    `;

    // 6. Disclaimer / Footer info
    const footerHtml = `
      <div style="margin-top: 30px; text-align: center; font-size: 10.5px; color: #64748b; border-t: 1px solid #f1f5f9; padding-top: 10px; line-height: 1.5;">
        <span>معذرت خواہی: یہ ڈیجیٹل ڈرافٹ اور قانونی مشورہ اعلیٰ درجہ کی قانونی ڈیٹا بیس اور مروجہ قوانین کی بنیاد پر تیار کیا گیا ہے۔ برائے مہربانی عدالتی استعمال سے قبل اس کی تصدیق کرائیں۔</span>
        <br />
        <span style="font-family: 'Inter', sans-serif; font-size: 9.5px; margin-top: 4px; display: inline-block;">
          Printed via Justice Legal AI Assistant - Syed Azhar Hussain Sabzwari Adv. 
        </span>
      </div>
    `;

    // Inject compiled DOM structures into container
    const innerWrapper = document.createElement('div');
    innerWrapper.innerHTML = headerHtml + metadataHtml + conversationHtml + verificationHtml + footerHtml;
    container.appendChild(innerWrapper);

    // Append to document frame
    document.body.appendChild(container);

    // 7. Convert HTML to high resolution digital image canvas
    // Wait slightly for fonts and styles to fully process in active document flow
    await new Promise(resolve => setTimeout(resolve, 600));

    const canvas = await html2canvas(container, {
      scale: 2, // 2x DPI for crisp high-resolution printing
      useCORS: true, // Enable relative source font CDN resources loading
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false
    });

    // 8. Clean temporary print element from active DOM
    document.body.removeChild(container);

    // 9. Load jsPDF and slice the canvas into a structured A4 format
    const imgData = canvas.toDataURL('image/jpeg', 0.98);
    
    // Create A4 PDF (Portrait, unit: 'mm')
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = 210; // width of standard A4 in mm
    const pdfHeight = 297; // height of standard A4 in mm
    
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    
    // Calculate aspect ratio matched width/height for PDF document
    const imageWidthInPDF = pdfWidth;
    const imageHeightInPDF = (canvasHeight * pdfWidth) / canvasWidth;

    let heightLeft = imageHeightInPDF;
    let position = 0;

    // Add first page
    pdf.addImage(imgData, 'JPEG', 0, position, imageWidthInPDF, imageHeightInPDF);
    heightLeft -= pdfHeight;

    // Loop and add pages if the length is larger than a standard A4 sheet height
    while (heightLeft > 0) {
      position = heightLeft - imageHeightInPDF; // calculate offset position to correctly slice subsequent pages
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imageWidthInPDF, imageHeightInPDF);
      heightLeft -= pdfHeight;
    }

    // 10. Generate downloadable filename incorporating the thread title and UTC timestamp
    const cleanTitle = (thread.title || 'legal_advice').replace(/[^a-zA-Z0-9\u0600-\u06FF]/g, '_').toLowerCase();
    const timestampStr = new Date().toISOString().slice(0, 10);
    const filename = `justice_advice_${cleanTitle}_${timestampStr}.pdf`;

    pdf.save(filename);
    return true;
  } catch (error) {
    console.error('Failed to export thread as PDF client-side:', error);
    throw error;
  }
};
