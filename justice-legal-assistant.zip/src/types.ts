/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'admin' | 'user';
export type UserStatus = 'pending' | 'approved' | 'blocked';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  status: UserStatus;
  createdAt: string;
  queryQuota?: number;
  queriesUsed?: number;
  notes?: string;
  isVerifiedAdvocate?: boolean;
  lawLicenseNumber?: string;
}

export interface Attachment {
  name: string;
  type: string; // 'image' | 'pdf' | 'docx'
  size: number;
  extractedText?: string;
  base64Data?: string; // For images
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  attachments?: Attachment[];
}

export interface Thread {
  id: string;
  userId: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: Message[];
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
}

export interface DraftTemplate {
  id: string;
  name: string;
  nameUrdu: string;
  type: 'plaint' | 'written_statement' | 'writ_petition' | 'legal_notice' | 'bail_application' | 'criminal_complaint' | 'khula_suit';
  description: string;
  category?: string;
  fields: {
    key: string;
    label: string;
    labelUrdu: string;
    type: 'text' | 'textarea';
    placeholder: string;
  }[];
}
