/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Landmark, Scale, ShieldAlert, Sun, Moon, LogIn, Scale as ScaleIcon, Menu, MessageSquare } from 'lucide-react';
import { User, Thread, Attachment, SystemNotification, Message } from './types';
import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import DraftingTool from './components/DraftingTool';
import AdminDashboard from './components/AdminDashboard';
import AuthModal from './components/AuthModal';
import LeftSidebar from './components/LeftSidebar';
import StampSealCreator from './components/StampSealCreator';
import MobileAppPortal from './components/MobileAppPortal';

export default function App() {
  // State elements
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'chat' | 'draft' | 'stamps' | 'apk' | 'admin'>('chat');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [sessionChecked, setSessionChecked] = useState(false);

  // Mobile navigation drawers state
  const [leftSidebarOpen, setLeftSidebarOpen] = useState(false);
  const [rightSidebarOpen, setRightSidebarOpen] = useState(false);

  // Initialize Theme and Auth Settings
  useEffect(() => {
    // Read cached login
    const cachedUser = localStorage.getItem('justice_user');
    if (cachedUser) {
      try {
        setCurrentUser(JSON.parse(cachedUser));
      } catch (e) {
        localStorage.removeItem('justice_user');
      }
    } else {
      // By default open login modal if first visit
      setAuthModalOpen(true);
    }

    // Read cached theme or default to dark
    const cachedTheme = localStorage.getItem('justice_theme') as 'light' | 'dark';
    const initialTheme = cachedTheme || 'dark';
    setTheme(initialTheme);
    if (initialTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    setSessionChecked(true);
  }, []);

  // Poll system announcements / admin push notifications
  const fetchAnnouncements = async () => {
    try {
      const res = await fetch('/api/notifications');
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch (e: any) {
      // Soft logging for announcement polls to prevent noise during server boots
      console.log('Brief announcement draft poll:', e.message || e);
    }
  };

  useEffect(() => {
    fetchAnnouncements();
    // Poll every 30 seconds for real-time announcements updates
    const interval = setInterval(fetchAnnouncements, 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch threads for currently logged in user
  const fetchActiveThreads = async (userId: string) => {
    try {
      const res = await fetch(`/api/threads?userId=${userId}`);
      if (res.ok) {
        const data = await res.json();
        setThreads(data);
        if (data.length > 0 && !activeThreadId) {
          setActiveThreadId(data[0].id);
        }
      }
    } catch (e) {
      console.error('Error fetching conversations:', e);
    }
  };

  useEffect(() => {
    if (sessionChecked) {
      const targetUserId = currentUser ? currentUser.id : 'guest';
      fetchActiveThreads(targetUserId);
    }
  }, [currentUser, sessionChecked]);

  // Handle successful login
  const handleAuthSuccess = (user: User | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('justice_user', JSON.stringify(user));
      // If approved user, navigate to chat; if pending, stay on approval info
      if (user.role === 'admin') {
        setActiveTab('admin');
      } else {
        setActiveTab('chat');
      }
    } else {
      // Guest login removal from local storage cache
      localStorage.removeItem('justice_user');
      setActiveTab('chat');
    }
    setAuthModalOpen(false);
  };

  // Perform logout
  const handleLogout = () => {
    localStorage.removeItem('justice_user');
    setCurrentUser(null);
    setThreads([]);
    setActiveThreadId(null);
    setAuthModalOpen(true);
  };

  // Toggle Theme
  const handleToggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    localStorage.setItem('justice_theme', nextTheme);
    if (nextTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  // Select another thread
  const handleSelectThread = (id: string) => {
    setActiveThreadId(id);
  };

  // Create new thread via server API
  const handleNewThread = async () => {
    const targetUserId = currentUser ? currentUser.id : 'guest';
    try {
      const res = await fetch('/api/threads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: targetUserId })
      });

      if (res.ok) {
        const data = await res.json();
        setThreads(prev => [data, ...prev]);
        setActiveThreadId(data.id);
      }
    } catch (e) {
      console.error('Error creating new thread:', e);
    }
  };

  // Delete thread via server API
  const handleDeleteThread = async (id: string) => {
    try {
      const res = await fetch(`/api/threads/${id}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        setThreads(prev => prev.filter(t => t.id !== id));
        if (activeThreadId === id) {
          const remaining = threads.filter(t => t.id !== id);
          setActiveThreadId(remaining.length > 0 ? remaining[0].id : null);
        }
      }
    } catch (e) {
      console.error('Error deleting thread:', e);
    }
  };

  // Send message handler inside chatarea
  const handleSendMessage = async (text: string, atts: Attachment[]) => {
    if (!activeThreadId) {
      const targetUserId = currentUser ? currentUser.id : 'guest';
      try {
        const res = await fetch('/api/threads', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: targetUserId })
        });
  
        if (res.ok) {
          const data = await res.json();
          setThreads(prev => [data, ...prev]);
          setActiveThreadId(data.id);
          await triggerSendCall(data.id, text, atts);
        }
      } catch (e) {
        console.error('Error creating thread on first message:', e);
      }
    } else {
      await triggerSendCall(activeThreadId, text, atts);
    }
  };

  const triggerSendCall = async (id: string, text: string, atts: Attachment[]) => {
    setSendingMessage(true);
    const targetUserId = currentUser ? currentUser.id : 'guest';

    // Optimistically update the UI by appending the user's message
    const tempUserMsgId = 'msg-opt-' + Date.now();
    const newUserMsg: Message = {
      id: tempUserMsgId,
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
      attachments: atts
    };

    setThreads(prev => prev.map(t => t.id === id ? {
      ...t,
      messages: [...t.messages, newUserMsg]
    } : t));

    // Client-side quick check: if currently logged user is blocked
    if (currentUser && currentUser.status === 'blocked') {
      setTimeout(() => {
        setThreads(prev => prev.map(t => t.id === id ? {
          ...t,
          messages: [
            ...t.messages,
            {
              id: 'blocked-' + Date.now(),
              role: 'model',
              content: 'BLOCKED_USER_RESPONSE',
              timestamp: new Date().toISOString()
            }
          ]
        } : t));
        setSendingMessage(false);
      }, 700);
      return;
    }

    try {
      const res = await fetch(`/api/threads/${id}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          attachments: atts,
          userId: targetUserId
        })
      });

      const data = await res.json();
      if (!res.ok) {
        // If server indicates user is blocked
        if (res.status === 403 && (data.error?.includes('بلاک') || data.error?.includes('blocked'))) {
          setThreads(prev => prev.map(t => t.id === id ? {
            ...t,
            messages: [
              ...t.messages,
              {
                id: 'blocked-' + Date.now(),
                role: 'model',
                content: 'BLOCKED_USER_RESPONSE',
                timestamp: new Date().toISOString()
              }
            ]
          } : t));
          return;
        }
        throw new Error(data.error || 'پیغام ارسال کرنے میں ناکامی۔');
      }

      // Update local thread in list with the actual returned payload completely
      setThreads(prev => prev.map(t => t.id === id ? data.thread : t));
    } catch (err: any) {
      console.error(err);
      const isBlockMsg = err.message.includes('بلاک') || err.message.includes('blocked') || err.message.includes('مخالف');
      
      setThreads(prev => prev.map(t => t.id === id ? {
        ...t,
        messages: [
          ...t.messages,
          {
            id: 'err-' + Date.now(),
            role: 'model',
            content: isBlockMsg ? 'BLOCKED_USER_RESPONSE' : `معذرت، ابھی سرور جواب نہیں دے رہا۔ آپ کا سوال موصول ہو چکا ہے، لیکن جواب پراسس نہیں کیا جا سکا۔ برائے مہربانی اپنا انٹرنیٹ کنکشن چیک کریں یا دوبارہ کوشش کریں۔\n\nخرابی کی تفصیل: ${err.message}`,
            timestamp: new Date().toISOString()
          }
        ]
      } : t));
    } finally {
      setSendingMessage(false);
    }
  };

  // Retrieve selected thread details
  const currentThread = threads.find(t => t.id === activeThreadId) || null;

  // Render main screen dashboard or restriction banner
  const isPendingApproval = currentUser && currentUser.status === 'pending' && currentUser.role !== 'admin';
  const isBlocked = currentUser && currentUser.status === 'blocked';

  return (
    <div className="w-full h-screen max-h-screen flex bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 font-sans transition-colors duration-300 overflow-hidden">
      
      {/* Left Sidebar - Drafting Categories and Admin mode */}
      <LeftSidebar
        currentUser={currentUser}
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        onNavigateToDraft={() => setActiveTab('draft')}
        onNavigateToAdmin={() => setActiveTab('admin')}
        onNavigateToStamps={() => setActiveTab('stamps')}
        onNavigateToApk={() => setActiveTab('apk')}
        activeTab={activeTab}
        isOpen={leftSidebarOpen}
        onClose={() => setLeftSidebarOpen(false)}
        onLogout={handleLogout}
        onLoginClick={() => setAuthModalOpen(true)}
      />

      {/* Main Content Workspace viewport */}
      <div className="flex-1 flex flex-col justify-between overflow-hidden min-w-0 h-full">
        
        {/* Top Control Header bar */}
        <header className="h-14 border-b border-stone-200 dark:border-stone-850 bg-white dark:bg-stone-900/90 backdrop-blur-xs flex items-center justify-between px-4 lg:px-6 z-30 sticky top-0 shrink-0 select-none">
          {/* Left Side: Navigation triggers & controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLeftSidebarOpen(true)}
              className="lg:hidden p-1.5 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg text-slate-600 dark:text-slate-350 transition-all cursor-pointer mr-0.5"
              title="دستاویز مینیو"
            >
              <Menu size={20} />
            </button>

            {/* Dark/Light mode switcher */}
            <button
              onClick={handleToggleTheme}
              className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl text-stone-600 dark:text-stone-300 transition-all focus:outline-none cursor-pointer"
              title="تھیم تبديل کریں"
            >
              {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
            </button>

            {/* Login indicator trigger if offline/guest */}
            {!currentUser ? (
              <button
                onClick={() => setAuthModalOpen(true)}
                className="p-1 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-urdu flex items-center gap-1 transition-all font-semibold active:scale-95 cursor-pointer shadow-xs"
              >
                <LogIn size={12} />
                لاگ ان
              </button>
            ) : null}

            <button
              onClick={() => setRightSidebarOpen(true)}
              className="lg:hidden p-1.5 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg text-slate-600 dark:text-slate-350 transition-all cursor-pointer ml-0.5"
              title="ہسٹری مینیو"
            >
              <MessageSquare size={20} />
            </button>
          </div>

          {/* Right Side: Logo & Brand details (Right-aligned representation) */}
          <div className="flex items-center gap-2 lg:gap-3 text-right">
            {/* active route indicators tag */}
            <span className="hidden sm:inline-block text-[9px] lg:text-[10px] px-2.5 py-0.5 font-bold uppercase rounded-full border border-stone-150 dark:border-stone-850 bg-stone-50 dark:bg-stone-850 font-urdu tracking-wider text-emerald-700 dark:text-emerald-400">
              {activeTab === 'chat'
                ? '👨‍⚖️ قانونی مکالمہ'
                : activeTab === 'draft'
                ? '📝 ڈرافٹ پیپر'
                : activeTab === 'stamps'
                ? '🏆 عدالتی مہر و اسٹامپ'
                : activeTab === 'apk'
                ? '📲 موبائل ایپ اے پی کے'
                : '🛡️ ایڈمنسٹریٹر'}
            </span>

            <div className="flex flex-col">
              <h1 className="text-sm md:text-base font-extrabold leading-tight tracking-tight text-emerald-700 dark:text-emerald-400 font-urdu">جسٹس لیگل اسسٹنٹ</h1>
              <p className="text-[11px] md:text-xs font-bold text-stone-700 dark:text-stone-300 font-urdu -mt-0.5">جسٹس لاء ایسوسی ایٹس</p>
            </div>

            <span className="p-1.5 bg-emerald-600/10 text-emerald-750 dark:text-emerald-450 rounded-lg select-none leading-none text-xl">
              ⚖️
            </span>
          </div>
        </header>

        {/* Content render routing */}
        <main className="flex-1 overflow-hidden min-h-0 bg-stone-50/50 dark:bg-[#121110]">
          {isBlocked && activeTab !== 'chat' ? (
            /* Blocked Account Panel space */
            <div className="w-full h-full p-6 flex flex-col items-center justify-center text-center">
              <div className="p-4 bg-red-50 dark:bg-red-950/20 text-red-650 dark:text-red-400 rounded-full mb-3">
                <ShieldAlert size={48} />
              </div>
              <h2 className="title text-base font-bold text-stone-700 dark:text-stone-200">آپ کا اکاؤنٹ بلاک کر دیا گیا ہے</h2>
              <p className="urdu-text text-stone-500 dark:text-stone-400 mt-2 max-w-sm">
                قواعد کی خلاف ورزی یا کسی غلط استعمال کی تشخیص کی وجہ سے ایڈمن کی جانب سے آپ کے اکاؤنٹ کی رسائی کو معطل کر دیا گیا ہے۔ براہ کرم ای میل کے ذریعے رابطہ کریں۔
              </p>
            </div>
          ) : isPendingApproval ? (
            /* Pending verification screen block */
            <div className="w-full h-full p-6 flex flex-col items-center justify-center text-center">
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-500 rounded-full mb-3 animate-pulse">
                <ScaleIcon size={48} />
              </div>
              <h2 className="urdu-title text-base font-bold text-stone-700 dark:text-stone-200">منظوری کا انتظار ہے (Pending Admin Approval)</h2>
              <p className="urdu-text-sm text-stone-500 dark:text-stone-400 mt-2 max-w-md bg-stone-100 dark:bg-stone-900 leading-relaxed rounded-2xl p-4">
                السلام علیکم! سپریم کنٹرول لاگ کے تحت آپ کا رجسٹریشن فارم موصول ہو چکا ہے۔ غیر قانونی استعمال اور سیکیورٹی کی وجہ سے نئے اکاؤنٹس کو صرف ایڈمن ہی منظور کر سکتا ہے۔<br/>
                <strong>براہ کرم سپریم ایڈمن کی جانب سے منظوری کا انتظار کریں۔</strong> چند ہی لمحوں میں آپ کو رسائی مل جائے گی۔
              </p>
            </div>
          ) : activeTab === 'admin' && currentUser?.role === 'admin' ? (
            <AdminDashboard currentUser={currentUser} />
          ) : activeTab === 'stamps' ? (
            <StampSealCreator />
          ) : activeTab === 'apk' ? (
            <MobileAppPortal />
          ) : activeTab === 'draft' ? (
            <DraftingTool currentUser={currentUser} activeCategory={activeCategory} />
          ) : (
            <ChatArea
              currentThread={currentThread}
              onSendMessage={handleSendMessage}
              sending={sendingMessage}
              currentUser={currentUser}
            />
          )}
        </main>

      </div>

      {/* Sidebar navigation */}
      <Sidebar
        threads={threads}
        activeThreadId={activeThreadId}
        onSelectThread={handleSelectThread}
        onNewThread={handleNewThread}
        onDeleteThread={handleDeleteThread}
        currentUser={currentUser}
        onLogout={handleLogout}
        onLoginClick={() => setAuthModalOpen(true)}
        onNavigateToChat={() => setActiveTab('chat')}
        activeTab={activeTab}
        notifications={notifications}
        isOpen={rightSidebarOpen}
        onClose={() => setRightSidebarOpen(false)}
      />

      {/* Authentication modals overlay */}
      <AuthModal
        isOpen={authModalOpen}
        onAuthSuccess={handleAuthSuccess}
        onClose={() => setAuthModalOpen(false)}
      />
    </div>
  );
}
